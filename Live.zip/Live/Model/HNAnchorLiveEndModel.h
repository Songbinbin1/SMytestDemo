//
//  HNAnchorLiveEndModel.h
//  SunsetLive
//
//  Created by Sunwanwan on 2017/9/14.
//  Copyright © 2017年 HN. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface HNAnchorLiveEndModel : NSObject

@property (nonatomic, strong) NSString *live_time;
@property (nonatomic, strong) NSString *watch_num;
@property (nonatomic, strong) NSString *like_num;
@property (nonatomic, strong) NSString *get_dot;

@end
