//
//  HNGiftListModel.m
//  SunsetLive
//
//  Created by Sunwanwan on 2017/9/13.
//  Copyright © 2017年 HN. All rights reserved.
//

#import "HNGiftListModel.h"

@implementation HNGiftListModel

+ (NSDictionary *)modelCustomPropertyMapper
{
    return @{@"giftId" : @"id"};
}

-(instancetype)initWithCoder:(NSCoder *)aDecoder{
    self = [super init];
    if (self) {
        self.giftId = [aDecoder decodeObjectForKey:@"giftId"];
        self.name = [aDecoder decodeObjectForKey:@"name"];
        self.detail = [aDecoder decodeObjectForKey:@"detail"];
        self.icon = [aDecoder decodeObjectForKey:@"icon"];
        self.icon_gif = [aDecoder decodeObjectForKey:@"icon_gif"];
        self.animation = [aDecoder decodeObjectForKey:@"animation"];
        self.coin = [aDecoder decodeObjectForKey:@"coin"];
        self.status = [aDecoder decodeObjectForKey:@"status"];
        self.isBigGift = [aDecoder decodeBoolForKey:@"isBigGift"];
    }
    return self;
}

-(void)encodeWithCoder:(NSCoder *)aCoder{
    [aCoder encodeObject:self.giftId forKey:@"giftId"];
    [aCoder encodeObject:self.name forKey:@"name"];
    [aCoder encodeObject:self.detail forKey:@"detail"];
    [aCoder encodeObject:self.icon forKey:@"icon"];
    [aCoder encodeObject:self.icon_gif forKey:@"icon_gif"];
    [aCoder encodeObject:self.animation forKey:@"animation"];
    [aCoder encodeObject:self.coin forKey:@"coin"];
    [aCoder encodeObject:self.status forKey:@"status"];
    [aCoder encodeBool:self.isBigGift forKey:@"isBigGift"];
}

@end
