//
//  HNLiveAnchorModel.m
//  LiveShow
//
//  Created by Sunwanwan on 2017/8/29.
//  Copyright © 2017年 HN. All rights reserved.
//

#import "HNLiveAnchorModel.h"

@implementation HNLiveAnchorModel

@end
