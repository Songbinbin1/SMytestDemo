//
//  HNLiveInfoModel.h
//  SunsetLive
//
//  Created by Sunwanwan on 2017/9/6.
//  Copyright © 2017年 HN. All rights reserved.
//  直播信息Model

#import <Foundation/Foundation.h>

@interface HNLiveInfoModel : NSObject

@property (nonatomic, strong) NSString *up_url;   // 推流地址
@property (nonatomic, strong) NSString *barrage_price;  // 弹幕价格
@property (nonatomic, strong) NSString *is_old;  // 是否是之前的直播（之前直播异常退出的）
@property (nonatomic, strong) NSString *live_time; // 直播时长（秒）


// 直播云服务平台
@property (nonatomic, strong) NSString *live_service;

@end
