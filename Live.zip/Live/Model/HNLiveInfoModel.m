//
//  HNLiveInfoModel.m
//  SunsetLive
//
//  Created by Sunwanwan on 2017/9/6.
//  Copyright © 2017年 HN. All rights reserved.
//

#import "HNLiveInfoModel.h"

@implementation HNLiveInfoModel

@end
