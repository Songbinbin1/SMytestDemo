//
//  HNLiveAnchorModel.h
//  LiveShow
//
//  Created by Sunwanwan on 2017/8/29.
//  Copyright © 2017年 HN. All rights reserved.
//  直播的主播Model

#import <Foundation/Foundation.h>

@interface HNLiveAnchorModel : NSObject

@property (nonatomic, strong) NSString *avatar;
@property (nonatomic, strong) NSString *uid;  // 用户id
@property (nonatomic, strong) NSString *total_dot; // 历史总收益

@property (nonatomic, strong) NSString *is_follow;
@property (nonatomic, strong) NSString *nick;

@property (nonatomic, strong) NSString *level;
@property (nonatomic, strong) NSString *gender;

@property (nonatomic, strong) NSString *conetState;
@property (nonatomic, strong) NSString *rtmpURL;

@end
