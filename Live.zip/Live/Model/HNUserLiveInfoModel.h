//
//  HNUserLiveInfoModel.h
//  SunsetLive
//
//  Created by Sunwanwan on 2017/9/12.
//  Copyright © 2017年 HN. All rights reserved.
//  用户进入直播间时获取到的直播间的信息

#import <Foundation/Foundation.h>

@interface HNUserLiveInfoModel : NSObject

@property (nonatomic, strong) NSString *down_url;  // 拉流地址
@property (nonatomic, strong) NSString *barrage_price;  // 
@property (nonatomic, strong) NSString *live_type;  // 直播类型
@property (nonatomic, strong) NSString *live_price;
@property (nonatomic, strong) NSString *free_time;  // 免费时长
@property (nonatomic, strong) NSString *has_ipa;  //

@end
