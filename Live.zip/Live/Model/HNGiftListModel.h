//
//  HNGiftListModel.h
//  SunsetLive
//
//  Created by Sunwanwan on 2017/9/13.
//  Copyright © 2017年 HN. All rights reserved.
//  礼物列表模型

#import <Foundation/Foundation.h>

@interface HNGiftListModel : NSObject <NSCopying>

@property (nonatomic, strong) NSString *giftId;
@property (nonatomic, strong) NSString *name;
@property (nonatomic, strong) NSString *detail; // 礼物描述
@property (nonatomic, strong) NSString *icon;
@property (nonatomic, strong) NSString *icon_gif;
@property (nonatomic, strong) NSString *animation;  // 礼物动画
@property (nonatomic, strong) NSString *coin;  // 礼物价格
@property (nonatomic, strong) NSString *status;  // 1上架 2下架

@property (nonatomic, assign) BOOL isShow;

@property (nonatomic, assign) BOOL isBigGift;

@end
