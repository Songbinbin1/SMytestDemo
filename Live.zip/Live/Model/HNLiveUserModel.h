//
//  HNLiveUserModel.h
//  SunsetLive
//
//  Created by Sunwanwan on 2017/9/11.
//  Copyright © 2017年 HN. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface HNLiveUserModel : NSObject

@property (nonatomic, strong) NSString *uid;
@property (nonatomic, strong) NSString *avatar;
@property (nonatomic, strong) NSString *level;
@property (nonatomic, strong) NSString *nick;
@property (nonatomic, strong) NSString *type;
@end
