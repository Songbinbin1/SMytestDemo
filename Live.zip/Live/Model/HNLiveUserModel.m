//
//  HNLiveUserModel.m
//  SunsetLive
//
//  Created by Sunwanwan on 2017/9/11.
//  Copyright © 2017年 HN. All rights reserved.
//

#import "HNLiveUserModel.h"

@implementation HNLiveUserModel

@end
