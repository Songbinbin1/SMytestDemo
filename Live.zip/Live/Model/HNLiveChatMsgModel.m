//
//  HNLiveChatMsgModel.m
//  SunsetLive
//
//  Created by Sunwanwan on 2017/9/11.
//  Copyright © 2017年 HN. All rights reserved.
//

#import "HNLiveChatMsgModel.h"
#import "NSString+HNFilter.h"

@implementation HNLiveChatMsgModel
-(void)calculationcellHeight{
    if ([_msg_content containsString:@"系统"])
    {
        if ([_msg_content containsString:@"系统消息"])
        {
            _attributedScount = [HNTools getAttributedString:_msg_content withStringAttributedDic:@{NSForegroundColorAttributeName : UIColorFromRGBA(20, 203, 255, 1)} withSubString:@"系统消息：" withSubStringAttributeDic:@{NSForegroundColorAttributeName : UIColorFromRGBA(255 ,255 ,0, 1)}];
        }
        else
        {
            _attributedScount = [HNTools getAttributedString:_msg_content withStringAttributedDic:@{NSForegroundColorAttributeName : UIColorFromRGBA(20, 203, 255, 1)} withSubString:@"系统公告：" withSubStringAttributeDic:@{NSForegroundColorAttributeName : UIColorFromRGBA(255 ,255 ,0, 1)}];
        }
      _cellHeight= [HNTools getSpaceLabelHeightwithSpeace:0 withFont:SystemFontSize14 withWidth:Handle_width(285)-Handle_width(60 / 2)-Handle(15)-kSpaceToLeftOrRight content:_attributedScount]+Handle(10);
        
//         cellHeight = [self.msgLab textRectForBounds:CGRectMake(0, 0, Handle_width(285)-Handle(5)-kSpaceToLeftOrRight , CGFLOAT_MAX) limitedToNumberOfLines:0];
//        [self.bgView mas_remakeConstraints:^(MASConstraintMaker *make) {
//            make.top.mas_equalTo((kSpaceToTop-Handle(4))/2);
//            make.left.mas_equalTo(5);
//            make.width.mas_equalTo(textOfRect.size.width+Handle(5));
//            make.bottom.mas_equalTo(-(kSpaceToTop-Handle(4))/2);
//        }];
    }
    else
    {
    
        NSString *string = [NSString stringWithFormat:@"%@: %@",_nick,_msg_content];
        if (_msgType == TipsMsgType)
        {
             NSMutableAttributedString *att = [HNTools getAttributedString:string withStringAttributedDic:@{NSForegroundColorAttributeName : UIColorFromRGBA(243 ,229 ,53, 1)} withSubString:_nick withSubStringAttributeDic:@{NSForegroundColorAttributeName : UIColorFromRGBA(255 ,255 ,0, 1)}];
            _attributedScount=att;
        }
        else if (_msgType == GiftMsgType)
        {
            [self.iconImg sd_setImageWithURL:[NSURL URLWithString:[HNTools pictureStr:_g_icon]] placeholderImage:nil];
            // 创建一个可变字符串
            NSMutableAttributedString *att = [HNTools getAttributedString:string withStringAttributedDic:@{NSForegroundColorAttributeName : UIColorFromRGBA(243 ,229 ,53, 1)} withSubString:_nick withSubStringAttributeDic:@{NSForegroundColorAttributeName : UIColorFromRGBA(255 ,255 ,0, 1)}];
            
            // 设置这个富文本的目的就是为了占位
            NSTextAttachment *attch = [[NSTextAttachment alloc] init];
            attch.image = self.iconImg.image;
            attch.bounds = CGRectMake(0, -Handle(5), Handle(16), Handle(16));
            
            // 创建带有图片的富文本
            NSAttributedString *pitString = [NSAttributedString attributedStringWithAttachment:attch];
            
            // 将图片放在最后一位
            [att appendAttributedString:pitString];
            
            _attributedScount=att;
        }
        else
        {
            
            NSMutableAttributedString *labelAttributed = [string emotionStringWithEmojiHeight:20].mutableCopy;
            [labelAttributed addAttribute:NSFontAttributeName value:[UIFont systemFontOfSize:14] range:NSMakeRange(0, labelAttributed.length)];
            
            NSRange rang = [string rangeOfString:_nick];
            [labelAttributed addAttribute:NSForegroundColorAttributeName value:UIColorFromRGBA(255 ,255 ,0, 1) range:rang];
             _attributedScount=labelAttributed;
        }
        
       _cellHeight= [HNTools getSpaceLabelHeightwithSpeace:0 withFont:SystemFontSize14 withWidth:Handle_width(285)-Handle_width(60 / 2)-Handle(15)-kSpaceToLeftOrRight content:_attributedScount];
       
    }
}
- (UIImageView *)iconImg
{
    if(!_iconImg)
    {
        _iconImg = InsertImageView(nil, CGRectZero, nil);
    }
    return _iconImg;
}
@end
