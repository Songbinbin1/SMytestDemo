//
//  HNUserLiveInfoModel.m
//  SunsetLive
//
//  Created by Sunwanwan on 2017/9/12.
//  Copyright © 2017年 HN. All rights reserved.
//

#import "HNUserLiveInfoModel.h"

@implementation HNUserLiveInfoModel

@end
