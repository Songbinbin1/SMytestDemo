//
//  HNLiveAnchorUserInfoView.m
//  LiveShow
//
//  Created by Sunwanwan on 2017/8/30.
//  Copyright © 2017年 HN. All rights reserved.
//

#import "HNLiveAnchorUserInfoView.h"

@interface HNLiveAnchorUserInfoView ()

//---------- 主播头像区域
@property (nonatomic, strong) UIImageView *headerImg;
@property (nonatomic, strong) UILabel *nameLab;
@property (nonatomic, strong) UILabel *personNumberLab;  // 人数
@property (nonatomic, strong) UIView *redTimerView;
@property (nonatomic, strong) UILabel *timerLab;  // 录制定时器
@property (nonatomic, strong) UIButton *followsBtn;  // 关注

// ---------- 打赏金额区域
@property (nonatomic, strong) UIView *exceptionalBgView;
@property (nonatomic, strong) UILabel *exceptionalLab;
@property (nonatomic, strong) UILabel *networkLab;
@property (nonatomic, strong) UIButton *showFansListBtn;

// ----------- ID 信息区域
@property (nonatomic, strong) UIView *idBgView;
@property (nonatomic, strong) UILabel *idLab;

@property (nonatomic, assign) int time;

@end

@implementation HNLiveAnchorUserInfoView

- (instancetype)init
{
    self = [super init];
    if (self)
    {
        self.backgroundColor = [UIColor clearColor];
        
        [self setUI];
    }
    return self;
}

#pragma mark - privateMethod

- (void)setModel:(HNLiveAnchorModel *)model
{
    _model = model;
    
    [self.headerImg sd_setImageWithURL:[NSURL URLWithString:[HNTools pictureStr:model.avatar]] placeholderImage:DefaultHeaderImage];
 
    if (self.isAnchor)
    {
        // 主播端处理
        self.nameLab.hidden = YES;
        self.followsBtn.hidden = YES;
        
        self.redTimerView.hidden = NO;
        self.timerLab.hidden = NO;
        
        self.timerLab.text = @"00:00:00";
        
        self.idBgView.backgroundColor = [UIColor clearColor];
        self.idLab.shadowColor = UIColorFromHEXA(0x000000, 0.9);
        self.idLab.shadowOffset = CGSizeMake(0.5, 0.1);
                
        [self.headerBgView mas_remakeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_offset(kSpaceToLeftOrRight);
            make.top.mas_offset(kSpaceToLeftOrRight + 20);
            make.height.mas_offset(Handle_height(40));
            make.right.mas_equalTo(self.redTimerView.mas_right).mas_offset(Handle(75));
        }];
    }
    else
    {
        // 客户端显示主播信息
        self.redTimerView.hidden = YES;
        self.timerLab.hidden = YES;
        
        self.nameLab.hidden = NO;
        self.followsBtn.hidden = NO;
        
        self.nameLab.text = model.nick;
        
        if ([model.is_follow boolValue])
        {
            [self.followsBtn removeFromSuperview];
            [self.headerBgView mas_updateConstraints:^(MASConstraintMaker *make) {
                make.right.mas_equalTo(self.nameLab.mas_right).mas_offset(kSpaceToLeftOrRight * 2);
            }];
        }
    }
    
    [self layoutIfNeeded];

    self.idLab.text = [NSString stringWithFormat:@"%@：%@",kIDName,model.uid];
    
    // 打赏金额
    self.exceptionalLab.text = [NSString stringWithFormat:@"%@: %@",kDotName,model.total_dot];
}

- (void)setOnlines:(NSString *)onlines
{
    _onlines = onlines;
    self.personNumberLab.text = [NSString stringWithFormat:@"%@人",onlines];
}

- (void)setExceptionalMoney:(NSString *)exceptionalMoney
{
    _exceptionalMoney = exceptionalMoney;
     dispatch_async(dispatch_get_main_queue(), ^{
      self.exceptionalLab.text = [NSString stringWithFormat:@"%@：%@",kDotName, exceptionalMoney];
  });
}

- (void)setNetworkKBS:(NSString *)networkKBS
{
    _networkKBS = networkKBS;
    if (self.isAnchor == YES)
    {
        self.networkLab.text = [NSString stringWithFormat:@"↑%@",networkKBS];
    }
    else
    {
        self.networkLab.text = [NSString stringWithFormat:@"↓%@",networkKBS];
    }
}

- (void)startTimer
{
    _timer = 0;
    if (_timer == nil)
    {
        _timer = [NSTimer scheduledTimerWithTimeInterval:1.0 target:self selector:@selector(startTime) userInfo:nil repeats:YES];
    }
}

#pragma mark - 点击关注

- (void)followAnchorsClick
{
    if ([self.infoViewDelegate respondsToSelector:@selector(didClickFollowBtnWithAnchor:)])
    {
        [self.infoViewDelegate didClickFollowBtnWithAnchor:self.model.uid];
    }
}

// 点击关注成功后的处理
- (void)followAnchorSuccess
{
    [self.followsBtn removeFromSuperview];
    
    [UIView animateWithDuration:0.25 animations:^{
        
        [self.headerBgView mas_updateConstraints:^(MASConstraintMaker *make) {
            make.right.mas_equalTo(self.nameLab.mas_right).mas_offset(kSpaceToLeftOrRight * 2);
        }];
        
        [self layoutIfNeeded];
    }];
}

- (void)cancelFollowAnchor
{
    [self.headerBgView addSubview:self.followsBtn];
    
    [UIView animateWithDuration:0.25 animations:^{
        
        [self.followsBtn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(self.nameLab.mas_right).mas_offset(Handle(5));
            make.centerY.mas_equalTo(self.headerBgView);
            make.size.mas_equalTo(CGSizeMake(Handle_width(35), Handle_height(18)));
        }];
        
        [self.headerBgView mas_remakeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_offset(kSpaceToLeftOrRight);
            make.top.mas_offset(kSpaceToLeftOrRight + 20);
            make.height.mas_offset(Handle_height(40));
            make.right.mas_equalTo(self.followsBtn.mas_right).mas_offset(kSpaceToLeftOrRight).priorityHigh();
        }];
        
        [self layoutIfNeeded];
    }];
}

#pragma mark - 点击了头像

- (void)clickHeader
{
    if ([self.infoViewDelegate respondsToSelector:@selector(didClickHeaderWithAnchor:)])
    {
        [self.infoViewDelegate didClickHeaderWithAnchor:self.model.uid];
    }
}

#pragma mark - 点击查看粉丝贡献榜
- (void)showFansListBtnClick
{
    if ([self.infoViewDelegate respondsToSelector:@selector(didClickShowFansContributionList)])
    {
        [self.infoViewDelegate didClickShowFansContributionList];
    }
}

#pragma mark - 计时处理

- (void)startTime
{
    _time ++;
    NSString *timeStr = [HNTools changMinuteToTime:[NSString stringWithFormat:@"%d",_time]];
    self.timerLab.text = timeStr;
}

#pragma mark - setUI
- (void)setUI
{
    [self addSubview:self.headerBgView];
    [self.headerBgView addSubview:self.headerImg];
    [self.headerBgView addSubview:self.nameLab];
    [self.headerBgView addSubview:self.personNumberLab];
    [self.headerBgView addSubview:self.redTimerView];
    [self.headerBgView addSubview:self.timerLab];
    [self.headerBgView addSubview:self.followsBtn];
    
    [self addSubview:self.exceptionalBgView];
    [self.exceptionalBgView addSubview:self.exceptionalLab];
    [self.exceptionalBgView addSubview:self.showFansListBtn];
    
    [self addSubview:self.networkLab];
    [self addSubview:self.idBgView];
    [self addSubview:self.idLab];
    
    [self setMasonry];
}

- (void)setMasonry
{
    [self.headerBgView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_offset(kSpaceToLeftOrRight);
        make.top.mas_offset(kSpaceToLeftOrRight + 20);
        make.height.mas_offset(Handle_height(40));
        make.right.mas_equalTo(self.followsBtn.mas_right).mas_offset(kSpaceToLeftOrRight);
    }];
    
    [self.headerImg mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.top.mas_equalTo(self.headerBgView);
        make.size.mas_equalTo(CGSizeMake(Handle_width(40), Handle_width(40)));
    }];

    
    [self.nameLab mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(self.headerBgView.mas_top).mas_offset(Handle(8));
        make.left.mas_equalTo(self.headerImg.mas_right).mas_offset(Handle(7));
        make.width.mas_lessThanOrEqualTo(Handle_width(100));
    }];
    
    [self.personNumberLab mas_makeConstraints:^(MASConstraintMaker *make) {
        make.bottom.mas_equalTo(self.headerBgView.mas_bottom).mas_offset(SCREEN_WIDTH > 320 ? -Handle(6) : -Handle(3));
        make.left.mas_equalTo(self.headerImg.mas_right).mas_offset(Handle(7));
    }];
    
    [self.redTimerView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(self.headerImg.mas_right).mas_offset(Handle(5));
        make.top.mas_equalTo(self.headerBgView.mas_top).mas_offset(Handle(10));
        make.size.mas_equalTo(CGSizeMake(Handle(5), Handle_height(5)));
    }];
    
    [self.timerLab mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.mas_equalTo(self.redTimerView);
        make.left.mas_equalTo(self.redTimerView.mas_right).mas_offset(Handle(5));
    }];
    
    [self.followsBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(self.nameLab.mas_right).mas_offset(Handle(5));
        make.centerY.mas_equalTo(self.headerBgView);
        make.size.mas_equalTo(CGSizeMake(Handle_width(35), Handle_height(18)));
    }];
    
    [self.exceptionalLab mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_offset(Handle(5) + kSpaceToLeftOrRight);
        make.top.mas_equalTo(self.headerBgView.mas_bottom).mas_offset(Handle(7));
        make.height.mas_offset(Handle_height(24));
    }];
    
    [self.showFansListBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(self.exceptionalLab.mas_right).mas_offset(Handle(7));
        make.centerY.mas_equalTo(self.exceptionalLab);
    }];
    
    [self.exceptionalBgView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_offset(kSpaceToLeftOrRight);
        make.right.mas_equalTo(self.showFansListBtn.mas_right).mas_offset(Handle(3));
        make.top.mas_equalTo(self.headerBgView.mas_bottom).mas_offset(Handle(7));
        make.height.mas_offset(Handle_height(24));
    }];
    
    [self.networkLab mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(self.exceptionalBgView.mas_right).mas_offset(Handle(8));
        make.top.height.mas_equalTo(self.exceptionalLab);
    }];
    
    [self.idLab mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.mas_offset(-kSpaceToLeftOrRight);
        make.centerY.mas_equalTo(self.exceptionalBgView.mas_centerY);
        make.height.mas_offset(Handle_height(24));
    }];
    
    [self.idBgView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.centerX.height.mas_equalTo(self.idLab);
        make.width.mas_equalTo(self.idLab.mas_width).mas_offset(Handle(10));
    }];
    
    [self mas_updateConstraints:^(MASConstraintMaker *make) {
        make.bottom.mas_equalTo(self.exceptionalBgView.mas_bottom).mas_offset(Handle(10));
    }];
    
    [self layoutIfNeeded];
}

#pragma mark - getter

- (UIView *)headerBgView
{
    if(!_headerBgView)
    {
        _headerBgView = InsertView(nil, CGRectZero, UIColorFromHEXA(0x000000, 0.4));
        _headerBgView.layer.cornerRadius = Handle(20);
        _headerBgView.layer.masksToBounds = YES;
    }
    return _headerBgView;
}

- (UIImageView *)headerImg
{
    if(!_headerImg)
    {
        _headerImg = InsertImageView(nil, CGRectZero, DefaultHeaderImage);
        _headerImg.contentMode = UIViewContentModeScaleAspectFill;
        _headerImg.layer.cornerRadius = Handle_width(20);
        _headerImg.layer.masksToBounds = YES;
        
        UITapGestureRecognizer *ges = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(clickHeader)];
        [_headerImg addGestureRecognizer:ges];
    }
    return _headerImg;
}


- (UILabel *)nameLab
{
    if(!_nameLab)
    {
        _nameLab = InsertLabel(nil, CGRectZero, NSTextAlignmentLeft, @"", SystemFontSize10, [UIColor whiteColor]);
        _nameLab.lineBreakMode = NSLineBreakByTruncatingTail;
    }
    return _nameLab;
}

- (UILabel *)personNumberLab
{
    if(!_personNumberLab)
    {
        _personNumberLab = InsertLabel(nil, CGRectZero, NSTextAlignmentLeft, @"", SystemFontSize10, [UIColor whiteColor]);
    }
    return _personNumberLab;
}

- (UIView *)redTimerView
{
    if(!_redTimerView)
    {
        _redTimerView = InsertView(nil, CGRectZero, [UIColor redColor]);
        _redTimerView.layer.cornerRadius = Handle(2.5);
        _redTimerView.layer.masksToBounds = YES;
        
        _redTimerView.hidden = YES;
    }
    return _redTimerView;
}

- (UILabel *)timerLab
{
    if(!_timerLab)
    {
        _timerLab = InsertLabel(nil, CGRectZero, NSTextAlignmentLeft, @"", SystemFontSize12, [UIColor whiteColor]);
        
        _timerLab.hidden = YES;
    }
    return _timerLab;
}

- (UIButton *)followsBtn
{
    if(!_followsBtn)
    {
        _followsBtn = InsertTitleAndImageButton(nil, CGRectZero, 77, @"关注", UIEdgeInsetsZero, SystemFontSize12, [UIColor whiteColor], nil, nil, nil, self, @selector(followAnchorsClick));
        _followsBtn.backgroundColor = UIColorFromHEXA(0xF95172, 1.0);
        _followsBtn.layer.cornerRadius = Handle(9);
        _followsBtn.layer.masksToBounds = YES;
        
        _followsBtn.hidden = YES;
    }
    return _followsBtn;
}

- (UIView *)exceptionalBgView
{
    if(!_exceptionalBgView)
    {
        _exceptionalBgView = InsertView(nil, CGRectZero, UIColorFromHEXA(0x000000, 0.35));
        _exceptionalBgView.layer.cornerRadius = Handle(12);
        _exceptionalBgView.layer.masksToBounds = YES;
//        _exceptionalBgView.hidden=YES;
    }
    return _exceptionalBgView;
}

- (UILabel *)exceptionalLab
{
    if(!_exceptionalLab)
    {
        _exceptionalLab = InsertLabel(nil, CGRectZero, NSTextAlignmentLeft, @"", SystemFontSize14, [UIColor whiteColor]);
//        _exceptionalLab.hidden=YES;
    }
    return _exceptionalLab;
}

- (UILabel *)networkLab
{
    if(!_networkLab)
    {
        _networkLab = InsertLabel(nil, CGRectZero, NSTextAlignmentRight, @"", SystemFontSize14, [UIColor whiteColor]);
        _networkLab.hidden=YES;
    }
    return _networkLab;
}

- (UIButton *)showFansListBtn
{
    if(!_showFansListBtn)
    {
        _showFansListBtn = InsertImageButton(nil, CGRectZero, 77, GetImage(@"live_icon_fans"), nil, self, @selector(showFansListBtnClick));
//        _showFansListBtn.hidden=YES;
        [_showFansListBtn setEnlargeEdgeWithTop:10 right:10 bottom:10 left:150];
    }
    return _showFansListBtn;
}

- (UIView *)idBgView
{
    if(!_idBgView)
    {
        _idBgView = InsertView(nil, CGRectZero, UIColorFromHEXA(0x000000, 0.2));
        _idBgView.layer.cornerRadius = Handle(12);
        _idBgView.layer.masksToBounds = YES;
    }
    return _idBgView;
}

- (UILabel *)idLab
{
    if(!_idLab)
    {
        _idLab =  InsertLabelWithShadow(nil, CGRectZero, NSTextAlignmentCenter, @"", SystemFontSize12, [UIColor whiteColor], YES, UIColorFromHEXA(0x000000, 0.35), CGSizeMake(0.5, 0));
    }
    return _idLab;
}

@end
