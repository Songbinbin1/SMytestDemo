//
//  HNLiveAnchorUserInfoView.h
//  LiveShow
//
//  Created by Sunwanwan on 2017/8/30.
//  Copyright © 2017年 HN. All rights reserved.
//  直播间主播信息视图

#import <UIKit/UIKit.h>
#import "HNLiveAnchorModel.h"

@protocol HNLiveAnchorUserInfoViewDelegate <NSObject>

@optional
// 点击了关注按钮
- (void)didClickFollowBtnWithAnchor:(NSString *)anchorID;

// 点击了用户头像
- (void)didClickHeaderWithAnchor:(NSString *)anchorID;

// 点击了查看粉丝贡献榜
- (void)didClickShowFansContributionList;

@end

@interface HNLiveAnchorUserInfoView : UIView

@property (nonatomic, assign) id<HNLiveAnchorUserInfoViewDelegate> infoViewDelegate;
@property (nonatomic, strong) HNLiveAnchorModel *model;

@property (nonatomic, assign) BOOL isAnchor; // 是否是主播
@property (nonatomic, strong) NSTimer *timer;

@property (nonatomic, strong) NSString *onlines; // 在线人数
@property (nonatomic, strong) NSString *exceptionalMoney;  // 收益金额
@property (nonatomic, strong) NSString *networkKBS;  // 网速

@property (nonatomic, strong) UIView *headerBgView;  // 主播头像

// 关注主播成功后处理
- (void)followAnchorSuccess;

// 直播间用户取消对主播的关注
- (void)cancelFollowAnchor;

- (void)startTimer;

@end
