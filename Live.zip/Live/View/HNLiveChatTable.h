//
//  HNLiveChatTable.h
//  SunsetLive
//
//  Created by Sunwanwan on 2017/9/11.
//  Copyright © 2017年 HN. All rights reserved.
//  直播间里的聊天视图

#import <UIKit/UIKit.h>

@protocol HNLiveChatTableDelegate <NSObject>

@optional
- (void)showUserInfoCardWithUid:(NSString *)uid;

@end

@interface HNLiveChatTable : UITableView

@property (nonatomic, strong) NSArray *dataSourceArr;

@property (nonatomic, assign) id<HNLiveChatTableDelegate> tableDelegate;

+ (instancetype)liveChatTable;

@end
