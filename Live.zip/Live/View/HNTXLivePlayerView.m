//
//  HNTXLivePlayerView.m
//  SunsetLive
//
//  Created by Sunwanwan on 2017/10/11.
//  Copyright © 2017年 HN. All rights reserved.
//

#import "HNTXLivePlayerView.h"
#import <TXLivePlayer.h>
#import <AVFoundation/AVFoundation.h>
#import "HNHttpRequest.h"
@interface HNTXLivePlayerView () <TXLivePlayListener>
{
    TX_Enum_PlayType _playType;
    
    TXLivePlayConfig *_config;
    
    BOOL _appIsInterrupt;  // 是否被打断
    BOOL _appIsInActive;   // 是否处于前台
    BOOL _appIsBackground; // 是否进入后台
}

@property (nonatomic, strong) TXLivePlayer *livePlayer;

@end

@implementation HNTXLivePlayerView

+ (instancetype)livePlayerView
{
    HNTXLivePlayerView *view = [[HNTXLivePlayerView alloc] init];
    return view;
}

- (id)init
{
    self = [super init];
    if (self)
    {
        self.frame = CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT);
        [self initPullFlowOption];
    }
    return self;
}

- (void)dealloc
{
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

#pragma mark --------------  腾讯云播放SDK -------------

- (void)initPullFlowOption
{
    self.livePlayer = [[TXLivePlayer alloc] init];
    
    self.livePlayer.enableHWAcceleration = YES;  // 开启硬件加速
    
    // 添加系统通知
    [self addNSNotification];

}

-(void)colseBtnAction{
    
    HNAlertView *view = [[HNAlertView alloc] initWithTitle:nil Content:@"确定要关闭该连麦吗？" whitTitleArray:@[@"取消",@"确定"] withType:@"center"];
     _weakself;
    [view showAlertView:^(NSInteger index) {
        if (index == 1)
        {
            [HNHttpRequest  userCancelFlowWithUid:kUserID gid:self.uid Success:^(id responseObject) {
                _strongSelf;
                [strongSelf stopPlay];
                [strongSelf removeFromSuperview];
                if (strongSelf.colseBlock) {
                    strongSelf.colseBlock();
                }
            } failure:^(NSError *error) {
                
            }];
        }
    }];
   

    
}
#pragma mark - 对拉流的操作

- (void)startPlay
{
    if (self.colseBlock) {
        UIButton    *colseBtn=[[UIButton alloc]init];
        colseBtn.frame=CGRectMake(self.width-40, 0, 40, 40);
        [colseBtn setImage:[UIImage imageNamed:@"tuichu_liaotian"] forState:UIControlStateNormal];
        [colseBtn addTarget:self action:@selector(colseBtnAction) forControlEvents:UIControlEventTouchUpInside];
        [self addSubview:colseBtn];
    }
    if (![self checkPlayUrl:self.rtmpURL])
    {
        [MBProgressHUD showError:@"播放地址不合法，还不能播放哦"];
        return;
    }
    
    if (self.livePlayer != nil)
    {
        self.livePlayer.delegate = self;
        [self.livePlayer setupVideoWidget:self.bounds containView:self insertIndex:0];
    }
    
    if (_config == nil)
    {
        _config = [[TXLivePlayConfig alloc] init];
        _config.connectRetryCount = 3; // 播放器重连次数
        _config.connectRetryInterval = 10; // 播放器重连时间间隔
        _config.enableAEC = YES;  // 开启回声消除
        
        // 播放模式设置为极速模式 （极速模式跟自动模式的差异只是MaxCacheTime的值不同。 自动模式下MaxCacheTime会设置的相对较高点，MaxCacheTime反应的是调节速度：值越大， 调节速度会越发保守，卡顿概率会越低）
        _config.bAutoAdjustCacheTime = YES;
        [_config setMaxAutoAdjustCacheTime:1];
        [_config setMinAutoAdjustCacheTime:1];
    }
    
    [self.livePlayer setConfig:_config];
    if(self.rtmpURL){
        
    }

    // 启动播放
    int result = [self.livePlayer startPlay:self.rtmpURL type:_playType];
    if( result!=0)
    {
        NSLog(@"播放器启动失败");
        return;
    }
}

- (void)stopPlay
{
    self.rtmpURL = @"";
    if (self.livePlayer !=nil)
    {
        [self.livePlayer stopPlay];
        [self.livePlayer removeVideoWidget];
        self.livePlayer.delegate = nil;
    }
}

- (void)pausePlay
{
    if([self.livePlayer isPlaying]){
        [self.livePlayer pause];
    }
   
}
- (void)resumePlay
{
//    if([self.livePlayer isPlaying]){
        [self.livePlayer resume];
//    }
    
}
#pragma mark - 监听拉流相关事件

- (void)onPlayEvent:(int)EvtID withParam:(NSDictionary *)param
{
    NSDictionary* dict = param;
    
    dispatch_async(dispatch_get_main_queue(), ^{
        
         if (EvtID == PLAY_EVT_RCV_FIRST_I_FRAME)
         {
             // 网络接收到首个可渲染的视频数据包(IDR)
             if ([self.livePlayer isPlaying] == NO)
             {
                [self.livePlayer setupVideoWidget:self.bounds containView:self insertIndex:0];
             }
         }
        
        if (EvtID == PLAY_EVT_CONNECT_SUCC)
        {
            // 已经连接服务器
            // 在这里可以进行一些网络的判断， 比如是否是wifi
        }
        else if (EvtID == PLAY_ERR_NET_DISCONNECT)
        {
            // 网络断连,且经多次重连抢救无效,可以放弃治疗
            [self stopPlay];
            
            [[NSNotificationCenter defaultCenter] postNotificationName:@"PlayReconteactFaild" object:nil];
        }
        else if (EvtID == PLAY_EVT_PLAY_BEGIN)
        {
            // 视频开始播放
            [[NSNotificationCenter defaultCenter] postNotificationName:@"PLPlayerStatusPlaying" object:nil];
        }
        else if (EvtID == PLAY_EVT_PLAY_END)
        {
            // 视频播放结束
            [self stopPlay];
        }
        else if (EvtID == PLAY_WARNING_RECV_DATA_LAG || EvtID == PLAY_WARNING_VIDEO_PLAY_LAG)
        {
            // 网络来包不稳：可能是下行带宽不足，或由于主播端出流不均匀 || 当前视频播放出现卡顿            
            [MBProgressHUD showError:@"您当前的网络环境不佳哦~"];
        }
        
        long long time = [(NSNumber *) [dict valueForKey:EVT_TIME] longLongValue];
        int mil = (int) (time % 1000);
        NSDate *date = [NSDate dateWithTimeIntervalSince1970:time / 1000];
        NSString *Msg = (NSString *) [dict valueForKey:EVT_MSG];
        [self appendLog:Msg time:date mills:mil];
    });
}

- (void)onNetStatus:(NSDictionary *)param
{
    NSDictionary* dict = param;
    
    // 拉流实时信息回调 --------
    
    dispatch_async(dispatch_get_main_queue(), ^{
        float netspeed  = [(NSNumber*)[dict valueForKey:NET_STATUS_NET_SPEED] floatValue] / 8;
       
        NSString *SPD = [NSString stringWithFormat:@"%.2fKB/s",netspeed];
        if (self.netStatusBlock)
        {
            self.netStatusBlock(SPD);
        }
    });

}

#pragma mark - 通知

- (void)addNSNotification
{
    // 监听系统的打断事件
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(onAudioSessionEvent:) name:AVAudioSessionInterruptionNotification object:nil];
    
    // 程序进入后台
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(onAppDidEnterBackGround:) name:UIApplicationDidEnterBackgroundNotification object:nil];
    
    // 程序将要进入前台
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(onAppWillEnterForeground:) name:UIApplicationWillEnterForegroundNotification object:nil];
    
    // 程序进入前台，并处于活动状态
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(onAppDidBecomeActive:) name:UIApplicationDidBecomeActiveNotification object:nil];
}

- (void) onAudioSessionEvent: (NSNotification *) notification
{
    NSDictionary *info = notification.userInfo;
    AVAudioSessionInterruptionType type = [info[AVAudioSessionInterruptionTypeKey] unsignedIntegerValue];
    
    if (type == AVAudioSessionInterruptionTypeBegan)
    {
        _appIsInterrupt = YES;
        [self.livePlayer pause];
        
        // 设置静音
        [self.livePlayer setMute:YES];
    }
   
    if (type == AVAudioSessionInterruptionOptionShouldResume)
    {
        // 收到该事件不能调用resume，因为此时可能还在后台
    }
    
    if (type == AVAudioSessionInterruptionTypeEnded)
    {
        _appIsInterrupt = NO;
        if (!_appIsBackground && !_appIsInActive && !_appIsInterrupt)
        {
            [self.livePlayer resume];
            
            // 恢复静音
            [self.livePlayer setMute:NO];
            NSLog(@"AVAudioSessionInterruptionTypeEnd");
        }
    }
}

- (void)onAppDidEnterBackGround:(UIApplication*)app
{
    _appIsBackground = YES;
    [self.livePlayer pause];
}

- (void)onAppWillEnterForeground:(NSNotification *)notification
{
    _appIsBackground = NO;
    if (!_appIsBackground && !_appIsInActive && !_appIsInterrupt)
    {
        [self.livePlayer resume];
    }
}

- (void)onAppDidBecomeActive:(UIApplication*)app
{
    _appIsInterrupt = NO;
    if (!_appIsBackground && !_appIsInActive && !_appIsInterrupt)
    {
        [self.livePlayer resume];
    }
}

#pragma mark - privateMethod

- (BOOL)checkPlayUrl:(NSString *)playUrl
{
    if ([playUrl hasPrefix:@"rtmp:"])
    {
        _playType = PLAY_TYPE_LIVE_RTMP;
    }
    else if (([playUrl hasPrefix:@"https:"] || [playUrl hasPrefix:@"http:"]) && [playUrl rangeOfString:@".flv"].length > 0)
    {
        _playType = PLAY_TYPE_LIVE_FLV;
    }
    else
    {
        NSLog(@"播放地址不合法，直播目前仅支持rtmp,flv播放方式!");
        return NO;
    }
    
    if ([playUrl hasPrefix:@"https:"] || [playUrl hasPrefix:@"http:"])
    {
        if ([playUrl rangeOfString:@".flv"].length > 0)
        {
            _playType = PLAY_TYPE_VOD_FLV;
        }
        else if ([playUrl rangeOfString:@".m3u8"].length > 0)
        {
            _playType= PLAY_TYPE_VOD_HLS;
        }
        else if ([playUrl rangeOfString:@".mp4"].length > 0)
        {
            _playType= PLAY_TYPE_VOD_MP4;
        }
        else
        {
            NSLog(@"播放地址不合法，点播目前仅支持flv,hls,mp4播放方式!");
            return NO;
        }
    }
    
    return YES;
}

- (void)appendLog:(NSString *)evt time:(NSDate *)date mills:(int)mil
{
    NSDateFormatter *format = [[NSDateFormatter alloc] init];
    format.dateFormat = @"hh:mm:ss";
    NSString *time = [format stringFromDate:date];
    NSString *log = [NSString stringWithFormat:@"[%@.%-3.3d] %@", time, mil, evt];
    NSLog(@"log：%@",log);
}

// 是否是点播
-(BOOL)isVODType:(int)playType
{
    if (playType == PLAY_TYPE_VOD_FLV || playType == PLAY_TYPE_VOD_HLS || playType == PLAY_TYPE_VOD_MP4 || playType == PLAY_TYPE_LOCAL_VIDEO)
    {
        return YES;
    }
    
    return NO;
}

@end
