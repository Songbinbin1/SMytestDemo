//
//  HNLiveChatTable.m
//  SunsetLive
//
//  Created by Sunwanwan on 2017/9/11.
//  Copyright © 2017年 HN. All rights reserved.
//

#import "HNLiveChatTable.h"
#import "HNLiveChatCell.h"

@interface HNLiveChatTable () <UITableViewDelegate, UITableViewDataSource, HNLiveChatCellDelegate>
@end

@implementation HNLiveChatTable

+ (instancetype)liveChatTable
{
    return [[self alloc] initWithFrame:CGRectZero style:UITableViewStylePlain];
}

- (id)initWithFrame:(CGRect)frame style:(UITableViewStyle)style
{
    self = [super initWithFrame:frame style:style];
    if (self)
    {
        self.backgroundColor = CString(WhiteColor);
        self.separatorStyle = UITableViewCellSeparatorStyleNone;
        UIView *view=[[UIView alloc]initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, 10)];
        view.backgroundColor=[UIColor clearColor];
        self.tableFooterView=view;
        self.showsVerticalScrollIndicator = NO;
        self.delegate = self;
        self.dataSource = self;
    }
    
    return self;
}



#pragma mark - UITableViewDelegate

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.dataSourceArr.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *reuseID = @"chatCell";
    
    HNLiveChatCell *cell = [tableView dequeueReusableCellWithIdentifier:reuseID];
   
    if (!cell)
    {
        cell = [[HNLiveChatCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:reuseID];
        
    }
    
    cell.delegate = self;
    
    if (self.dataSourceArr.count > 0)
    {
        cell.msgModel = self.dataSourceArr[indexPath.row];
    }
    NSLog(@"address --- %p ----- 第%ld行",cell, (long)indexPath.row);
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
//    HNLiveChatCell *cell = (HNLiveChatCell *)[self tableView:tableView cellForRowAtIndexPath:indexPath];
    HNLiveChatMsgModel *model=self.dataSourceArr[indexPath.row];
    return model.cellHeight+Handle(10);
}

#pragma mark - HNLiveChatCellDelegate

- (void)didClickNickWithUid:(NSString *)uid
{
    if ([self.tableDelegate respondsToSelector:@selector(showUserInfoCardWithUid:)])
    {
        [self.tableDelegate showUserInfoCardWithUid:uid];
    }
}


@end
