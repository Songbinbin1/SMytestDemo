//
//  HNLiveChatTools.h
//  SunsetLive
//
//  Created by Sunwanwan on 2017/9/15.
//  Copyright © 2017年 HN. All rights reserved.
//  直播间聊天工具栏

#import <UIKit/UIKit.h>
#import "EmojiScrollView.h"

@class HNLiveChatToolsView;
@protocol HNLiveChatToolsDelegate <NSObject>

@optional

// text
- (void)inputFuntionView:(HNLiveChatToolsView *)toolsView sendMessage:(NSString *)message barrageBtnSelect:(BOOL)isSelect;

// 点击表情按钮
- (void)didClickEmojiBtnWithBtn:(UIButton *)emojiBtn;

@end

@interface HNLiveChatToolsView : UIView

- (id)initWithSuperView:(UIView *)superView;

// 聊天输入框
@property (nonatomic, strong) UITextField *inputTextField;

// 表情按钮
@property (nonatomic, strong) UIButton *emojiBtn;

// 表情键盘
@property (nonatomic, strong) EmojiScrollView *emojiScrollView;

// 能否删除表情
@property (nonatomic, assign) BOOL isFaceDel;

// 弹幕价格
@property (nonatomic, strong) NSString *barragePrice;

@property (nonatomic, assign) id<HNLiveChatToolsDelegate> toolsDelegate;


@end
