//
//  HNEnterRoomView.m
//  SunsetLive
//
//  Created by Sunwanwan on 2017/9/18.
//  Copyright © 2017年 HN. All rights reserved.
//

#import "HNEnterRoomView.h"

@interface HNEnterRoomView ()

@property (nonatomic, strong) UIImageView *bgImg;
@property (nonatomic, strong) UIButton *levelBtn;
@property (nonatomic, strong) UILabel *msgLab;

@end

@implementation HNEnterRoomView

+ (instancetype)enterRoomView
{
    HNEnterRoomView *enterView = [[HNEnterRoomView alloc] init];
    return enterView;
}

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self)
    {
        [self setUI];
    }
    return self;
}

#pragma mark - privateMethod

- (void)setMsgModel:(HNLiveChatMsgModel *)msgModel
{
    _msgModel = msgModel;
    
    [self.levelBtn setTitle:msgModel.level forState:UIControlStateNormal];
    [self.levelBtn setBackgroundImage:[HNTools returnBackgroundImageNameWithLevel:msgModel.level] forState:UIControlStateNormal];
    
    self.msgLab.text = [NSString stringWithFormat:@"%@ %@",msgModel.nick,@"进入了房间"];
}

#pragma mark - setUI

- (void)setUI
{
    [self addSubview:self.bgImg];
    [self addSubview:self.levelBtn];
    [self addSubview:self.msgLab];
    
    [self.bgImg mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.mas_equalTo(self);
    }];
    
    [self.levelBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_offset(kSpaceToLeftOrRight);
        make.centerY.mas_equalTo(self.mas_centerY);
        make.size.mas_equalTo(CGSizeMake(Handle_width(60 / 2), Handle_height(13)));
    }];
    
    [self.msgLab mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.mas_equalTo(self.mas_centerY);
        make.left.mas_equalTo(self.levelBtn.mas_right).mas_offset(Handle(10));
    }];
}

#pragma mark - getter

- (UIImageView *)bgImg
{
    if(!_bgImg)
    {
        _bgImg = InsertImageView(nil, CGRectZero, GetImage(@"enterRoom"));
    }
    return _bgImg;
}

- (UIButton *)levelBtn
{
    if(!_levelBtn)
    {
        _levelBtn = InsertTitleAndImageButton(nil, CGRectZero, 99, @"", UIEdgeInsetsZero, SystemFontSize10, [UIColor whiteColor], nil, nil, nil, self, nil);
        [_levelBtn setImage:GetImage(@"start_level") forState:UIControlStateNormal];
        [_levelBtn setBackgroundImage:GetImage(@"level_user_bg") forState:UIControlStateNormal];
        _levelBtn.layer.cornerRadius = Handle(2);
        _levelBtn.layer.masksToBounds = YES;
        _levelBtn.titleEdgeInsets = UIEdgeInsetsMake(0, Handle(5), 0, 0);
    }
    return _levelBtn;
}

- (UILabel *)msgLab
{
    if(!_msgLab)
    {
        _msgLab = InsertLabel(nil, CGRectZero, NSTextAlignmentLeft, @"", SystemFontSize15, [UIColor whiteColor]);
    }
    return _msgLab;
}

@end
