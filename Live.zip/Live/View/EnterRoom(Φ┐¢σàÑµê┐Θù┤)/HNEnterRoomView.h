//
//  HNEnterRoomView.h
//  SunsetLive
//
//  Created by Sunwanwan on 2017/9/18.
//  Copyright © 2017年 HN. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "HNLiveChatMsgModel.h"

@interface HNEnterRoomView : UIView

@property (nonatomic, strong) HNLiveChatMsgModel *msgModel;

+ (instancetype)enterRoomView;

@end
