//
//  HNEnterOperaTion.m
//  VeraShow
//
//  Created by 小兵 on 16/10/23.
//  Copyright © 2016年 Red-bird-OfTMZ. All rights reserved.
//

#import "HNEnterOperaTion.h"
#import "HNEnterRoomView.h"

@interface HNEnterOperaTion ()

@property (nonatomic, strong) HNLiveChatMsgModel* msgModel;
@property (nonatomic, strong) UIView* parentView;

@property (nonatomic, strong) HNEnterRoomView* flyView;
@end
@implementation HNEnterOperaTion

+ (instancetype)enterRoomWithModel:(HNLiveChatMsgModel *)msgModel parentView:(UIView *)scrollerView
{
    HNEnterOperaTion* op = [[HNEnterOperaTion alloc]init];
    op.msgModel = msgModel;
    op.parentView = scrollerView;
    return op;
}

- (void)main {
    
    @autoreleasepool {
        dispatch_async(dispatch_get_main_queue(), ^{
            [self.parentView addSubview:self.flyView];
            
            self.flyView.frame =CGRectMake(-SCREEN_WIDTH, SCREEN_HEIGHT - Handle(275), Handle_width(512 / 2), Handle_height(74 / 2));
            self.flyView.msgModel =self.msgModel;
            
            [UIView animateWithDuration:1.5 animations:^{
                
                self.flyView.transform = CGAffineTransformMakeTranslation(SCREEN_WIDTH, 0);
                
            } completion:^(BOOL finished) {
                
                dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                    
                    [UIView animateWithDuration:1 animations:^{
                        self.flyView.alpha = 0;
                        self.flyView.transform = CGAffineTransformMakeTranslation(SCREEN_WIDTH, -Handle_height(74 / 2));
                        
                    } completion:^(BOOL finished) {
                        
                        [self.flyView removeFromSuperview];
                        self.flyView = nil;
                    }];
                });
              
            }];
        });
        
        [NSThread sleepForTimeInterval:10.5];
    }
}

#pragma mark - getter
- (HNEnterRoomView *)flyView
{
    if (!_flyView)
    {
        _flyView= [HNEnterRoomView enterRoomView];
    }
    return _flyView;
}
@end
