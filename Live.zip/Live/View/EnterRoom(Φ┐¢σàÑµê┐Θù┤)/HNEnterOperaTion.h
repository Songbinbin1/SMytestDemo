//
//  HNEnterOperaTion.h
//  VeraShow
//
//  Created by 小兵 on 16/10/23.
//  Copyright © 2016年 Red-bird-OfTMZ. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "HNLiveChatMsgModel.h"

@interface HNEnterOperaTion : NSOperation

+ (instancetype) enterRoomWithModel:(HNLiveChatMsgModel*) msgModel parentView:(UIView*) scrollerView;

@end
