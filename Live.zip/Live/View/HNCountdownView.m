//
//  HNCountdownView.m
//  SunsetLive
//
//  Created by Sunwanwan on 2017/10/31.
//  Copyright © 2017年 HN. All rights reserved.
//

#import "HNCountdownView.h"

@interface HNCountdownView ()

@property (nonatomic, strong) UILabel *descLab;
@property (nonatomic, strong) UILabel *timeLab;

@end

@implementation HNCountdownView

- (id)init
{
    self = [super init];
    if (self)
    {
        self.backgroundColor = UIColorFromHEXA(0x1F1F1F, 0.9);
        
        [self setUI];
    }
    return self;
}

#pragma mark - privateMethod

- (void)setLiveType:(NSString *)liveType
{

        self.descLab.text = @"当前直播";
  
}

- (void)setCountDownTime:(NSInteger)countDownTime
{
    NSString *string = [NSString stringWithFormat:@"%ld S",(long)countDownTime];
    self.timeLab.attributedText = [HNTools getAttributedString:string withStringAttributedDic:@{NSForegroundColorAttributeName : BtnBgColor} withSubString:@"S" withSubStringAttributeDic:@{NSForegroundColorAttributeName : [UIColor whiteColor]}];
}

#pragma mark - setUI

- (void)setUI
{
    [self addSubview:self.descLab];
    [self addSubview:self.timeLab];
    
    [self.descLab mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_offset(kSpaceToLeftOrRight);
        make.centerY.mas_equalTo(self.centerY);
    }];
    
    [self.timeLab mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(self.descLab.mas_right);
        make.centerY.mas_equalTo(self.centerY);
    }];
}

#pragma mark - getter

- (UILabel *)descLab
{
    if(!_descLab)
    {
        _descLab = InsertLabel(nil, CGRectZero, NSTextAlignmentLeft, @"", SystemFontSize15, [UIColor whiteColor]);
    }
    return _descLab;
}

- (UILabel *)timeLab
{
    if(!_timeLab)
    {
        _timeLab = InsertLabel(nil, CGRectZero, NSTextAlignmentLeft, @"", SystemFontSize15, [UIColor whiteColor]);
    }
    return _timeLab;
}

@end
