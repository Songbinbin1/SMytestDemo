//
//  HNGiftView.h
//  SunsetLive
//
//  Created by Sunwanwan on 2017/11/14.
//  Copyright © 2017年 HN. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "HNGiftListModel.h"

@interface HNGiftView : UIView

@property (nonatomic, strong) UIButton *clickBtn;

@property (nonatomic, strong) HNGiftListModel *model;

@property (nonatomic, assign) BOOL selected;

@end
