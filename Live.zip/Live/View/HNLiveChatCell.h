//
//  HNLiveChatCell.h
//  SunsetLive
//
//  Created by Sunwanwan on 2017/9/11.
//  Copyright © 2017年 HN. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "HNLiveChatMsgModel.h"

@protocol HNLiveChatCellDelegate <NSObject>

@optional
- (void)didClickNickWithUid:(NSString *)uid;

@end

@interface HNLiveChatCell : UITableViewCell

@property (nonatomic, strong) HNLiveChatMsgModel *msgModel;

@property (nonatomic, assign) id<HNLiveChatCellDelegate> delegate;

- (CGFloat)cellHeight:(NSInteger)index;
@end
