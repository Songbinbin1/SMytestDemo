//
//  HNSelectPushOrVideo.h
//  SunsetLive
//
//  Created by 宋彬彬 on 2018/4/28.
//  Copyright © 2018年 HN. All rights reserved.
//

#import <UIKit/UIKit.h>
typedef void(^LiveBtnBlock)(void);
typedef void(^VideoBtnBlock)(void);
typedef void(^ArticleBtnBlock)(void);
@interface HNSelectPushOrVideo : UIView
@property (weak, nonatomic) IBOutlet UIView *bgView;

@property (weak, nonatomic) IBOutlet UIView *btnBgView;
@property (weak, nonatomic) IBOutlet UIButton *liveBtn;
@property (weak, nonatomic) IBOutlet UIButton *videoBtn;
@property (weak, nonatomic) IBOutlet UIButton *closeBtn;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *bgViewHeight;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *btnBgViewTop;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *bgViewBottom;
@property (weak, nonatomic) IBOutlet UIButton *articleBtn;

@property (weak, nonatomic) IBOutlet NSLayoutConstraint *bgViewheight;
@property(copy,nonatomic) LiveBtnBlock liveBtnBlock;
@property(copy,nonatomic) VideoBtnBlock videoBtnBlock;
@property(copy,nonatomic) ArticleBtnBlock articleBtnBlock;
+(instancetype) initHNSelectPushOrVideo;
-(void)showSelectView:(UIView *)view;
@end
