//
//  HNLiveChatTools.m
//  SunsetLive
//
//  Created by Sunwanwan on 2017/9/15.
//  Copyright © 2017年 HN. All rights reserved.
//

#import "HNLiveChatToolsView.h"
#import "NaturalData.h"

@interface HNLiveChatToolsView () <emojiScrollViewDelegate, UITextFieldDelegate, UIScrollViewDelegate>

@property (nonatomic, strong) UIView *bgView;

// 弹幕按钮
@property (nonatomic, strong) UIButton *barrageBtn;

// 聊天框容器
@property (nonatomic, strong) UIView *containerView;

// 发送按钮
@property (nonatomic, strong) UIButton *sendBtn;

@end

@implementation HNLiveChatToolsView

- (id)initWithSuperView:(UIView *)superView
{
    CGRect frame = CGRectMake(0, SCREEN_HEIGHT, SCREEN_WIDTH, LiveChatToolsHeight);
    
    self = [super initWithFrame:frame];
    if (self)
    {
        [self setUI];
        
        [superView addSubview:self.emojiScrollView];
    }
    return self;
}

#pragma mark - 点击弹幕按钮

- (void)barrageBtnclick:(UIButton *)btn
{
    btn.selected = !btn.selected;
    
    if (btn.selected)
    {
        self.inputTextField.placeholder = [NSString stringWithFormat:@"%@%@/条",self.barragePrice,kCoinName];
    }
    else
    {
        self.inputTextField.placeholder = @"输入聊天内容";
    }
}

#pragma mark - 点击发送按钮

- (void)sendBtnClick
{
    if (self.inputTextField.text.length == 0)
    {
        return;
    }
    
    NSString *resultStr = [self.inputTextField.text stringByReplacingOccurrencesOfString:@"   " withString:@""];
    if ([self.toolsDelegate respondsToSelector:@selector(inputFuntionView:sendMessage:barrageBtnSelect:)])
    {
        [self.toolsDelegate inputFuntionView:self sendMessage:resultStr barrageBtnSelect:self.barrageBtn.selected];
    }
    
    self.inputTextField.text = @"";
    
}

#pragma mark - 点击表情按钮

- (void)emojiBtnClick:(UIButton *)btn
{
    btn.selected = !btn.selected;
    
    if ([self.toolsDelegate respondsToSelector:@selector(didClickEmojiBtnWithBtn:)])
    {
        [self.toolsDelegate didClickEmojiBtnWithBtn:btn];
    }
}

#pragma mark - emojiScrollViewDelegate

- (void)deleteTap:(UITapGestureRecognizer*)tap
{
    DLog(@"删除");
    [self deleteString];
}

// emojiDelegate
- (void)deleteString
{
    NSString *nameStr = @"[删除]";
    [self faceClick:nameStr andFaceNumber:0];
}

//选择表情
- (void)emojiSelcet:(NSInteger)numface
{
    NSString *faceName =[[NaturalData shareInStance].faceArray objectAtIndex:numface];
    [self faceClick:faceName andFaceNumber:numface];
}

//点击对应下标的表情
-(void)faceClick:(NSString *)faceName andFaceNumber:(NSInteger)number
{
    if ([faceName isEqualToString:@"[删除]"])
    {
        self.isFaceDel = YES;
        [self textField:self.inputTextField shouldChangeCharactersInRange:NSMakeRange(self.inputTextField.text.length - 1, 1) replacementString:@""];
    }
    else if ([faceName isEqualToString:@"[发送]"])
    {
        
    }
    else
    {
        self.inputTextField.text = [self.inputTextField.text stringByAppendingString:faceName];
    }
}

#pragma mark - UITextFieldDelegate

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    if ([string isEqualToString:@"\n"])
    {
        return NO;
    }
    
    //对于退格删除键开放限制
    if (string.length == 0) {
        //判断删除的文字是否符合表情文字规则
        NSString *deleteText = [textField.text substringWithRange:range];
        NSUInteger location = range.location;
        NSUInteger length = range.length;
        
        if ([deleteText isEqualToString:@"]"]){
            NSString *subText;
            while (YES) {
                if (location == 0) {
                    return YES;
                }
                location -- ;
                length ++ ;
                subText = [textField.text substringWithRange:NSMakeRange(location, length)];
                if (([subText hasPrefix:@"["] && [subText hasSuffix:@"]"])) {
                    break;
                }
            }
            textField.text = [textField.text stringByReplacingCharactersInRange:NSMakeRange(location, length) withString:@""];

            return NO;
        }else{
            if (self.isFaceDel ==YES) {
                NSLog(@"deleteText:%@",deleteText);
                if (textField.text.length!=0) {
                    
                    textField.text = [textField.text stringByReplacingCharactersInRange:range withString:@""];
                }
            }
            self.isFaceDel = NO;
        }
    }
    
    return YES;
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField

{
     [textField resignFirstResponder];
    return YES;
    
}
#pragma mark - setUI

- (void)setUI
{
    [self addSubview:self.bgView];
    [self.bgView addSubview:self.barrageBtn];
    [self.bgView addSubview:self.sendBtn];
    [self.bgView addSubview:self.containerView];
    [self.containerView addSubview:self.emojiBtn];
    [self.containerView addSubview:self.inputTextField];
    
    [self.barrageBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.mas_equalTo(self.bgView.mas_centerY);
        make.left.mas_offset(kSpaceToLeftOrRight);
        make.size.mas_equalTo(CGSizeMake(Handle_width(148 / 2), Handle_height(44)));
    }];
    
    [self.sendBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.mas_equalTo(self.bgView.mas_centerY);
        make.right.mas_offset(-kSpaceToLeftOrRight);
        make.size.mas_equalTo(CGSizeMake(Handle_width(60), Handle_height(45)));
    }];
    
    [self.containerView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(self.barrageBtn.mas_right).mas_offset(Handle(6));
        make.right.mas_equalTo(self.sendBtn.mas_left).mas_offset(-Handle(6));
        make.centerY.mas_equalTo(self.bgView.mas_centerY);
        make.height.mas_offset(Handle_height(44));
    }];
    
    [self.emojiBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.mas_offset(-Handle(16));
        make.centerY.mas_equalTo(self.containerView.mas_centerY);
        make.size.mas_equalTo(CGSizeMake(Handle_width(24), Handle_height(24)));
    }];
    
    [self.inputTextField mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_offset(Handle(6));
        make.right.mas_equalTo(self.emojiBtn.mas_left).mas_offset(-Handle(16));
        make.height.mas_offset(Handle_height(35));
        make.centerY.mas_equalTo(self.containerView.mas_centerY);
    }];
}

#pragma mark - getter

- (UIView *)bgView
{
    if(!_bgView)
    {
        _bgView = InsertView(nil, self.bounds, UIColorFromHEXA(0xF8F8F8, 0.6));
        _bgView.layer.borderColor = CString(LineColor).CGColor;
        _bgView.layer.borderWidth = Handle(0.5);
    }
    return _bgView;
}

- (UIButton *)barrageBtn
{
    if(!_barrageBtn)
    {
        _barrageBtn = InsertImageButton(nil, CGRectZero, 88, GetImage(@"hanhua"), nil, self, @selector(barrageBtnclick:));
        [_barrageBtn setBackgroundImage:GetImage(@"hanhua_noselect") forState:UIControlStateSelected];
        _barrageBtn.selected = NO;
    }
    return _barrageBtn;
}

- (UIView *)containerView
{
    if(!_containerView)
    {
        _containerView = InsertView(nil, CGRectZero, UIColorFromHEXA(0xFFFFFF, 0.6));
        _containerView.layer.borderColor = CString(SubtitleColor).CGColor;
        _containerView.layer.borderWidth = Handle(0.5);
        _containerView.layer.cornerRadius = Handle(6);
        _containerView.layer.masksToBounds = YES;
    }
    return _containerView;
}

- (UITextField *)inputTextField
{
    if (!_inputTextField)
    {
        _inputTextField = InsertTextField(nil, self, CGRectZero, @"请输入聊天", SystemFontSize14, NSTextAlignmentLeft, UIControlContentVerticalAlignmentCenter);
        _inputTextField.textColor = UIColorFromHEXA(0x333333, 1.0);
       _inputTextField.returnKeyType = UIReturnKeyDone;
    }
    
    return _inputTextField;
}

- (UIButton *)emojiBtn
{
    if(!_emojiBtn)
    {
        _emojiBtn = InsertImageButton(nil, CGRectZero, 99, GetImage(@"smile"), nil, self, @selector(emojiBtnClick:));
    }
    return _emojiBtn;
}

- (UIButton *)sendBtn
{
    if(!_sendBtn)
    {
        _sendBtn = InsertTitleAndImageButton(nil, CGRectZero, 999, @"发送", UIEdgeInsetsZero, SystemFontSize14, [UIColor whiteColor], nil, nil, nil, self, @selector(sendBtnClick));
        _sendBtn.backgroundColor = BtnBgColor;
        
        _sendBtn.layer.cornerRadius = Handle(6);
        _sendBtn.layer.masksToBounds = YES;
    }
    return _sendBtn;
}

- (EmojiScrollView *)emojiScrollView
{
    if (!_emojiScrollView)
    {
        _emojiScrollView = [EmojiScrollView shareEmojiScrollView];
        _emojiScrollView.emojiDelegate = self;
    }
    return _emojiScrollView;
}

@end
