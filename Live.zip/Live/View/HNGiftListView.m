//
//  HNGiftListView.m
//  SunsetLive
//
//  Created by Sunwanwan on 2017/9/13.
//  Copyright © 2017年 HN. All rights reserved.
//

#import "HNGiftListView.h"
#import "HNGiftView.h"
#import "AppDelegate.h"
#define PIC_Width  SCREEN_WIDTH / 4
#define PIC_Height Handle_height(206 / 2)
#define COL_Count  4

@interface HNGiftListView () < UICollectionViewDelegateFlowLayout>

@property (nonatomic, strong) UIView *bgView;
@property (nonatomic, strong) UIScrollView *mainScrollView;
@property (nonatomic, strong) UIPageControl *pageControl;
@property (nonatomic, strong) UILabel *coinLab;
@property (nonatomic, strong) UIButton *rechargeBtn;  // 兑换
@property (nonatomic, strong) UIButton *sendBtn;  // 赠送

@property (nonatomic, strong) HNGiftListModel *selectModel;  // 当前选择的礼物index

@end

@implementation HNGiftListView

- (instancetype)init
{
    self = [super init];
    if (self)
    {
        self.backgroundColor = [UIColor clearColor];
        [self setUI];
    }
    return self;
}

- (void)show
{
      [self showView];
    // 获取下上次礼物版本的更新时间
    NSString *versionTime;
    if (kGiftVersionTime == nil)
    {
        versionTime = @"0";
    }
    else
    {
        versionTime = kGiftVersionTime;
    }
    _weakself;
    [[HNRequestManager manager] sendRequestWithRequestMethodType:HNRequestMethodTypeGET requestAPICode:CheckVersion requestParameters:@{@"os" : @"iOS",@"version_time" : versionTime} requestHeader:nil success:^(id responseObject) {
        
        if (CODE != 200)
        {
            return ;
        }
        
        // 礼物列表处理
        NSArray *array = [NSArray yy_modelArrayWithClass:[HNGiftListModel class] json:responseObject[@"d"][@"gift_list"]];
        AppDelegate * appDelegate = (AppDelegate*)[UIApplication sharedApplication].delegate;
        [appDelegate giftListDealWithArray:array];
        // 获取下礼物列表
        NSData *gidtData = [[UserDefault objectForKey:@"giftList"] copy];
        NSArray *giftListarray = [[NSKeyedUnarchiver unarchiveObjectWithData:gidtData] copy];
        NSMutableArray *attarray = [NSMutableArray arrayWithArray:giftListarray];
        for (HNGiftListModel *model in array)
        {
            // 只显示上架的礼物
            if ([model.status integerValue] != 1)
            {
                [attarray removeObject:model];
            }
        }
        
       weakself.giftArray=attarray;
       
    } faild:^(NSError *error) {
         ERROR;
    }];
  
}
-(void)showView{
   dispatch_async(dispatch_get_main_queue(), ^{
        self.pageControl.numberOfPages = self.mainScrollView.contentSize.width / SCREEN_WIDTH;
       
        UIWindow *window = [[[UIApplication sharedApplication] delegate] window];
        [window addSubview:self];
       
        self.frame  =CGRectMake(0, SCREEN_HEIGHT, SCREEN_WIDTH, SCREEN_HEIGHT);
       
        [UIView animateWithDuration:0.25 animations:^{
            self.transform = CGAffineTransformMakeTranslation(0, -SCREEN_HEIGHT);
        } completion:^(BOOL finished) {
            
            // 修改当前的余额
            self.coinLab.text = [NSString stringWithFormat:@"余额：%@%@",self.coin,kCoinName];
        }];
   });
}
- (void)hiddenView
{
    [UIView animateWithDuration:0.25 animations:^{
        self.frame = CGRectMake(0, SCREEN_HEIGHT, SCREEN_WIDTH, SCREEN_HEIGHT);
        
    } completion:^(BOOL finished) {
        if(self.enabledBlock){
            self.enabledBlock();
        }
        [self removeFromSuperview];
        
    
    }];
}

#pragma mark - 点击空白消失
-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    UITouch *touche = [touches anyObject];
    CGPoint point =  [touche locationInView:self];
    CGFloat height = self.bgView.height;
    BOOL b =  CGRectContainsPoint(CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT -height), point);
    if (b)
    {
        [UIView animateWithDuration:0.25 animations:^{
            self.transform = CGAffineTransformIdentity;
            
        } completion:^(BOOL finished) {
            if(self.enabledBlock){
                self.enabledBlock();
            }
            [self removeFromSuperview];

        }];
    }
}

#pragma mark - privateMethod

- (void)rechargeBtnClick
{
    if ([self.giftDelegate respondsToSelector:@selector(didClickRechargeBtn)])
    {
        [self.giftDelegate didClickRechargeBtn];
    }
}

- (void)sendBtnClick
{
    if (self.selectModel == nil)
    {
        return;
    }
    
    if ([self.giftDelegate respondsToSelector:@selector(didClickSendGiftWithSelectModel:)])
    {
        [self.giftDelegate didClickSendGiftWithSelectModel:self.selectModel];
    }
}

- (void)setCoin:(NSString *)coin
{
    _coin = coin;
    
    self.coinLab.text = [NSString stringWithFormat:@"余额：%@%@",coin,kCoinName];
}

- (void)setGiftArray:(NSArray *)giftArray
{
    _giftArray = giftArray;
    
    [self addGifts];
}

- (void)giftClick:(UIButton *)btn
{
    for (HNGiftView *view in self.mainScrollView.subviews)
    {
        view.selected = NO;
    }
    
    HNGiftView *view = [self.mainScrollView viewWithTag:btn.tag - 100 + 1000];
    view.selected = YES;
    
    HNGiftListModel *model = self.giftArray[btn.tag - 100];
    self.selectModel = model;
}

#pragma mark - UIScrollViewDelegate

- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView;
{
    NSInteger page = scrollView.contentOffset.x / SCREEN_WIDTH;
    self.pageControl.currentPage = page;
}

#pragma mark - setUI

// 九宫格形式添加礼物图片
- (void)addGifts
{
    for (HNGiftListView *view in self.mainScrollView.subviews)
    {
        [view removeFromSuperview];
    }
    
    int total_row = 0;
    BOOL isMultipleOfEight = !(self.giftArray.count % 8);
    if (isMultipleOfEight == YES)
    {
        total_row = (int)self.giftArray.count / 8;
    }
    else
    {
        total_row = (int)self.giftArray.count / 8 + 1;
    }

    self.mainScrollView.contentSize = CGSizeMake(SCREEN_WIDTH * total_row, self.mainScrollView.height);
    
    for (int j = 0; j < total_row; ++j)
    {
        for (int i = 0; i < 8; ++i)
        {
            NSInteger tag = 0;
            tag = i + j * 8 ;
            if (self.giftArray.count <= tag)
            {
                return;
            }
        
           dispatch_async(dispatch_get_main_queue(), ^{
                
                CGFloat viewX = (i % COL_Count) * PIC_Width + SCREEN_WIDTH * j;
                CGFloat viewY = (i / COL_Count) * PIC_Height;
                
                HNGiftView *view = [[HNGiftView alloc] initWithFrame:CGRectMake(viewX, viewY, PIC_Width, PIC_Height)];
                view.clickBtn.tag = tag + 100;
                view.tag = tag + 1000;
                [view.clickBtn addTarget:self action:@selector(giftClick:) forControlEvents:UIControlEventTouchUpInside];
                
                view.model = self.giftArray[tag];
                
                
                    [self.mainScrollView addSubview:view];
            });
        }
    }
}

- (void)setUI
{
    [self addSubview:self.bgView];
    [self.bgView addSubview:self.mainScrollView];
    [self.bgView addSubview:self.pageControl];
    [self.bgView addSubview:self.coinLab];
    [self.bgView addSubview:self.rechargeBtn];
    [self.bgView addSubview:self.sendBtn];

    [self.mainScrollView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(self.bgView);
        make.left.width.mas_equalTo(self);
        make.height.mas_offset(Handle_height(208));
    }];
    
    [self.pageControl mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.mas_equalTo(self.bgView.mas_centerX);
        make.top.mas_equalTo(self.mainScrollView.mas_bottom);
        make.width.mas_offset(Handle_width(200));
        make.height.mas_offset(30);
    }];
    
    [self.coinLab mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_offset(kSpaceToLeftOrRight);
        make.bottom.mas_offset(-Handle(15));
    }];
    
    [self.sendBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.bottom.mas_offset(-Handle(2));
        make.right.mas_offset(-kSpaceToLeftOrRight);
        make.width.mas_offset(Handle_width(100));
        make.height.mas_offset(Handle_height(40));
    }];
    
    [self.rechargeBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.mas_equalTo(self.sendBtn.mas_left).mas_offset(-Handle(25));
        make.centerY.mas_equalTo(self.sendBtn.mas_centerY);
        make.width.mas_lessThanOrEqualTo(Handle_width(100));
    }];
    
    [self layoutIfNeeded];
}

#pragma mark - getter

- (UIView *)bgView
{
    if(!_bgView)
    {
        _bgView = InsertView(nil, CGRectMake(0, SCREEN_HEIGHT - Handle_height(548 / 2), SCREEN_WIDTH, Handle_height(548 / 2)), UIColorFromHEXA(0x000000, 0.8));
    }
    return _bgView;
}

- (UIScrollView *)mainScrollView
{
    if (!_mainScrollView)
    {
        _mainScrollView = InsertScrollView(nil, CGRectZero, 0, self);
        _mainScrollView.backgroundColor = [UIColor clearColor];
        _mainScrollView.pagingEnabled = YES;
        _mainScrollView.scrollEnabled = YES;
    }
    return _mainScrollView;
}

- (UILabel *)coinLab
{
    if(!_coinLab)
    {
        _coinLab = InsertLabel(nil, CGRectZero, NSTextAlignmentLeft, @"余额：", SystemFontSize15, [UIColor whiteColor]);
//         _coinLab.hidden=YES;
    }
    return _coinLab;
}

- (UIButton *)rechargeBtn
{
    if(!_rechargeBtn)
    {
        _rechargeBtn = InsertTitleAndImageButton(nil, CGRectZero, 88, @"去充值", UIEdgeInsetsZero, SystemFontSize15, UIColorFromHEXA(0x8D2CD5, 1.0), nil, nil, nil, self, @selector(rechargeBtnClick));
        [_rechargeBtn setImage:GetImage(@"btn_recharge") forState:UIControlStateNormal];
        _rechargeBtn.imageEdgeInsets = UIEdgeInsetsMake(0, Handle(50) + 2.5, 0, -Handle(50) -2.5);
        _rechargeBtn.titleEdgeInsets = UIEdgeInsetsMake(0, -_rechargeBtn.currentImage.size.width, 0, _rechargeBtn.currentImage.size.width);
        _rechargeBtn.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft;
//        _rechargeBtn.hidden=YES;
    }
    return _rechargeBtn;
}

- (UIButton *)sendBtn
{
    if(!_sendBtn)
    {
        _sendBtn = InsertTitleAndImageButton(nil, CGRectZero, 99, @"赠送", UIEdgeInsetsZero, SystemFontSize18, [UIColor whiteColor], nil, nil, nil, self, @selector(sendBtnClick));
        _sendBtn.backgroundColor = BtnBgColor;
        _sendBtn.layer.cornerRadius = Handle(6);
        _sendBtn.layer.masksToBounds = YES;
    }
    return _sendBtn;
}

- (UIPageControl *)pageControl
{
    if (!_pageControl) {
        _pageControl = [[UIPageControl alloc]initWithFrame:CGRectZero];
        _pageControl.currentPage = 0;
        _pageControl.currentPageIndicatorTintColor = UIColorFromHEXA(0xFFFFFF, 1.0);
        _pageControl.pageIndicatorTintColor = UIColorFromHEXA(0xFFFFFF, 0.4);
    }
    return _pageControl;
}

@end
