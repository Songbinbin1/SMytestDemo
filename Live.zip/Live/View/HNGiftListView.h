//
//  HNGiftListView.h
//  SunsetLive
//
//  Created by Sunwanwan on 2017/9/13.
//  Copyright © 2017年 HN. All rights reserved.
//  礼物列表视图

#import <UIKit/UIKit.h>
typedef void(^EnabledBlock)(void);
@protocol HNGiftListViewDelegate <NSObject>

@optional

// 点击了兑换按钮
- (void)didClickRechargeBtn;

// 点击了赠送按钮
- (void)didClickSendGiftWithSelectModel:(HNGiftListModel *)model;

// 界面消失之后处理（懒， 不想写block， 直接写代理里面算了）
- (void)viewHiddenEnd;

@end

@interface HNGiftListView : UIView
@property (copy, nonatomic)EnabledBlock enabledBlock;

@property (nonatomic, strong) NSArray *giftArray;

@property (nonatomic, strong) NSString *coin;  // 用户余额

@property (nonatomic, assign) id<HNGiftListViewDelegate> giftDelegate;

- (void)show;

- (void)hiddenView;

@end
