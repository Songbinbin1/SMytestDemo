//
//  HNTXLiveMediaStreamView.m
//  SunsetLive
//
//  Created by Sunwanwan on 2017/10/11.
//  Copyright © 2017年 HN. All rights reserved.
//

#import "HNTXLivePushView.h"
#import <TXLivePush.h>
#import "HNHttpRequest.h"
@interface HNTXLivePushView () <TXLivePushListener>
{
    BOOL _appIsInterrupt;  // 是否被打断
    BOOL _appIsInActive;   // 是否处于前台
    BOOL _appIsBackground; // 是否进入后台
}

@property (nonatomic, strong) TXLivePush *livePushLisher;
@property (nonatomic, strong) NSString *tapeId;
@property (nonatomic, assign) BOOL isFront;
@end

@implementation HNTXLivePushView

+ (instancetype)livePushView
{
    HNTXLivePushView *view = [[HNTXLivePushView alloc] init];
    return view;
}

- (id)init
{
    self = [super init];
    if (self)
    {
        self.frame = CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT);
        self.backgroundColor = [UIColor clearColor];
        self.isFront=YES;
        [self initStreamOption];
    }
    return self;
}

- (void)dealloc
{
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

#pragma mark ------------- 腾讯云推流sdk ----------

- (void)initStreamOption
{
    TXLivePushConfig *config = [[TXLivePushConfig alloc] init];
    config.pauseFps = 10;
    config.pauseTime = 300;  // 后台播放暂停图片最长持续时间
    config.connectRetryCount = 3;  // 重连次数
    config.connectRetryInterval = 10;  // 重连间隔
    
    // 开启耳返
    config.enableAudioPreview = YES;
    
    self.livePushLisher = [[TXLivePush alloc] initWithConfig:config];
    
    // 开启镜像
    [self.livePushLisher setMirror:self.isFront];
    
    // 设置清晰度
    //    [self.livePushLisher setVideoQuality:VIDEO_QUALITY_HIGH_DEFINITION adjustBitrate:NO adjustResolution:NO];
    
    // 添加系统事件通知
    [self addNSNotification];
    
    _appIsInterrupt = NO;
    _appIsInActive = YES;
    _appIsBackground = NO;
}

#pragma mark - 对推流的操作

- (void)startPush
{
    if (![self.streamCloudURL hasPrefix:@"rtmp://"])
    {
        [MBProgressHUD showError:@"推流地址不合法，不能推流哦"];
        return;
    }
    
    // 是否有摄像头权限
    AVAuthorizationStatus statusVideo = [AVCaptureDevice authorizationStatusForMediaType:AVMediaTypeVideo];
    if (statusVideo == AVAuthorizationStatusDenied)
    {
        HNAlertView *view = [[HNAlertView alloc] initWithTitle:nil Content:@"请到设置里打开摄像头权限" whitTitleArray:@[@"取消",@"设置"] withType:@"center"];
        [view showAlertView:^(NSInteger index) {
            if (index == 1)
            {
                NSURL *url = [NSURL URLWithString:UIApplicationOpenSettingsURLString];
                
                if ([[UIApplication sharedApplication] canOpenURL:url]) {
                    
                    [[UIApplication sharedApplication] openURL:url];
                    
                }
            }
        }];
        
        return;
    }
    
    // 是否有麦克风权限
    AVAuthorizationStatus statusAudio = [AVCaptureDevice authorizationStatusForMediaType:AVMediaTypeAudio];
    if (statusAudio == AVAuthorizationStatusDenied)
    {
        HNAlertView *view = [[HNAlertView alloc] initWithTitle:nil Content:@"请到设置里打开麦克风权限" whitTitleArray:@[@"取消",@"设置"] withType:@"center"];
        [view showAlertView:^(NSInteger index) {
            if (index == 1)
            {
                NSURL *url = [NSURL URLWithString:UIApplicationOpenSettingsURLString];
                
                if ([[UIApplication sharedApplication] canOpenURL:url]) {
                    
                    [[UIApplication sharedApplication] openURL:url];
                    
                }
            }
        }];
        
        return;
    }
    
    if (self.livePushLisher != nil)
    {
        TXLivePushConfig *config = self.livePushLisher.config;
        config.pauseImg = GetImage(@"Likai-beijing");
        config.enableNearestIP = self.enableNearestIP;
        config.enableHWAcceleration=YES;
        
        [self.livePushLisher setConfig:config];
        
        self.livePushLisher.delegate = self;
    }
    [self.livePushLisher setVideoQuality:VIDEO_QUALITY_STANDARD_DEFINITION adjustBitrate:YES adjustResolution:YES];
    [self.livePushLisher startPreview:self];
    [self.livePushLisher startPush:self.streamCloudURL];
    
    if ([self.livePushLisher startPush:self.streamCloudURL] != 0)
    {
        NSLog(@"推流器启动失败");
        return;
    }
    if (_isRecording) {
        _weakself;
        [HNHttpRequest tapeStartWithStreamParam:_streamCloudURL liveTitle:_liveTitle liveLogo:_liveLogo Success:^(id responseObject) {
            _strongSelf;
            strongSelf.tapeId=responseObject[@"d"];
        } failure:^(NSError *error) {
            
        }];
    }
    
    //    [HNHttpRequest tapeStartWithSuccess:^(id responseObject) {
    //        _strongSelf;
    //        strongSelf.tapeId=responseObject[@"d"];
    //    } failure:^(NSError *error) {
    //
    //    }];
}

- (void)stopPush
{
    self.streamCloudURL = @"";
    if (self.livePushLisher != nil)
    {
        if (_tapeId && _isRecording) {
            [HNHttpRequest  tapeStopWithtApeId:_tapeId success:^(id responseObject) {
                
            } failure:^(NSError *error) {
                
            }];
        }
        self.livePushLisher.delegate = nil;
        [self.livePushLisher stopPreview];
        [self.livePushLisher stopPush];
    }
}

- (void)pausePush;
{
    [self.livePushLisher pausePush];
}

- (void)resumePush
{
    [self.livePushLisher resumePush];
}

#pragma mark - 监听推流相关事件

- (void)onPushEvent:(int)EvtID withParam:(NSDictionary *)param
{
    NSDictionary *dict = param;
    
    dispatch_async(dispatch_get_main_queue(), ^{
        
        if (EvtID == PUSH_WARNING_RECONNECT)
        {
            //网络断连, 已启动自动重连 (自动重连连续失败超过三次会放弃)
            [MBProgressHUD showError:@"正在重连中，请稍候~" toView:self];
        }
        else if (EvtID == PUSH_ERR_NET_DISCONNECT)
        {
            // 多次重连失败了， 更多重试可自行重启重连
            
            
            //            [[NSNotificationCenter defaultCenter] postNotificationName:@"StreamReconteactFaild" object:nil];
        }
        else if (EvtID == PUSH_WARNING_HW_ACCELERATION_FAIL)
        {
            // 硬编码启动失败，采用软编码
            self.livePushLisher.config.enableHWAcceleration = false;
        }
        else if (EvtID == PUSH_ERR_OPEN_CAMERA_FAIL)
        {
            // 打开摄像头失败
            [self stopPush];
            [[UIApplication sharedApplication] setIdleTimerDisabled:NO];
        }
        else if (EvtID == PUSH_ERR_OPEN_MIC_FAIL)
        {
            // 打开麦克风失败
            [self stopPush];
            [[UIApplication sharedApplication] setIdleTimerDisabled:NO];
        }
        else if (EvtID == PUSH_EVT_CONNECT_SUCC)
        {
            // 已经成功连接到腾讯云推流服务器
            // 在这里可以进行一些网络的判断， 比如是否是wifi
        }
        else if (EvtID == PUSH_EVT_PUSH_BEGIN)
        {
            // 已经与服务器握手完毕,开始推流  （真正推流开始的标志）
            [[NSNotificationCenter defaultCenter] postNotificationName:@"PLStreamStartStateSuccess" object:nil];
        }
        else if (EvtID == PUSH_EVT_FIRST_FRAME_AVAILABLE)
        {
            // 首桢画面采集完成
            [[NSNotificationCenter defaultCenter] postNotificationName:@"PLStreamStartStateSuccess" object:@"FIRST_FRAME_AVAILABLE"];
        }
        else if (EvtID == PUSH_WARNING_NET_BUSY)
        {
            // 当前主播的上行网络质量较差，观众端已出现了卡顿现象
            [MBProgressHUD showError:@"您当前的网络环境不佳哦~"];
        }
        
        long long time = [(NSNumber *) [dict valueForKey:EVT_TIME] longLongValue];
        int mil = (int) (time % 1000);
        NSDate *date = [NSDate dateWithTimeIntervalSince1970:time / 1000];
        NSString *Msg = (NSString *) [dict valueForKey:EVT_MSG];
        [self appendLog:Msg time:date mills:mil];
        
    });
}

- (void)onNetStatus:(NSDictionary *)param
{
    NSDictionary *dict = param;
    
    NSString *streamID = [dict valueForKey:STREAM_ID];
    if (![streamID isEqualToString:self.streamCloudURL])
    {
        return;
    }
    
    // 推流实时信息回调 --------
    dispatch_async(dispatch_get_main_queue(), ^{
        float netspeed  = [(NSNumber*)[dict valueForKey:NET_STATUS_NET_SPEED] floatValue] / 8;
        
        NSString *SPD = [NSString stringWithFormat:@"%.2fKB/s",netspeed];
        if (self.netStatusBlock)
        {
            self.netStatusBlock(SPD);
        }
    });
}

#pragma mark - 通知

- (void)addNSNotification
{
    // 监听系统的打断事件
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(handleInterruption:) name:AVAudioSessionInterruptionNotification object:nil];
    
    // 程序进入后台
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(onAppDidEnterBackGround:) name:UIApplicationDidEnterBackgroundNotification object:nil];
    
    // 程序进入非活动状态
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(onAppWillResignActive:) name:UIApplicationWillResignActiveNotification object:nil];
    
    // 程序进入前台，并处于活动状态
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(onAppDidBecomeActive:) name:UIApplicationDidBecomeActiveNotification object:nil];
    
    // 程序将要进入前台
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(onAppWillEnterForeground:) name:UIApplicationWillEnterForegroundNotification object:nil];
}

- (void)handleInterruption:(NSNotification *)notification
{
    AVAudioSessionInterruptionType type = [notification.userInfo[AVAudioSessionInterruptionTypeKey] intValue];
    if (AVAudioSessionInterruptionTypeBegan == type)
    {
        _appIsInterrupt = YES;
        [self.livePushLisher pausePush];
        
        NSLog(@"AVAudioSessionInterruptionTypeBegan");
    }
    if (AVAudioSessionInterruptionTypeEnded == type)
    {
        _appIsInterrupt = NO;
        if (!_appIsBackground && !_appIsInActive && !_appIsInterrupt)
        {
            [self.livePushLisher resumePush];
            NSLog(@"AVAudioSessionInterruptionTypeEnd");
        }
    }
}

- (void)onAppDidEnterBackGround:(NSNotification *)notification
{
    [[UIApplication sharedApplication] beginBackgroundTaskWithExpirationHandler:^{
        
    }];
    
    _appIsBackground = YES;
    [self.livePushLisher pausePush];
}

- (void)onAppWillResignActive:(NSNotification *)notification
{
    _appIsInActive = NO;
    [self.livePushLisher pausePush];
}

- (void)onAppDidBecomeActive:(NSNotification *)notification
{
    _appIsInActive = NO;
    if (!_appIsBackground && !_appIsInActive && !_appIsInterrupt)
    {
        [self.livePushLisher resumePush];
    }
}

- (void)onAppWillEnterForeground:(NSNotification *)notification
{
    _appIsBackground = NO;
    if (!_appIsBackground && !_appIsInActive && !_appIsInterrupt)
    {
        [self.livePushLisher resumePush];
    }
}

#pragma mark - private

- (void)appendLog:(NSString *)evt time:(NSDate *)date mills:(int)mil
{
    NSDateFormatter *format = [[NSDateFormatter alloc] init];
    format.dateFormat = @"hh:mm:ss";
    NSString *time = [format stringFromDate:date];
    NSString *log = [NSString stringWithFormat:@"[%@.%-3.3d] %@", time, mil, evt];
    NSLog(@"log：%@",log);
}

#pragma mark - 切换摄像头操作

- (void)changeCamer
{
    [self.livePushLisher switchCamera];
    self.isFront=self.isFront?NO:YES;
    [self.livePushLisher setMirror:self.isFront];
}

#pragma mark - 美颜操作

- (void)changeSkinCareWithType:(BOOL)isSmooth skinCareValue:(CGFloat)skinCare whiteningValue:(CGFloat)whitening ruddyValue:(CGFloat)ruddy
{
    [self.livePushLisher setBeautyStyle:isSmooth ? 1 : 0 beautyLevel:skinCare whitenessLevel:whitening ruddinessLevel:ruddy];
}

@end
