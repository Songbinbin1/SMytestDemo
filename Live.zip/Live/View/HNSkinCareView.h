//
//  HNSkinCareView.h
//  SunsetLive
//
//  Created by Sunwanwan on 2017/10/25.
//  Copyright © 2017年 HN. All rights reserved.
//  美颜

#import <UIKit/UIKit.h>

@protocol HNSkinCareViewDelegate <NSObject>

- (void)sliderValueChangeWithSkinCareValue:(CGFloat)skinCare whiteningValue:(CGFloat)whitening ruddyValue:(CGFloat)ruddy type:(BOOL)isSmooth;

@end

@interface HNSkinCareView : UIView

@property (nonatomic, assign) id<HNSkinCareViewDelegate> skinDelegate;

- (void)show;

@end
