//
//  HNLiveSeeUserCollectionCell.m
//  SunsetLive
//
//  Created by Sunwanwan on 2017/9/14.
//  Copyright © 2017年 HN. All rights reserved.
//

#import "HNLiveSeeUserCollectionCell.h"

@interface HNLiveSeeUserCollectionCell ()

@property (nonatomic, strong) UIImageView *headerImg;

@end

@implementation HNLiveSeeUserCollectionCell

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self)
    {
        [self.contentView addSubview:self.headerImg];
        
        [self.headerImg mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerX.centerY.mas_equalTo(self.contentView);
            make.size.mas_equalTo(CGSizeMake(Handle_width(40), Handle_height(40)));
        }];
        
    }
    return self;
}

#pragma mark - privateMethod

- (void)setUserModel:(HNLiveUserModel *)userModel
{
    _userModel = userModel;
    
    [self.headerImg sd_setImageWithURL:[NSURL URLWithString:[HNTools pictureStr:userModel.avatar]] placeholderImage:DefaultHeaderImage];
 
}

#pragma mark - getter

- (UIImageView *)headerImg
{
    if(!_headerImg)
    {
        _headerImg = InsertImageView(nil, CGRectZero, DefaultHeaderImage);
        _headerImg.layer.cornerRadius = Handle(20);
        _headerImg.layer.masksToBounds = YES;
        
        _headerImg.contentMode = UIViewContentModeScaleAspectFill;
        _headerImg.clipsToBounds = YES;
    }
    return _headerImg;
}



@end
