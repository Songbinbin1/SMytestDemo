//
//  HNHeadsetView.h
//  SunsetLive
//
//  Created by 龙骏 on 2018/8/28.
//  Copyright © 2018年 HN. All rights reserved.
//

#import <UIKit/UIKit.h>
typedef void(^ApplyBtnBlock)(void);
typedef void(^CancelBtnBlock)(void);
typedef void(^ConnectBtnBlock)(void);
typedef void(^ColseBtnBlock)(void);
@interface HNHeadsetView : UIView

@property(strong,nonatomic) UITableView *tableView;
@property(copy,nonatomic) ApplyBtnBlock applyBtnBlock;
@property(copy,nonatomic) CancelBtnBlock cancelBtnBlock;
@property(copy,nonatomic) ConnectBtnBlock connectBtnBlock;
@property(copy,nonatomic) ColseBtnBlock colseBtnBlock;
@property(strong,nonatomic) NSString *anchorId;
-(void)show:(NSInteger)type congUserIdArr:(NSMutableArray *)congUserIdArr;
-(void)diss;
@end
