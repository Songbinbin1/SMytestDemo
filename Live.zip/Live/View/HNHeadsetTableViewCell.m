//
//  HNHeadsetTableViewCell.m
//  SunsetLive
//
//  Created by 龙骏 on 2018/8/28.
//  Copyright © 2018年 HN. All rights reserved.
//

#import "HNHeadsetTableViewCell.h"
#import "HNHttpRequest.h"
@implementation HNHeadsetTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}
-(void)setModel:(HNLiveAnchorModel *)model{
    _model = model;
    _nameLable.text = model.nick;
    [self.iamgeView sd_setImageWithURL:[NSURL URLWithString:model.avatar] placeholderImage:[UIImage imageNamed:@"live_head_default"]];
    
    if ([model.conetState isEqualToString:@"1"]){
         [_stateBtn setTitle:@"取消" forState:UIControlStateNormal];
         [_stateBtn setTitleColor:[UIColor redColor] forState:UIControlStateNormal];
       _stateBtn.backgroundColor = UIColorFromRGBA(50, 212, 201, 1);
    }else if ([model.conetState isEqualToString:@"0"]){
         [_stateBtn setTitle:@"接受" forState:UIControlStateNormal];
          [_stateBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        _stateBtn.backgroundColor = UIColorFromRGBA(50, 212, 201, 1);
    }else if ([model.conetState isEqualToString:@"2"]){
        [_stateBtn setTitle:@"等待连接" forState:UIControlStateNormal];
        [_stateBtn setTitleColor:[UIColor grayColor] forState:UIControlStateNormal];
    }else if ([model.conetState isEqualToString:@"3"]){
        [_stateBtn setTitle:@"连麦中" forState:UIControlStateNormal];
        [_stateBtn setTitleColor:[UIColor greenColor] forState:UIControlStateNormal];
    }
}

- (IBAction)btnAction:(id)sender {
    if([_model.conetState isEqualToString:@"0"]){
        if (self.btnActionBlock) {
            self.btnActionBlock(self.model.uid);
        }
    }
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
