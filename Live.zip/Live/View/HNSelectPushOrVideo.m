//
//  HNSelectPushOrVideo.m
//  SunsetLive
//
//  Created by 宋彬彬 on 2018/4/28.
//  Copyright © 2018年 HN. All rights reserved.
//

#import "HNSelectPushOrVideo.h"
#import "HNTools.h"
@implementation HNSelectPushOrVideo

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
 
*/
- (void)drawRect:(CGRect)rect {
  
    if (HN_isFullScreen) {
          self.bgViewHeight.constant = 194;
    }
    CAShapeLayer *maskLayer = [CAShapeLayer layer];
    maskLayer.path = [UIBezierPath bezierPathWithRoundedRect:self.bgView.bounds byRoundingCorners: UIRectCornerTopLeft | UIRectCornerTopRight cornerRadii: (CGSize){10.0f, 10.0f}].CGPath;
    self.bgView.layer.masksToBounds = YES;
    self.bgView.layer.mask = maskLayer;
    [HNTools initButton:self.liveBtn];
    [HNTools initButton:self.videoBtn];
    [HNTools initButton:self.articleBtn];
//    CGFloat    space = 5;// 图片和文字的间距
//    NSString    * titleString = [NSString stringWithFormat:@"直播"];
//    CGFloat    titleWidth = [titleString sizeWithAttributes:@{NSFontAttributeName:[UIFont systemFontOfSize:14]}].width;
//    UIImage    * btnImage = [UIImage imageNamed:@"buy_ticket"];// 11*6
//    CGFloat    imageWidth = btnImage.size.width;
//    CGFloat    imageHeight = self.videoBtn.height;
//    CGFloat    titleHeight = [titleString sizeWithAttributes:@{NSFontAttributeName:[UIFont systemFontOfSize:14]}].height;
//    [self.videoBtn setImageEdgeInsets:UIEdgeInsetsMake(-(imageHeight*0.5 + space*0.5), titleWidth*0.5, imageHeight*0.5 + space*0.5, -titleWidth*0.5)];
//    [self.videoBtn setTitleEdgeInsets:UIEdgeInsetsMake(titleHeight*0.5 + space*0.5, -imageWidth*0.5, -(titleHeight*0.5 + space*0.5), imageWidth*0.5)];
    
}


+(instancetype) initHNSelectPushOrVideo{
    NSBundle *bundle=[NSBundle mainBundle];
    NSArray *objs=[bundle loadNibNamed:@"HNSelectPushOrVideo" owner:nil options:nil];
    return [objs lastObject];
}
-(void)showSelectView:(UIView *)view{
    self.backgroundColor=UIColorFromRGBA(0, 0, 0, 0.3);
    if(view){
        [view addSubview:self];
    }else{
        [[UIApplication sharedApplication].keyWindow addSubview:self];
    }
    self.btnBgViewTop.constant=20;
    if (HN_isFullScreen) {
        self.bgViewHeight.constant = 194;
    }
    self.bgViewBottom.constant=-(HN_isFullScreen?194:174);
     [self layoutIfNeeded];
     self.bgViewBottom.constant=0;
    [UIView animateWithDuration:0.1 animations:^{
          [self layoutIfNeeded];
    } completion:^(BOOL finished) {
        self.btnBgViewTop.constant=10;
        [UIView animateWithDuration:0.4 delay:0 usingSpringWithDamping:0.1 initialSpringVelocity:1  options:UIViewAnimationOptionCurveLinear animations:^{
            [self layoutIfNeeded];
        } completion:^(BOOL finished) {
            
        }];
    }];
    
}
- (IBAction)videoBtnAction:(id)sender {
    if(self.videoBtnBlock){
        self.videoBtnBlock();
        [self removeFromSuperview];
    }
}
- (IBAction)liveBtnAction:(id)sender {
    if(self.liveBtnBlock){
        self.liveBtnBlock();
        [self removeFromSuperview];
    }
}
- (IBAction)closeBtnAction:(id)sender {
    self.bgViewBottom.constant=-self.bgView.height;
    [UIView animateWithDuration:0.1 animations:^{
        [self layoutIfNeeded];
    } completion:^(BOOL finished) {
        [self removeFromSuperview];
    }];
    
}
- (IBAction)articleBtnAction:(id)sender {
    if(self.articleBtnBlock){
        self.articleBtnBlock();
        [self removeFromSuperview];
    }
}
-(void) touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event{
    UITouch * touch = touches.anyObject;
    if(touch.view==self.liveBtn || touch.view==self.videoBtn){
        [super touchesBegan:touches withEvent:event];
    }
    self.bgViewBottom.constant=-(HN_isFullScreen?194:174);
    [UIView animateWithDuration:0.1 animations:^{
        [self layoutIfNeeded];
    } completion:^(BOOL finished) {
         [self removeFromSuperview];
    }];
   
}
@end
