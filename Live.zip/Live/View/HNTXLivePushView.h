//
//  HNTXLiveMediaStreamView.h
//  SunsetLive
//
//  Created by Sunwanwan on 2017/10/11.
//  Copyright © 2017年 HN. All rights reserved.
//  腾讯云推流

#import <UIKit/UIKit.h>

@interface HNTXLivePushView : UIView

+ (instancetype)livePushView;

@property (nonatomic, strong) NSString *streamCloudURL; // 推流的服务器地址

@property (nonatomic, assign) BOOL enableNearestIP;  // 是否选择就近线路， 其实就是区分是否是腾讯云还是其他第三方云服务

@property (nonatomic, copy) void(^netStatusBlock) (NSString *spd);  // 上传速度

@property (nonatomic, copy) void(^colseBlock) (void);  // 
@property (nonatomic, strong) NSString *liveTitle; // 推流的服务器地址
@property (nonatomic, strong) NSString *liveLogo;  // 推流的服务器地址
@property (nonatomic, assign) BOOL isRecording;

// 开始推流
- (void)startPush;

// 停止推流
- (void)stopPush;

// 暂停推流
- (void)pausePush;

// 恢复推流
- (void)resumePush;

// 切换摄像头
- (void)changeCamer;

// 改变美颜
- (void)changeSkinCareWithType:(BOOL)isSmooth skinCareValue:(CGFloat)skinCare whiteningValue:(CGFloat)whitening ruddyValue:(CGFloat)ruddy;

-(void)changeFilter:(UIImage *)filter;

@end
