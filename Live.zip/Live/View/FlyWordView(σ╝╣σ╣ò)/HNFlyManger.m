//
//  HNFlyManger.m
//  VeraShow
//
//  Created by 小兵 on 16/8/22.
//  Copyright © 2016年 Red-bird-OfTMZ. All rights reserved.
//

#import "HNFlyManger.h"
#import "HNFlyOperation.h"
#import "HNEnterOperaTion.h"
@interface HNFlyManger ()
@property (nonatomic, strong) NSOperationQueue* queue;

@property (nonatomic, assign) NSInteger sendNum;

@property (nonatomic, strong) NSOperationQueue* enterQueue;
@end
@implementation HNFlyManger

+ (instancetype)sharedManger {
    static HNFlyManger *manger = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        manger = [[HNFlyManger alloc]init];
    });
    return manger;

}
#pragma mark--------------飞屏
- (void)mangerShowWithModel:(HNLiveChatMsgModel *)msgModel parentView:(UIView *)scrollerView {

    HNFlyOperation* op = [HNFlyOperation flyWordWithModel:msgModel parentView:scrollerView];
    self.danMuLayer = op.danMuLayer;
    
    op.rankNum =self.sendNum%2;
    self.sendNum++;
    [self.queue addOperation:op];
    
}

#pragma mark--------------进入房间
- (void)mangerPeopleEnterRoom:(HNLiveChatMsgModel *)msgModel parentView:(UIView *)scrollerView
{
    HNEnterOperaTion* op = [HNEnterOperaTion enterRoomWithModel:msgModel parentView:scrollerView];
    [self.enterQueue addOperation:op];

}
- (NSOperationQueue *)queue
{
    if (!_queue) {
        _queue = [[NSOperationQueue alloc]init];
        _queue.maxConcurrentOperationCount =2;
    }
    return _queue;
}
- (NSOperationQueue *)enterQueue {
    if (!_enterQueue) {
        _enterQueue = [[NSOperationQueue alloc]init];
        _enterQueue.maxConcurrentOperationCount =1;

    }
    return _enterQueue;
}
- (void) endAnimation {
    [self.queue cancelAllOperations];
    self.queue = nil;
}
@end
