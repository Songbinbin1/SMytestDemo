//
//  HNFlyOperation.m
//  VeraShow
//
//  Created by 小兵 on 16/8/22.
//  Copyright © 2016年 Red-bird-OfTMZ. All rights reserved.
//

#import "HNFlyOperation.h"
#import "HNFlyView.h"

#define HEADIMAGEHE  Handle(24)
#define FLYVIEWH  Handle(30)
#define ANIMATIONTime 15

@interface HNFlyOperation ()

@property (nonatomic, strong) HNLiveChatMsgModel* msgModel;
@property (nonatomic, strong) UIView* parentView;

@property (nonatomic, strong) HNFlyView* flyView;
@end
@implementation HNFlyOperation

+ (instancetype)flyWordWithModel:(HNLiveChatMsgModel *)msgModel parentView:(UIView*) scrollerView
{
    HNFlyOperation* op = [[HNFlyOperation alloc]init];
    op.msgModel = msgModel;
    op.parentView = scrollerView;
    return op;
}

- (void)main {

    @autoreleasepool {
        CGFloat contextWidth = [self.msgModel.msg_content boundingRectWithSize:CGSizeMake(SCREEN_WIDTH, FLYVIEWH) options:NSStringDrawingUsesLineFragmentOrigin attributes:@{NSFontAttributeName:[UIFont systemFontOfSize:12 weight:20]} context:nil].size.width;
        CGFloat nameWidth =[self.msgModel.nick boundingRectWithSize:CGSizeMake(SCREEN_WIDTH, FLYVIEWH) options:NSStringDrawingUsesLineFragmentOrigin attributes:@{NSFontAttributeName:[UIFont systemFontOfSize:14]} context:nil].size.width +Handle(20);
        CGFloat wordWith = contextWidth> nameWidth? contextWidth:nameWidth;
        CGFloat totalWidth = wordWith+HEADIMAGEHE+15;
        
        
        dispatch_async(dispatch_get_main_queue(), ^{
            [self.parentView addSubview:self.flyView];
            self.danMuLayer = self.flyView.layer;
            self.flyView.frame =CGRectMake(SCREEN_WIDTH+totalWidth, SCREEN_HEIGHT- Handle(275) - self.rankNum * (FLYVIEWH+13), totalWidth, FLYVIEWH);
            self.flyView.msgModel =self.msgModel;
            
//            UITapGestureRecognizer *ges = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(clickFlyView:)];
//            [self.parentView addGestureRecognizer:ges];

            
//            [UIView animateWithDuration:ANIMATIONTime animations:^{
//                self.flyView.transform = CGAffineTransformMakeTranslation(-MAXWIDTH-totalWidth*2, 0);
//            } completion:^(BOOL finished) {
//                [self.flyView removeFromSuperview];
//                self.flyView = nil;
//            }];
            
            [UIView animateWithDuration:ANIMATIONTime delay:0 options:UIViewAnimationOptionAllowUserInteraction|UIViewAnimationOptionCurveLinear animations:^{
//                  self.flyView.layer.transform = CGAffineTransformMakeTranslation(-MAXWIDTH-totalWidth*2, 0);
//                self.flyView.layer.transform = CATransform3DMakeTranslation(-MAXWIDTH-totalWidth*2, 0, 0);
//                CATransform3DMakeTranslation
                self.flyView.frame = CGRectMake(-SCREEN_WIDTH - totalWidth*2, SCREEN_HEIGHT - Handle(275) - self.rankNum*(FLYVIEWH+13), totalWidth, FLYVIEWH);
            } completion:^(BOOL finished) {
                [self.flyView removeFromSuperview];
                self.flyView = nil;
                
//                [self.parentView removeGestureRecognizer:ges];
            }];
        });
//        [NSThread sleepForTimeInterval:ANIMATIONTime];
        
    }


}


#pragma mark - privateMethod

- (void)clickFlyView:(UITapGestureRecognizer *)tap
{
    CGPoint clickPoint =  [tap locationInView:self.parentView];
    if ([self.flyView.layer.presentationLayer hitTest:clickPoint]) {
        CGPoint p = [self.flyView.layer.presentationLayer convertPoint:clickPoint fromLayer:self.parentView.layer];
        if (CGRectContainsPoint(self.flyView.headImageView.layer.presentationLayer.frame, p)) {
            dispatch_async(dispatch_get_main_queue(), ^{
                [[NSNotificationCenter defaultCenter] postNotificationName:@"jhClickFlyViewHeaderImage"
                                                                    object:self.flyView.msgModel.uid];
            });
            DLog(@"xx点击了头像");
        }
    }
}

- (HNFlyView *)flyView {
    if (!_flyView) {
        _flyView =[HNFlyView flyView];
        
    }
    return _flyView;
}

@end
