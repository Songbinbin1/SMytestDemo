//
//  HNFlyView.m
//  VeraShow
//
//  Created by 小兵 on 16/8/22.
//  Copyright © 2016年 Red-bird-OfTMZ. All rights reserved.
//

#import "HNFlyView.h"
#import "NSString+HNFilter.h"

#define HEADIMAGEHE  Handle(24)

@interface HNFlyView ()

@property (nonatomic, strong) UILabel* contextLab;
@property (nonatomic, strong) UILabel* nameLab;
///等级按钮
@property (nonatomic, strong) UIButton* dengjiBut;
///下面透明View
@property (nonatomic, strong) UIView* bottomView;


@end
@implementation HNFlyView

+ (instancetype) flyView {

    HNFlyView* flyView = [[HNFlyView alloc]init];
    [flyView setupSubV];
    return flyView;
}
#pragma mark------------设置子控件
- (void) setupSubV {
    [self addSubview:self.bottomView];
    [self addSubview:self.nameLab];
    [self addSubview:self.dengjiBut];
    [self addSubview:self.headImageView];
    [self.bottomView addSubview:self.contextLab];

    [self.bottomView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.bottom.mas_equalTo(self);
        make.height.mas_equalTo(Handle(17));
        make.leading.mas_equalTo(HEADIMAGEHE/2);
    }];
    [self.headImageView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.width.height.mas_equalTo(HEADIMAGEHE);
        make.leading.bottom.mas_equalTo(self);
    }];
    [self.nameLab mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(self);
        make.leading.mas_equalTo(self.headImageView.mas_trailing).mas_offset(Handle(5));
//        make.trailing.mas_equalTo(-10*PXSCALE);
    }];
    [self.dengjiBut mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.mas_equalTo(self.nameLab);
        make.leading.mas_equalTo(self.nameLab.mas_trailing).mas_offset(Handle(5));
        make.width.mas_equalTo(Handle(15));
        make.height.mas_equalTo(Handle(10));
    }];
    self.dengjiBut.hidden = YES;
    
    [self.contextLab mas_makeConstraints:^(MASConstraintMaker *make) {
        make.leading.mas_equalTo(self.headImageView.mas_trailing).mas_offset(Handle(5));
        make.centerY.mas_equalTo(self.bottomView);
        make.trailing.mas_equalTo(self.bottomView);
    }];
  
  
}
#pragma mark---------模型赋值
- (void)setMsgModel:(HNLiveChatMsgModel *)msgModel
{
    _msgModel  =msgModel;
    
    [self.headImageView sd_setImageWithURL:[NSURL URLWithString:[HNTools pictureStr:msgModel.avatar]] placeholderImage:DefaultHeaderImage];
    
    NSMutableAttributedString *labelAttributed = [msgModel.msg_content emotionStringWithEmojiHeight:13].mutableCopy;
    NSRange ColorRange = NSMakeRange([[labelAttributed string]rangeOfString:msgModel.msg_content options:NSBackwardsSearch].location, [[labelAttributed string]rangeOfString:msgModel.msg_content].length);
    [labelAttributed addAttributes:@{NSForegroundColorAttributeName:UIColorFromHEXA(0xFFFFFF, 1.0),NSFontAttributeName:SystemFontSize13} range:ColorRange];
    self.contextLab.attributedText = labelAttributed;
    
    self.nameLab.text = msgModel.nick;
    [self.dengjiBut setTitle:msgModel.level forState:UIControlStateNormal];
}

#pragma mark - getter

- (UIImageView *)headImageView {
    if (!_headImageView) {
        _headImageView = [[UIImageView alloc]init];
        _headImageView.layer.cornerRadius = HEADIMAGEHE/2;
        _headImageView.layer.masksToBounds = YES;
        _headImageView.userInteractionEnabled = YES;
    }
    return _headImageView;
}
- (UILabel *)nameLab
{
    if (!_nameLab) {
        _nameLab = InsertLabel(nil, CGRectZero, NSTextAlignmentLeft, @"", SystemFontSize10, UIColorFromHEXA(0xfdd209, 1.0));
    }
    return _nameLab;
}
- (UILabel *)contextLab {
    if (!_contextLab) {
        _contextLab = [[UILabel alloc]init];
        _contextLab.textColor = CString(WhiteColor);
        _contextLab.textAlignment = NSTextAlignmentLeft;
        _contextLab.font = [UIFont systemFontOfSize:12 weight:20];
    }
    return _contextLab;

}
- (UIButton *)dengjiBut {
    if (!_dengjiBut) {
        _dengjiBut = [[UIButton alloc]init];
        _dengjiBut.titleLabel.font = SystemFontSize10;
        _dengjiBut.layer.borderColor = UIColorFromHEXA(0x985ABB, 1.0).CGColor;
        _dengjiBut.layer.borderWidth= 1;
//        _dengjiBut.layer.cornerRadius = 10;
//        _dengjiBut.layer.masksToBounds = YES;
        [_dengjiBut setTitleColor:UIColorFromHEXA(0x985ABB,1.0) forState:UIControlStateNormal];
    }
    return _dengjiBut;
}
- (UIView *)bottomView {
    if (!_bottomView) {
        _bottomView = [[ UIView alloc]init];
        _bottomView.backgroundColor = UIColorFromHEXA(0x000000, 0.3);
    }
    return _bottomView;
}

- (void)layoutSubviews {
    [super layoutSubviews];
    UIBezierPath* path = [UIBezierPath bezierPathWithRoundedRect:self.bottomView.bounds byRoundingCorners:UIRectCornerAllCorners cornerRadii:CGSizeMake(15, 15)];
    CAShapeLayer* layer = [CAShapeLayer layer];
    layer.path  =path.CGPath;
    layer.frame = self.bottomView.bounds;
    self.bottomView.layer.mask = layer;
 
}
#pragma mark----
@end
