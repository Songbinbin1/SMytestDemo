//
//  HNFlyView.h
//  VeraShow
//
//  Created by 小兵 on 16/8/22.
//  Copyright © 2016年 Red-bird-OfTMZ. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "HNLiveChatMsgModel.h"

@interface HNFlyView : UIView

///头像
@property (nonatomic, strong) UIImageView* headImageView;
@property (nonatomic, copy) NSString* headImageStr;
///姓名
@property (nonatomic, copy) NSString* name;
///文字内容
@property (nonatomic, copy) NSString* flyContext;

@property (nonatomic, strong) HNLiveChatMsgModel* msgModel;

+ (instancetype) flyView;

@end
