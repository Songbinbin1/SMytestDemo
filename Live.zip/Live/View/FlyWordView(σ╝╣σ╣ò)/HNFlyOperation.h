//
//  HNFlyOperation.h
//  VeraShow
//
//  Created by 小兵 on 16/8/22.
//  Copyright © 2016年 Red-bird-OfTMZ. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "HNLiveChatMsgModel.h"

@interface HNFlyOperation : NSOperation

@property (nonatomic, assign) NSInteger rankNum;

+ (instancetype) flyWordWithModel:(HNLiveChatMsgModel*) msgModel parentView:(UIView*) scrollerView;

@property(nonatomic ,strong)CALayer *danMuLayer; //!<
@end
