//
//  HNFlyManger.h
//  VeraShow
//
//  Created by 小兵 on 16/8/22.
//  Copyright © 2016年 Red-bird-OfTMZ. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "HNLiveChatMsgModel.h"

@interface HNFlyManger : NSObject

+ (instancetype) sharedManger;

- (void) mangerShowWithModel:(HNLiveChatMsgModel*) msgModel parentView:(UIView*) scrollerView;

- (void) mangerPeopleEnterRoom:(HNLiveChatMsgModel*) msgModel parentView:(UIView*) scrollerView;

@property(nonatomic ,strong)CALayer *danMuLayer; //!<

- (void) endAnimation;
@end
