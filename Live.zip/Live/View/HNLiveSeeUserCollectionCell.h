//
//  HNLiveSeeUserCollectionCell.h
//  SunsetLive
//
//  Created by Sunwanwan on 2017/9/14.
//  Copyright © 2017年 HN. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "HNLiveUserModel.h"

@interface HNLiveSeeUserCollectionCell : UICollectionViewCell

@property (nonatomic, strong) HNLiveUserModel *userModel;

@end
