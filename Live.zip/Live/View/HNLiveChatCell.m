//
//  HNLiveChatCell.m
//  SunsetLive
//
//  Created by Sunwanwan on 2017/9/11.
//  Copyright © 2017年 HN. All rights reserved.
//

#import "HNLiveChatCell.h"
#import "NSString+HNFilter.h"
#define kSpaceToTop Handle(10)
@interface HNLiveChatCell ()

@property (nonatomic, strong) UIButton *levelBtn;
@property (nonatomic, strong) UILabel *msgLab;
@property (nonatomic, strong) UIButton *nickBtn;

@property (nonatomic, strong) UIImageView *iconImg;
@property (nonatomic, strong) UIView *bgView;
@end

@implementation HNLiveChatCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self  = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self)
    {
        self.backgroundColor =[UIColor clearColor];//[UIColor colorWithWhite:0.f alpha:0.15];
        self.selectionStyle = UITableViewCellSelectionStyleNone;
//        self.layer.cornerRadius = 5;
        [self setUI];
    }
    return self;
}

#pragma mark - privateMethod

- (void)setMsgModel:(HNLiveChatMsgModel *)msgModel
{
    _msgModel = msgModel;
    
    if ([msgModel.msg_content containsString:@"系统"])
    {
        self.levelBtn.hidden = YES;
        self.nickBtn.hidden = YES;
        [self.msgLab mas_remakeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_offset(kSpaceToLeftOrRight);
//            make.top.mas_equalTo(self.contentView.mas_top).mas_offset(Handle(10)/2);
            make.centerY.mas_equalTo(self.contentView);
            make.right.mas_equalTo(self.contentView.mas_right).mas_offset(-Handle(5));
        }];
        
        if ([msgModel.msg_content containsString:@"系统消息"])
        {
            self.msgLab.attributedText = msgModel.attributedScount;
        }
        else
        {
             self.msgLab.attributedText = msgModel.attributedScount;
        }
        CGRect textOfRect = [self.msgLab textRectForBounds:CGRectMake(0, 0, Handle_width(285)-Handle(5)-kSpaceToLeftOrRight , CGFLOAT_MAX) limitedToNumberOfLines:0];
        [self.bgView mas_remakeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo((kSpaceToTop-Handle(4))/2);
            make.left.mas_equalTo(5);
            make.width.mas_equalTo(textOfRect.size.width+Handle(5));
            make.bottom.mas_equalTo(-(kSpaceToTop-Handle(4))/2);
        }];
    }
    else
    {
        self.levelBtn.hidden = NO;
        self.nickBtn.hidden = NO;
        [self.msgLab mas_remakeConstraints:^(MASConstraintMaker *make) {
//            make.top.mas_equalTo(self.contentView.mas_top).mas_offset(Handle(10)/2);
             make.centerY.mas_equalTo(self.contentView);
             make.left.mas_equalTo(self.contentView.mas_left).mas_offset(kSpaceToLeftOrRight+Handle_width(60 / 2)+Handle(10));
            make.right.mas_equalTo(self.contentView.mas_right).mas_offset(-Handle(5));
        }];
        
        [self.levelBtn setTitle:msgModel.level forState:UIControlStateNormal];
        [self.levelBtn setBackgroundImage:[HNTools returnBackgroundImageNameWithLevel:msgModel.level] forState:UIControlStateNormal];
        
        [self.nickBtn setTitle:msgModel.nick forState:UIControlStateNormal];
        
        NSString *string = [NSString stringWithFormat:@"%@: %@",msgModel.nick,msgModel.msg_content];
        if (msgModel.msgType == TipsMsgType)
        {
            self.msgLab.attributedText = [HNTools getAttributedString:string withStringAttributedDic:@{NSForegroundColorAttributeName : UIColorFromRGBA(243 ,229 ,53, 1)} withSubString:msgModel.nick withSubStringAttributeDic:@{NSForegroundColorAttributeName : UIColorFromRGBA(255 ,255 ,0, 1)}];
        }
        else if (msgModel.msgType == GiftMsgType )
        {
//            [self.iconImg sd_setImageWithURL:[NSURL URLWithString:[HNTools pictureStr:msgModel.g_icon]] placeholderImage:nil];
//
//            // 创建一个可变字符串
//            NSMutableAttributedString *att = [HNTools getAttributedString:string withStringAttributedDic:@{NSForegroundColorAttributeName : UIColorFromRGBA(243 ,229 ,53, 1)} withSubString:msgModel.nick withSubStringAttributeDic:@{NSForegroundColorAttributeName : UIColorFromRGBA(255 ,255 ,0, 1)}];
//
//            // 设置这个富文本的目的就是为了占位
//            NSTextAttachment *attch = [[NSTextAttachment alloc] init];
//            attch.image = self.iconImg.image;
//            attch.bounds = CGRectMake(0, -Handle(5), Handle(16), Handle(16));
//
//            // 创建带有图片的富文本
//            NSAttributedString *pitString = [NSAttributedString attributedStringWithAttachment:attch];
//
//            // 将图片放在最后一位
//            [att appendAttributedString:pitString];
            
            self.msgLab.attributedText = msgModel.attributedScount;
        }
        else
        {
//
//            NSMutableAttributedString *labelAttributed = [string emotionStringWithEmojiHeight:20].mutableCopy;
//            [labelAttributed addAttribute:NSFontAttributeName value:[UIFont systemFontOfSize:14] range:NSMakeRange(0, labelAttributed.length)];
//
//            NSRange rang = [string rangeOfString:msgModel.nick];
//            [labelAttributed addAttribute:NSForegroundColorAttributeName value:UIColorFromRGBA(255 ,255 ,0, 1) range:rang];
            
            self.msgLab.attributedText = msgModel.attributedScount;
        }
         self.msgLab.attributedText = msgModel.attributedScount;
        CGRect textOfRect = [self.msgLab textRectForBounds:CGRectMake(0, 0, Handle_width(285)-Handle_width(60 / 2)-Handle(15)-kSpaceToLeftOrRight, CGFLOAT_MAX) limitedToNumberOfLines:0];
        [self.bgView mas_remakeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo((kSpaceToTop-Handle(4))/2);
            make.left.mas_equalTo(5);
            make.width.mas_equalTo(textOfRect.size.width+Handle(5)+kSpaceToLeftOrRight+10+Handle_width(60 / 2));
            make.bottom.mas_equalTo(-(kSpaceToTop-Handle(4))/2);
        }];
    }
   
}

- (CGFloat)cellHeight:(NSInteger)index
{
//    [self layoutIfNeeded];
    if (index==0) {
         CGRect textOfRect = [self.msgLab textRectForBounds:CGRectMake(0, 0, Handle_width(285)-Handle(5)-kSpaceToLeftOrRight , CGFLOAT_MAX) limitedToNumberOfLines:0];
         return textOfRect.size.height + Handle(10);
    }else{
        CGRect textOfRect = [self.msgLab textRectForBounds:CGRectMake(0, 0, Handle_width(285)-Handle_width(60 / 2)-Handle(15)-kSpaceToLeftOrRight, CGFLOAT_MAX) limitedToNumberOfLines:0];
        return textOfRect.size.height + Handle(10);
    }
    
//    }
//    else
//    {
//        return self.msgLab.bottom + Handle(5);
//    }
}

- (void)nickBtnClick
{
    DLog(@"-----  点击了昵称。。 哈哈哈哈");
    
    if ([self.delegate respondsToSelector:@selector(didClickNickWithUid:)])
    {
        [self.delegate didClickNickWithUid:self.msgModel.uid];
    }
}

#pragma mark - setUI

- (void)setUI
{
    [self.contentView addSubview: self.bgView];
    [self.contentView addSubview:self.levelBtn];
    [self.contentView addSubview:self.msgLab];
    [self.contentView addSubview:self.nickBtn];
    
   
    
    [self.msgLab mas_makeConstraints:^(MASConstraintMaker *make) {
//        make.top.mas_equalTo(self.contentView.mas_top).mas_offset(Handle(10)/2);
         make.centerY.mas_equalTo(self.contentView);
        make.left.mas_equalTo(self.contentView.mas_left).mas_offset(kSpaceToLeftOrRight+Handle_width(60 / 2)+Handle(10));
        make.right.mas_equalTo(self.contentView.mas_right).mas_offset(-Handle(5));
    }];

    [self.levelBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_offset(kSpaceToLeftOrRight);
        make.top.mas_equalTo(self.msgLab.mas_top).mas_offset(1);
//        make.centerY.mas_equalTo(self.contentView);
        make.size.mas_equalTo(CGSizeMake(Handle_width(60 / 2), Handle_height(13)));
    }];
    [self.nickBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.left.mas_equalTo(self.msgLab);
        make.height.mas_offset(Handle_height(16));
    }];
    
    [self.bgView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(kSpaceToTop-2);
        make.left.mas_equalTo(5);
        make.right.mas_equalTo(-5);
        make.bottom.mas_equalTo(-(kSpaceToTop-2));
    }];
}

#pragma mark - getter

- (UIButton *)levelBtn
{
    if(!_levelBtn)
    {
        _levelBtn = InsertTitleAndImageButton(nil, CGRectZero, 99, @"", UIEdgeInsetsZero, SystemFontSize10, [UIColor whiteColor], nil, nil, nil, self, nil);
        [_levelBtn setImage:GetImage(@"start_level") forState:UIControlStateNormal];
        [_levelBtn setBackgroundImage:GetImage(@"level_user_bg") forState:UIControlStateNormal];
        _levelBtn.layer.cornerRadius = Handle(2);
        _levelBtn.layer.masksToBounds = YES;
        _levelBtn.imageEdgeInsets = UIEdgeInsetsMake(0, -Handle(3), 0, 0);
    }
    return _levelBtn;
}

- (UILabel *)msgLab
{
    if(!_msgLab)
    {
        _msgLab = InsertLabelWithShadow(nil, CGRectZero, NSTextAlignmentLeft, @"", SystemFontSize14, [UIColor whiteColor], YES, UIColorFromHEXA(0x000000, 0.35), CGSizeMake(0.5, 0));
        _msgLab.numberOfLines = 0;
        
    }
    return _msgLab;
}

- (UIButton *)nickBtn
{
    if(!_nickBtn)
    {
        _nickBtn = InsertTitleAndImageButton(nil, CGRectZero, 0, @"", UIEdgeInsetsZero, SystemFontSize14, [UIColor clearColor], nil, nil, nil, self, @selector(nickBtnClick));
        _nickBtn.hidden = YES;
    }
    return _nickBtn;
}

- (UIImageView *)iconImg
{
    if(!_iconImg)
    {
        _iconImg = InsertImageView(nil, CGRectZero, nil);
    }
    return _iconImg;
}
- (UIView *)bgView
{
    if(!_bgView)
    {
        _bgView =[UIView new];
        _bgView.backgroundColor=[UIColor colorWithWhite:0.f alpha:0.15];
         _bgView.layer.cornerRadius = 5;
    }
    return _bgView;
}
@end
