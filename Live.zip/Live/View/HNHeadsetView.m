//
//  HNHeadsetView.m
//  SunsetLive
//
//  Created by 龙骏 on 2018/8/28.
//  Copyright © 2018年 HN. All rights reserved.
//

#import "HNHeadsetView.h"
#import "HNHeadsetTableViewCell.h"
#import "HNLiveAnchorModel.h"
#import "HNHttpRequest.h"
//#import "UIButton+ImageTitleSpacing.h"
@interface HNHeadsetView ()<UITableViewDelegate, UITableViewDataSource>

@property(strong,nonatomic) UIView *bgView;
@property(strong,nonatomic) UILabel *titelLable;
@property (nonatomic, strong) NSMutableArray<HNLiveAnchorModel *> *congUserIdArr;
@property(assign,nonatomic) NSInteger type;

@end
@implementation HNHeadsetView
static NSString * const reuseIdentifier = @"HNHeadsetTableViewCell";
-(instancetype)initWithFrame:(CGRect)frame{
    self=[super initWithFrame:frame];
    if (self) {
        [self loadUI:frame];
    }
    return self;
}

-(void)loadUI:(CGRect )frame{
    self.bgView=[[UIView alloc]initWithFrame:CGRectMake(0, SCREEN_HEIGHT, SCREEN_WIDTH, Handle(450 / 2)+40)];
    self.bgView.backgroundColor=[UIColor whiteColor];
    UIView *header=[[UIView alloc]initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, 40)];
    header.backgroundColor=[UIColor lightGrayColor];
    _titelLable=[[UILabel alloc]initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, 39)];
    _titelLable.backgroundColor=[UIColor whiteColor];
//    titelLable.textAlignment=NSTextAlignmentCenter;
    _titelLable.text=@"  连麦";
    [header addSubview: _titelLable];
    self.tableView=[[UITableView alloc]initWithFrame:CGRectMake(0, 40, SCREEN_WIDTH, Handle(450 / 2))];
    self.tableView.delegate=self;
    self.tableView.dataSource=self;
    self.tableView.rowHeight=70;
    self.tableView.tableFooterView=[UIView new];
    [self.tableView registerNib:[UINib nibWithNibName:reuseIdentifier bundle:nil] forCellReuseIdentifier:reuseIdentifier];
    [self.bgView addSubview:header];
    [self.bgView addSubview:self.tableView];
    [self addSubview:self.bgView];
    
}
-(void)show:(NSInteger)type congUserIdArr:(NSMutableArray *)congUserIdArr{
    
    self.type = type;
    self.congUserIdArr = congUserIdArr;
    if (type==0){
        self.tableView.hidden = YES;
        UIButton *coninglBtn=[[UIButton alloc]init];
        coninglBtn.frame=CGRectMake((SCREEN_WIDTH - 120)/2, (self.bgView.height-120)/2, 120, 120);
//        [coninglBtn setTitle:@"连麦" forState:UIControlStateNormal];
        [coninglBtn setImage:[UIImage imageNamed:@"apply"] forState:UIControlStateNormal];
        [coninglBtn setTitleColor:BtnBgColor forState:UIControlStateNormal];
        [coninglBtn addTarget:self action:@selector(applyBtnAction) forControlEvents:UIControlEventTouchUpInside];
        [self.bgView addSubview:coninglBtn];
        
        UIButton *cancelapplyBtn=[[UIButton alloc]init];
        cancelapplyBtn.frame=CGRectMake((SCREEN_WIDTH-X(300))/2, Handle(450 / 2)-20,X(300), 40);
        cancelapplyBtn.backgroundColor = UIColorFromRGBA(36, 213, 201, 1);
        [cancelapplyBtn setTitle:@"申请连麦" forState:UIControlStateNormal];
         cancelapplyBtn.layer.cornerRadius = 20;
        [cancelapplyBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        [cancelapplyBtn addTarget:self action:@selector(applyBtnAction) forControlEvents:UIControlEventTouchUpInside];
        [self.bgView addSubview:cancelapplyBtn];
//        UIButton *lable=[[UIButton alloc]initWithFrame:CGRectMake(0, CGRectGetMaxY(coninglBtn.frame), SCREEN_WIDTH, 39)];
//        lable.backgroundColor=[UIColor whiteColor];
////        lable.textAlignment=NSTextAlignmentCenter;
//        lable.text=@"申请连麦";
//        [self.bgView addSubview: lable];
    }else if (type==1) {
        self.tableView.frame=CGRectMake(0, 40, SCREEN_WIDTH, Handle(450 / 2)-40);
        UIButton *cancelapplyBtn=[[UIButton alloc]init];
        cancelapplyBtn.frame=CGRectMake((SCREEN_WIDTH-X(300))/2, Handle(450 / 2)-20,X(300), 40);
        cancelapplyBtn.backgroundColor = UIColorFromRGBA(36, 213, 201, 1);
        [cancelapplyBtn setTitle:@"取消申请" forState:UIControlStateNormal];
        [cancelapplyBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        cancelapplyBtn.layer.cornerRadius = 20;
        [cancelapplyBtn addTarget:self action:@selector(cancelBtnAction) forControlEvents:UIControlEventTouchUpInside];
        [self.bgView addSubview:cancelapplyBtn];
    }else if (type==2) {
        self.tableView.frame=CGRectMake(0, 40, SCREEN_WIDTH, Handle(450 / 2)-40);
        UIButton *cancelBtn=[[UIButton alloc]init];
        cancelBtn.frame=CGRectMake((SCREEN_WIDTH-X(300))/2, Handle(450 / 2)-20,X(300), 40);
        cancelBtn.backgroundColor = UIColorFromRGBA(36, 213, 201, 1);
        [cancelBtn setTitle:@"取消连麦" forState:UIControlStateNormal];
        [cancelBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        cancelBtn.layer.cornerRadius = 20;
        [cancelBtn addTarget:self action:@selector(cancelapplyBtnAction) forControlEvents:UIControlEventTouchUpInside];
        [self.bgView addSubview:cancelBtn];
    }else if (type==3) {
        if (!congUserIdArr || congUserIdArr.count==0) {
            UILabel *tipLable = [[UILabel alloc]initWithFrame:self.tableView.frame];
            tipLable.textColor = CString(SubtitleColor);;
            tipLable.text = @"暂无连麦申请";
            tipLable.textAlignment = NSTextAlignmentCenter;
            [self.bgView addSubview:tipLable];
        }
        self.titelLable.text=@"  连麦申请";
    }else if (type==4) {
       
           UIButton *agree = [[UIButton alloc]init];
           CGFloat interval =self.tableView.width/12;
           CGFloat agreewidth =self.tableView.width/3;
            agree.frame = CGRectMake(interval*3 +agreewidth, (self.tableView.height-agreewidth)/2+40, agreewidth, agreewidth);
            [agree setTitle:@"同意" forState:UIControlStateNormal];
            agree.backgroundColor = UIColorFromRGBA(37, 217, 204, 1);
            agree.layer.cornerRadius = agreewidth/2;
            [agree.layer setBorderWidth:5.0];
        
//            CGColorSpaceRef colorSpace = CGColorSpaceCreateDeviceRGB();
//            CGColorRef colorref = CGColorCreate(colorSpace,(CGFloat[]){ 0, 0, 0, 1 });
            agree.layer.borderColor=[UIColor whiteColor].CGColor;

            [agree addTarget:self action:@selector(connectBtnAction) forControlEvents:UIControlEventTouchUpInside];
            [self.bgView addSubview:agree];
        
            UIButton *refuse = [[UIButton alloc]init];
            refuse.frame = CGRectMake(interval, (self.tableView.height-agreewidth)/2+40, agreewidth, agreewidth);
            [refuse setTitle:@"拒绝" forState:UIControlStateNormal];
            refuse.backgroundColor = UIColorFromRGBA(253, 125, 96, 1);
            refuse.layer.cornerRadius = agreewidth/2;
            [refuse.layer setBorderWidth:5.0];
            refuse.layer.borderColor=[UIColor whiteColor].CGColor;
            [refuse addTarget:self action:@selector(cancelBtnAction) forControlEvents:UIControlEventTouchUpInside];
            [self.bgView addSubview:refuse];
            self.tableView.backgroundColor = UIColorFromRGBA(248, 243, 247, 1);
            self.titelLable.backgroundColor = UIColorFromRGBA(248, 243, 247, 1);
    }
    self.frame=[UIApplication sharedApplication].keyWindow.bounds;
    [[UIApplication sharedApplication].keyWindow addSubview:self];
    [UIView animateWithDuration:0.25 animations:^{
        self.bgView.transform = CGAffineTransformMakeTranslation(0, - Handle(450 / 2)-40);
    }];
    [self.tableView reloadData];
}

-(void)connectBtnAction{
   
    if (self.connectBtnBlock) {
        self.connectBtnBlock();
        [self diss];
    }
    
}
-(void)cancelBtnAction{
    _weakself;
    [HNHttpRequest  userCancelWithUid:self.anchorId Success:^(id responseObject) {
        if (CODE != 200)
        {
            [MBProgressHUD showError:responseObject[@"m"]];
            return ;
        }
        _strongSelf;
        [strongSelf.congUserIdArr enumerateObjectsWithOptions:NSEnumerationReverse usingBlock:^(id obj, NSUInteger idx, BOOL * _Nonnull stop) {
            HNLiveAnchorModel *anchorModel = obj;
            if ([anchorModel.uid isEqualToString:strongSelf.anchorId]) {
                [strongSelf.congUserIdArr removeObject:anchorModel];
                *stop = YES;
            }
        }];
        if ( strongSelf.cancelBtnBlock) {
            strongSelf.cancelBtnBlock();
        }
        [strongSelf diss];
    } failure:^(NSError *error) {
        ERROR;
    }];
    
}
-(void)cancelapplyBtnAction{
    _weakself;
    [HNHttpRequest  userCancelFlowWithUid:self.anchorId  gid:kUserID Success:^(id responseObject) {
        _strongSelf;
        if (CODE != 200)
        {
            [MBProgressHUD showError:responseObject[@"m"]];
            return ;
        }
        if ( strongSelf.cancelBtnBlock) {
            strongSelf.cancelBtnBlock();
        }
        [strongSelf diss];
    } failure:^(NSError *error) {
        ERROR;
    }];
    
}
-(void)applyBtnAction{
    if ( self.applyBtnBlock) {
        self.applyBtnBlock();
    }
    [self diss];
}

-(void)diss{
    [UIView animateWithDuration:0.25 animations:^{
         self.bgView.transform = CGAffineTransformMakeTranslation(0, 0);
    } completion:^(BOOL finished) {
         [self removeFromSuperview];
    }];
}

- (void)touchesEnded:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
     UITouch * touch = touches.anyObject;//获取触摸对象
    if (touch.view!=self.bgView && self.type != 4) {
        [self diss];
        if (self.colseBtnBlock) {
            self.colseBtnBlock();
        }
    }
}
-(void)loadData:(NSString *)uid{
    
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return self.congUserIdArr.count;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    HNHeadsetTableViewCell *cell=[tableView dequeueReusableCellWithIdentifier:reuseIdentifier forIndexPath:indexPath];
    cell.model = self.congUserIdArr[indexPath.row];
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
      _weakself;
    cell.btnActionBlock = ^(NSString *uid) {
        _strongSelf;
        NSInteger conet = 0;
         for (HNLiveAnchorModel *model in strongSelf.congUserIdArr) {
             if ([model.conetState isEqualToString:@"2"] || [model.conetState isEqualToString:@"3"]) {
                 conet ++;
             }
         }
        if (conet==3) {
            [MBProgressHUD showError:@"连麦数不能大于3个"];
            return ;
        }
        [HNHttpRequest anchorToConnectWithUid:uid Success:^(id responseObject) {
            for (HNLiveAnchorModel *model in strongSelf.congUserIdArr) {
                if ([model.uid isEqualToString:uid]) {
                    model.conetState = @"2";
                    [strongSelf.tableView reloadData];
                    break;
                }
            }
            
        } failure:^(NSError *error) {
            ERROR;
        }];
    };
   
    return cell;
}


@end
