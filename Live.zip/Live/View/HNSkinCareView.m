//
//  HNSkinCareView.m
//  SunsetLive
//
//  Created by Sunwanwan on 2017/10/25.
//  Copyright © 2017年 HN. All rights reserved.
//

#import "HNSkinCareView.h"

@interface HNSkinCareView ()

@property (nonatomic, strong) UIView *bgView;

@property (nonatomic, strong) UIView *whiteView;
@property (nonatomic, strong) UIButton *smoothBtn;  // 平滑
@property (nonatomic, strong) UIButton *naturalBtn; // 自然

@property (nonatomic, strong) UILabel *skincareLab;  // 美颜
@property (nonatomic, strong) UISlider *skincareSlider;
@property (nonatomic, strong) UILabel *whiteningLab; // 美白
@property (nonatomic, strong) UISlider *whiteningSlider;
@property (nonatomic, strong) UILabel *ruddyLab;     // 红润
@property (nonatomic, strong) UISlider *ruddySlider;

@end

@implementation HNSkinCareView

- (instancetype)init
{
    self = [super init];
    if (self)
    {
        self.backgroundColor = [UIColor clearColor];
        [self setUI];
        
        // 先从本地拿保存的值
        NSString *skinType = [[UserDefault objectForKey:kSkinType] stringValue];
        if (skinType == nil)
        {
            // 说明没有存任何值， 第一次则直接显示为平滑，
            self.smoothBtn.selected = YES;
            self.skincareSlider.value = 6;
            self.whiteningSlider.value = 6;
            self.ruddySlider.value = 6;
        }
        else
        {
            if ([skinType isEqualToString:@"1"])
            {
                self.smoothBtn.selected = YES;
                self.naturalBtn.selected = NO;
                
                [self.whiteView mas_remakeConstraints:^(MASConstraintMaker *make) {
                    make.top.mas_offset(Handle(10));
                    make.centerX.mas_equalTo(self.smoothBtn.mas_centerX);
                    make.size.mas_equalTo(CGSizeMake(Handle_width(10), Handle_height(10)));
                }];
            }
            else
            {
                self.naturalBtn.selected = YES;
                self.smoothBtn.selected = NO;
                
                [self.whiteView mas_remakeConstraints:^(MASConstraintMaker *make) {
                    make.top.mas_offset(Handle(10));
                    make.centerX.mas_equalTo(self.naturalBtn.mas_centerX);
                    make.size.mas_equalTo(CGSizeMake(Handle_width(10), Handle_height(10)));
                }];
            }
            
            self.skincareSlider.value = [[UserDefault objectForKey:kSkincareValue] floatValue];
            self.whiteningSlider.value = [[UserDefault objectForKey:kWhiteningValue] floatValue];
            self.ruddySlider.value = [[UserDefault objectForKey:kRuddyValue] floatValue];
        }
    }
    return self;
}

- (void)show
{
    UIWindow *window = [[[UIApplication sharedApplication] delegate] window];
    [window addSubview:self];
    
    self.frame  =CGRectMake(0, SCREEN_HEIGHT, SCREEN_WIDTH, SCREEN_HEIGHT);
    [UIView animateWithDuration:0.25 animations:^{
        self.transform = CGAffineTransformMakeTranslation(0, -SCREEN_HEIGHT);
    } completion:^(BOOL finished) {
        self.backgroundColor = UIColorFromHEXA(0x333333, 0.4);
    }];
}

#pragma mark - 点击空白消失
-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    UITouch *touche = [touches anyObject];
    CGPoint point =  [touche locationInView:self];
    CGFloat height = self.bgView.height;
    BOOL b =  CGRectContainsPoint(CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT -height), point);
    if (b)
    {
        self.backgroundColor = [UIColor clearColor];
        [UIView animateWithDuration:0.25 animations:^{
            self.transform = CGAffineTransformIdentity;
            
        } completion:^(BOOL finished) {
            [self removeFromSuperview];
            
            // 消失之后要保存当前值到本地
            [UserDefault setValue:self.smoothBtn.isSelected ? @(1) : @(0) forKey:kSkinType];
            [UserDefault setValue:@(self.skincareSlider.value) forKey:kSkincareValue];
            [UserDefault setValue:@(self.whiteningSlider.value) forKey:kWhiteningValue];
            [UserDefault setValue:@(self.ruddySlider.value) forKey:kRuddyValue];
            
            [UserDefault synchronize];
        }];
    }
}

#pragma mark - privateMethod

- (void)typeBtnClick:(UIButton *)btn
{
    self.smoothBtn.selected = NO;
    self.naturalBtn.selected = NO;
    
    btn.selected = YES;
    
    [self.whiteView mas_remakeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_offset(Handle(10));
        make.centerX.mas_equalTo(btn.mas_centerX);
        make.size.mas_equalTo(CGSizeMake(Handle_width(10), Handle_height(10)));
    }];
    
    if ([self.skinDelegate respondsToSelector:@selector(sliderValueChangeWithSkinCareValue:whiteningValue:ruddyValue:type:)])
    {
        [self.skinDelegate sliderValueChangeWithSkinCareValue:self.skincareSlider.value whiteningValue:self.whiteningSlider.value ruddyValue:self.ruddySlider.value type:self.smoothBtn.isSelected ? YES : NO];
    }
}

- (void)sliderValueChanged:(UISlider *)slider
{
    DLog(@"slider value%f",slider.value);
    
    if ([self.skinDelegate respondsToSelector:@selector(sliderValueChangeWithSkinCareValue:whiteningValue:ruddyValue:type:)])
    {
        [self.skinDelegate sliderValueChangeWithSkinCareValue:self.skincareSlider.value whiteningValue:self.whiteningSlider.value ruddyValue:self.ruddySlider.value type:self.smoothBtn.isSelected ? YES : NO];
    }
}

#pragma mark - setUI

- (void)setUI
{
    [self addSubview:self.bgView];
    [self.bgView addSubview:self.whiteView];
    [self.bgView addSubview:self.smoothBtn];
    [self.bgView addSubview:self.naturalBtn];
    [self.bgView addSubview:self.skincareLab];
    [self.bgView addSubview:self.skincareSlider];
    [self.bgView addSubview:self.whiteningLab];
    [self.bgView addSubview:self.whiteningSlider];
    [self.bgView addSubview:self.ruddyLab];
    [self.bgView addSubview:self.ruddySlider];
    
    [self.smoothBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.mas_equalTo(self.bgView.mas_centerX).mas_offset(-Handle(15));
        make.top.mas_offset(Handle(7.5) + Handle(20));
        make.size.mas_equalTo(CGSizeMake(Handle_width(50), Handle_height(20)));
    }];
    
    [self.naturalBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(self.bgView.mas_centerX).mas_offset(Handle(15));
        make.top.mas_offset(Handle(7.5) + Handle(20));
        make.size.mas_equalTo(CGSizeMake(Handle_width(50), Handle_height(20)));
    }];
    
    [self.whiteView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_offset(Handle(10));
        make.centerX.mas_equalTo(self.smoothBtn.mas_centerX);
        make.size.mas_equalTo(CGSizeMake(Handle_width(10), Handle_height(10)));
    }];
    
    [self.skincareLab mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_offset(Handle(30));
        make.top.mas_equalTo(self.smoothBtn.mas_bottom).mas_offset(Handle(44));
    }];
    
    [self.skincareSlider mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.mas_equalTo(self.skincareLab.mas_centerY);
        make.left.mas_equalTo(self.skincareLab.mas_right).mas_offset(Handle(15));
        make.right.mas_offset(-Handle(30));
        make.height.mas_offset(Handle_height(30));
    }];
    
    [self.whiteningLab mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_offset(Handle(30));
        make.top.mas_equalTo(self.skincareLab.mas_bottom).mas_offset(Handle(40));
    }];
    
    [self.whiteningSlider mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.mas_equalTo(self.whiteningLab.mas_centerY);
        make.left.mas_equalTo(self.whiteningLab.mas_right).mas_offset(Handle(15));
        make.right.mas_offset(-Handle(30));
        make.height.mas_offset(Handle_height(30));
    }];
    
    [self.ruddyLab mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_offset(Handle(30));
        make.top.mas_equalTo(self.whiteningLab.mas_bottom).mas_offset(Handle(44));
    }];
    
    [self.ruddySlider mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.mas_equalTo(self.ruddyLab.mas_centerY);
        make.left.mas_equalTo(self.ruddyLab.mas_right).mas_offset(Handle(15));
        make.right.mas_offset(-Handle(30));
        make.height.mas_offset(Handle_height(30));
    }];
    
}

#pragma mark - getter

- (UIView *)bgView
{
    if(!_bgView)
    {
        _bgView = InsertView(nil, CGRectMake(0, SCREEN_HEIGHT - Handle_height(510 / 2), SCREEN_WIDTH, Handle_height(510 / 2)), UIColorFromHEXA(0x000000, 0.8));
    }
    return _bgView;
}

- (UIView *)whiteView
{
    if(!_whiteView)
    {
        _whiteView = InsertView(nil, CGRectZero, [UIColor whiteColor]);
        _whiteView.layer.cornerRadius = Handle(5);
        _whiteView.layer.masksToBounds = YES;
    }
    return _whiteView;
}

- (UIButton *)smoothBtn
{
    if(!_smoothBtn)
    {
        _smoothBtn = InsertTitleAndImageButton(nil, CGRectZero, 444, @"平滑", UIEdgeInsetsZero, SystemFontSize14, UIColorFromHEXA(0xCCCCCC, 0.48), nil, nil, nil, self, @selector(typeBtnClick:));
        [_smoothBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateSelected];
        
        _smoothBtn.selected = YES;
    }
    return _smoothBtn;
}

- (UIButton *)naturalBtn
{
    if(!_naturalBtn)
    {
        _naturalBtn = InsertTitleAndImageButton(nil, CGRectZero, 445, @"自然", UIEdgeInsetsZero, SystemFontSize14, UIColorFromHEXA(0xCCCCCC, 0.48), nil, nil, nil, self, @selector(typeBtnClick:));
        [_naturalBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateSelected];

    }
    return _naturalBtn;
}

- (UILabel *)skincareLab
{
    if(!_skincareLab)
    {
        _skincareLab = InsertLabel(nil, CGRectZero, NSTextAlignmentRight, @"美颜", SystemFontSize15, [UIColor whiteColor]);
    }
    return _skincareLab;
}

- (UISlider *)skincareSlider
{
    if (!_skincareSlider)
    {
        _skincareSlider = [[UISlider alloc] initWithFrame:CGRectZero];
        _skincareSlider.minimumValue = 0;
        _skincareSlider.maximumValue = 9;
        _skincareSlider.value = 6;
        
        [_skincareSlider setContinuous:YES];
        _skincareSlider.minimumTrackTintColor = BtnBgColor;
        _skincareSlider.maximumTrackTintColor = UIColorFromHEXA(0xCCCCCC, 0.48);
        
        [_skincareSlider addTarget:self action:@selector(sliderValueChanged:) forControlEvents:UIControlEventValueChanged];
    }
    return _skincareSlider;
}

- (UILabel *)whiteningLab
{
    if(!_whiteningLab)
    {
        _whiteningLab = InsertLabel(nil, CGRectZero, NSTextAlignmentRight, @"美白", SystemFontSize15, [UIColor whiteColor]);
    }
    return _whiteningLab;
}

- (UISlider *)whiteningSlider
{
    if (!_whiteningSlider)
    {
        _whiteningSlider = [[UISlider alloc] initWithFrame:CGRectZero];
        _whiteningSlider.minimumValue = 0;
        _whiteningSlider.maximumValue = 9;
        _whiteningSlider.value = 6;
        
        [_whiteningSlider setContinuous:YES];
        _whiteningSlider.minimumTrackTintColor = BtnBgColor;
        _whiteningSlider.maximumTrackTintColor = UIColorFromHEXA(0xCCCCCC, 0.48);
        
        [_whiteningSlider addTarget:self action:@selector(sliderValueChanged:) forControlEvents:UIControlEventValueChanged];
    }
    return _whiteningSlider;
}

- (UILabel *)ruddyLab
{
    if(!_ruddyLab)
    {
        _ruddyLab = InsertLabel(nil, CGRectZero, NSTextAlignmentRight, @"红润", SystemFontSize15, [UIColor whiteColor]);
    }
    return _ruddyLab;
}

- (UISlider *)ruddySlider
{
    if (!_ruddySlider)
    {
        _ruddySlider = [[UISlider alloc] initWithFrame:CGRectZero];
        _ruddySlider.minimumValue = 0;
        _ruddySlider.maximumValue = 9;
        _ruddySlider.value = 6;
        
        [_ruddySlider setContinuous:YES];
        _ruddySlider.minimumTrackTintColor = BtnBgColor;
        _ruddySlider.maximumTrackTintColor = UIColorFromHEXA(0xCCCCCC, 0.48);
        
        [_ruddySlider addTarget:self action:@selector(sliderValueChanged:) forControlEvents:UIControlEventValueChanged];
    }
    return _ruddySlider;
}


@end
