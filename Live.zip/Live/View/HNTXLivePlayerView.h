//
//  HNTXLivePlayerView.h
//  SunsetLive
//
//  Created by Sunwanwan on 2017/10/11.
//  Copyright © 2017年 HN. All rights reserved.
//  腾讯云拉流

#import <UIKit/UIKit.h>

@interface HNTXLivePlayerView : UIView

+ (instancetype)livePlayerView;

@property (nonatomic, strong) NSString *rtmpURL;
@property (nonatomic, strong) NSString *uid;
@property (nonatomic, copy) void(^netStatusBlock) (NSString *spd);  // 下载速度
@property (nonatomic, copy) void(^colseBlock) (void);  // 

// 开始播放
- (void)startPlay;

// 停止播放
- (void)stopPlay;

// 暂停播放
- (void)pausePlay;

- (void)resumePlay;
@end
