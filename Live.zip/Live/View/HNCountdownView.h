//
//  HNCountdownView.h
//  SunsetLive
//
//  Created by Sunwanwan on 2017/10/31.
//  Copyright © 2017年 HN. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HNCountdownView : UIView

@property (nonatomic, strong) NSString *liveType;
@property (nonatomic, assign) NSInteger countDownTime;

@end
