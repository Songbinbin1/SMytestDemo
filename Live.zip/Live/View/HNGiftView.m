//
//  HNGiftView.m
//  SunsetLive
//
//  Created by Sunwanwan on 2017/11/14.
//  Copyright © 2017年 HN. All rights reserved.
//

#import "HNGiftView.h"

@interface HNGiftView ()

@property (nonatomic, strong) UIImageView *icomImg;
@property (nonatomic, strong) UILabel *nameLab;
@property (nonatomic, strong) UILabel *priceLab;
@property (nonatomic, strong) UILabel *bigIconLab;



@end

@implementation HNGiftView

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self)
    {
        self.backgroundColor = [UIColor clearColor];
        [self setUI];
    }
    return self;
}

#pragma mark - privateMethod

- (void)setModel:(HNGiftListModel *)model
{
    _model = model;
    
    [self.icomImg sd_setImageWithURL:[NSURL URLWithString:[HNTools pictureStr:model.icon]] placeholderImage:nil];
    
    self.nameLab.text = model.name;
    self.priceLab.text = [model.coin integerValue]!=0?model.coin:@"免费";
    
    if (model.animation.length > 0 && [model.animation hasPrefix:@"http"])
    {
        self.bigIconLab.hidden = NO;
    }
    else
    {
        self.bigIconLab.hidden = YES;
    }
}

- (void)setSelected:(BOOL)selected
{
    if (selected)
    {
        self.layer.borderColor = BtnBgColor.CGColor;
        self.layer.borderWidth = Handle(0.5);
        
        // 没有gif动画， 自己做一个放大缩小的动画
        if ([self.model.icon_gif isEqualToString:@""])
        {
            CAKeyframeAnimation *anima = [CAKeyframeAnimation animationWithKeyPath:@"transform"];//同上
            NSMutableArray *values = [NSMutableArray array];
            
            [values addObject:[NSValue valueWithCATransform3D:CATransform3DMakeScale(0.5, 0.5, 1.0)]];
            [values addObject:[NSValue valueWithCATransform3D:CATransform3DMakeScale(0.9, 0.9, 1.0)]];
            [values addObject:[NSValue valueWithCATransform3D:CATransform3DMakeScale(0.9, 0.9, 1.0)]];
            [values addObject:[NSValue valueWithCATransform3D:CATransform3DMakeScale(0.5, 0.5, 1.0)]];
            
            anima.values = values;
            anima.duration = 2.0;
            anima.repeatCount = 5;
            [self.icomImg.layer addAnimation:anima forKey:@"scaleAnimation"];
        }
        else
        {
            [self.icomImg sd_setImageWithURL:[NSURL URLWithString:self.model.icon_gif] placeholderImage:self.icomImg.image];
        }
    }
    else
    {
        [self.icomImg.layer removeAllAnimations];
        [self.icomImg sd_setImageWithURL:[NSURL URLWithString:self.model.icon]];
        
        self.layer.borderColor = [UIColor clearColor].CGColor;
        self.layer.borderWidth = 0.0;
    }
}

#pragma mark - setUI

- (void)setUI
{
    [self addSubview:self.icomImg];
    [self addSubview:self.nameLab];
    [self addSubview:self.priceLab];
    [self addSubview:self.bigIconLab];
    [self addSubview:self.clickBtn];
    
    [self.icomImg mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_offset(Handle_height(7));
        make.centerX.mas_equalTo(self);
        make.size.mas_equalTo(CGSizeMake(Handle_width(50), Handle_height(50)));
    }];
    
    [self.nameLab mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.mas_equalTo(self.icomImg.mas_centerX);
        make.top.mas_offset(Handle_height(130 / 2));
    }];
    
    [self.priceLab mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.mas_equalTo(self.nameLab.mas_centerX);
        make.top.mas_equalTo(self.nameLab.mas_bottom).mas_offset(Handle(3));
    }];
    
    [self.bigIconLab mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.mas_equalTo(self);
        make.top.mas_equalTo(self.mas_top).mas_offset(Handle(4));
        make.size.mas_equalTo(CGSizeMake(Handle_width(58 / 2), Handle_height(15)));
    }];
    
    [self.clickBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.left.width.height.mas_equalTo(self);
    }];
}

#pragma mark - getter

- (UIImageView *)icomImg
{
    if(!_icomImg)
    {
        _icomImg = InsertImageView(nil, CGRectZero, GetImage(@""));
    }
    return _icomImg;
}

- (UILabel *)nameLab
{
    if(!_nameLab)
    {
        _nameLab = InsertLabel(nil, CGRectZero, NSTextAlignmentCenter, @"", SystemFontSize12, UIColorFromHEXA(0xFFFDFD, 1.0));
    }
    return _nameLab;
}

- (UILabel *)priceLab
{
    if(!_priceLab)
    {
        _priceLab = InsertLabel(nil, CGRectZero, NSTextAlignmentCenter, @"", SystemFontSize12, UIColorFromHEXA(0xFFFFFF, 0.4));
    }
    return _priceLab;
}

- (UILabel *)bigIconLab
{
    if(!_bigIconLab)
    {
        _bigIconLab = InsertLabel(nil, CGRectZero, NSTextAlignmentCenter, @"飘屏", SystemFontSize10, [UIColor whiteColor]);
        _bigIconLab.backgroundColor = UIColorFromHEXA(0xEE2c11, 1.0);
        _bigIconLab.layer.cornerRadius = Handle(1);
        _bigIconLab.layer.masksToBounds = YES;
        
        _bigIconLab.hidden = YES;
    }
    return _bigIconLab;
}
- (UIButton *)clickBtn
{
    if(!_clickBtn)
    {
        _clickBtn = InsertImageButton(nil, CGRectZero, 99, nil, nil, self, nil);
    }
    return _clickBtn;
}

@end
