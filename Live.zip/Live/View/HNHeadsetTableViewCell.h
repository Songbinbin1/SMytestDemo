//
//  HNHeadsetTableViewCell.h
//  SunsetLive
//
//  Created by 龙骏 on 2018/8/28.
//  Copyright © 2018年 HN. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "HNLiveAnchorModel.h"
typedef void (^BtnActionBlock)(NSString *uid);
@interface HNHeadsetTableViewCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *nameLable;
@property (weak, nonatomic) IBOutlet UIButton *stateBtn;

@property (weak, nonatomic) IBOutlet UIImageView *iamgeView;
@property (strong, nonatomic)  HNLiveAnchorModel *model;
@property (copy, nonatomic)  BtnActionBlock btnActionBlock;
@end
