//
//  HNLiveChatMessageVC.m
//  SunsetLive
//
//  Created by Sunwanwan on 2017/9/15.
//  Copyright © 2017年 HN. All rights reserved.
//

#import "HNLiveChatMessageVC.h"
#import "HNChatTable.h"
#import "HNChatToolsView.h"
#import "HNChatTableCell.h"
#import "HNChatHeaderFollowView.h"

@interface HNLiveChatMessageVC () <HNChatToolsViewDelegate>
{
    NSInteger _page;
}

@property (nonatomic, strong) UIView *headerView;
@property (nonatomic, strong) UILabel *descLab;
@property (nonatomic, strong) UIButton *backBtn;
@property (nonatomic, strong) UIButton *exitBtn;
@property (nonatomic, strong) UIView *line;

@property (nonatomic, strong) HNChatTable *chatTable;
@property (nonatomic, strong) HNChatToolsView *toolsView;
@property (nonatomic, strong) HNChatHeaderFollowView *followView;

@property (nonatomic, strong) NSMutableArray *chatList;
@property (nonatomic, assign) BOOL isFollow;

@end

@implementation HNLiveChatMessageVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
     self.view.backgroundColor = [UIColor clearColor];
    self.automaticallyAdjustsScrollViewInsets = NO;
    
    [self setUI];
    _page = 0;
    [self.chatTable.mj_header beginRefreshing];
    
    self.descLab.text = self.nick;
    
    // 添加通知
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(keyboardChange:) name:UIKeyboardWillShowNotification object:nil];
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(keyboardChange:) name:UIKeyboardWillHideNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(receiveMessage:) name:@"privateMessage" object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(followUser) name:@"followOneUser" object:nil];
    //收回表情键盘事件
#define kXJH_Tap_Open 1
#if kXJH_Tap_Open
    [self.view addGestureRecognizer:({
        [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(didTapView:)];
    })];
#endif
}


#if kXJH_Tap_Open
- (void)didTapView:(UITapGestureRecognizer *)tap
{
    //表情键盘
    if (_toolsView.emojiScrollView.hidden == NO) {
        
        // 点击表情键盘空白处，会触发收回键盘
        // 如果点击不在 屏幕上半部分，不处理
        CGPoint point = [tap locationInView:self.view];
        CGRect rect = CGRectMake(0, kNavigationHeight, SCREEN_WIDTH, _toolsView.emojiScrollView.mj_y - kNavigationHeight);
        if (CGRectContainsPoint(rect, point) == false) {
            return;
        }
        
        [UIView animateWithDuration:0.25 animations:^{
            _toolsView.emojiBtn.selected = NO;
            _toolsView.emojiScrollView.mj_y = SCREEN_HEIGHT - ChatToolsHeight;
            
            _toolsView.mj_y = SCREEN_HEIGHT - _toolsView.mj_h;
            _chatTable.mj_y = _toolsView.mj_y - _chatTable.mj_h;
            _headerView.mj_y = _chatTable.mj_y - _headerView.mj_h;
            _followView.mj_y = _headerView.mj_y + _headerView.mj_h;
        }];
        
    }
    //输入框
    //    else{
    [_toolsView.TextViewInput resignFirstResponder];
    //    }
}
#endif

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - loadData

- (void)loadChatListWithPage:(NSInteger)page
{
    NSDictionary *dic = @{
                          @"uid" : self.uid,
                          @"page" : @(page)
                          };
    
    [[HNRequestManager manager] sendRequestWithRequestMethodType:HNRequestMethodTypePOST requestAPICode:MessageDetail requestParameters:dic requestHeader:@{@"authorization" : kTOKEN} success:^(id responseObject) {
        
        [self.chatTable.mj_header endRefreshing];
        
        if (CODE != 200)
        {
            MBErrorMsg;
            return ;
        }
        
        NSArray *array = [NSArray yy_modelArrayWithClass:[HNChatMsgModel class] json:responseObject[@"d"][@"msg_list"][@"items"]];
        
        NSDictionary *meDic = responseObject[@"d"][@"my_info"];
        NSDictionary *otherDic = responseObject[@"d"][@"g_info"];
        
        
        for (HNChatMsgModel *model in array)
        {
            if ([model.uid isEqualToString:meDic[@"uid"]])
            {
                model.avatar = meDic[@"avatar"];
            }
            
            if ([model.uid isEqualToString:otherDic[@"uid"]])
            {
                model.avatar = otherDic[@"avatar"];
            }
        }
        
        if (page == 1)
        {
            self.chatList = [NSMutableArray arrayWithArray:array];
            
            BOOL isFollow = [responseObject[@"d"][@"is_follow"] boolValue];
            self.isFollow = isFollow;
            
            self.chatList = (NSMutableArray *)[[self.chatList reverseObjectEnumerator] allObjects];
        }
        else
        {
            self.chatList = (NSMutableArray *)[[self.chatList objectEnumerator] allObjects];
            
            [self.chatList addObjectsFromArray:array];
            
            self.chatList = (NSMutableArray *)[[self.chatList reverseObjectEnumerator] allObjects];
        }
        
        if (self.chatList.count == [responseObject[@"d"][@"msg_list"][@"total"] integerValue])
        {
            self.chatTable.mj_header = nil;
        }
        
        self.chatTable.dataSourceArray = self.chatList;
        
        [self.chatTable reloadData];
        
        // 滚动到视图底部
        if (page == 1)
        {
            if(self.chatList.count != 0)
            {
                NSIndexPath* indexPath = [NSIndexPath indexPathForRow:self.chatList.count-1 inSection:0];
                [self.chatTable scrollToRowAtIndexPath:indexPath atScrollPosition:UITableViewScrollPositionTop animated:NO];
            }
        }
        
        // 是否动画显示关注视图
        if (self.isFollow == NO)
        {
            [self.view addSubview:self.followView];
            [UIView animateWithDuration:0.25 animations:^{
                self.followView.frame = CGRectMake(0, self.headerView.bottom, SCREEN_WIDTH, Handle_height(75 / 2));
            }];
        }
        
    } faild:^(NSError *error) {
        
        [self.chatTable.mj_header endRefreshing];
        ERROR;
    }];
}

#pragma mark - 关注用户

- (void)followUser
{
    NSDictionary *dic = @{
                          @"type" : @"add",
                          @"uid" : self.uid
                          };
    
    [[HNRequestManager manager] sendRequestWithRequestMethodType:HNRequestMethodTypePOST requestAPICode:ChangeFollow requestParameters:dic requestHeader:@{@"authorization" : kTOKEN} success:^(id responseObject) {
        
        if (CODE != 200)
        {
            MBErrorMsg;
            return ;
        }
        
        [MBProgressHUD showSuccess:@"关注成功"];
        
        // 发一个通知到界面上， 处理主播头像区域的关注按钮
        [[NSNotificationCenter defaultCenter] postNotificationName:@"FollowAnchorSuccess" object:nil];
        
        self.isFollow = YES;
        
        [self.followView removeFromSuperview];
   
    } faild:^(NSError *error) {
        ERROR;
    }];
}

#pragma mark - 收到聊天消息

- (void)receiveMessage:(NSNotification *)noti
{
    NSDictionary *dict = noti.userInfo;
    
    HNChatMsgModel *model = [HNChatMsgModel yy_modelWithJSON:dict[@"user_info"]];
    model.msg_content = dict[@"content"][@"word"];
    model.add_time = dict[@"content"][@"add_time"];
    
    [self.chatList insertObject:model atIndex:self.chatList.count];
    
    NSIndexPath* indexPath = [NSIndexPath indexPathForRow:self.chatList.count - 1 inSection:0];
    [self.chatTable insertRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationBottom];
    [self.chatTable scrollToRowAtIndexPath:indexPath atScrollPosition:UITableViewScrollPositionBottom animated:YES];
}

#pragma mark - 退出对话详情

- (void)exitMessageDetail
{
    NSDictionary *dic = @{
                          @"uid" : self.uid
                          };
    
    [[HNRequestManager manager] sendRequestWithRequestMethodType:HNRequestMethodTypePOST requestAPICode:QuitChat requestParameters:dic requestHeader:@{@"authorization" : kTOKEN} success:^(id responseObject) {
        
        if (CODE != 200)
        {
            
            return ;
        }
        
        // 发个通知处理用户的总的未读消息数
        NSString *total_unread = responseObject[@"d"][@"total_unread"];
        
        [UserDefault setValue:total_unread forKey:UnreadMessageCount];
        [UserDefault synchronize];
        
        [[NSNotificationCenter defaultCenter] postNotificationName:kChangeTotalUnread object:nil userInfo:@{kUnReadKey:total_unread}];
        
        // 处理当前用户在消息列表里面的未读小红点显示
        if (self.chatList.count > 0)
        {
            [[NSNotificationCenter defaultCenter] postNotificationName:@"ChangeCurrentIDUnread" object:nil userInfo:@{@"model" : [self.chatList lastObject],@"uid" : self.uid}];
        }
        else
        {
            [[NSNotificationCenter defaultCenter] postNotificationName:@"ChangeCurrentIDUnread" object:nil userInfo:@{@"uid" : self.uid}];
        }
        
        // 在这里发一个通知到消息界面， 把当前用户的未读消息数处理了
        [[NSNotificationCenter defaultCenter] postNotificationName:@"allMessageisReadWithUser" object:nil userInfo:@{@"uid" : self.uid}];
        
        [self.navigationController popViewControllerAnimated:YES];
        
    } faild:^(NSError *error) {
        
    }];
}

#pragma mark - MJRefresh

- (void)headerRefreshing
{
    _page ++;
    [self loadChatListWithPage:_page];
}

#pragma mark - HNChatToolsViewDelegate

- (void)InputFunctionView:(HNChatToolsView *)funcView sendMessage:(NSString *)message
{
    if (message.length == 0)
    {
        [MBProgressHUD showError:@"请输入聊天信息"];
        return;
    }
    
    NSDictionary *dic = @{
                          @"word" : message,
                          @"uid" : self.uid
                          };
    [[HNRequestManager manager] sendRequestWithRequestMethodType:HNRequestMethodTypePOST requestAPICode:SendMessage requestParameters:dic requestHeader:@{@"authorization" : kTOKEN} success:^(id responseObject) {
        
        if (CODE != 200)
        {
            MBErrorMsg;
            return ;
        }
        
        HNChatMsgModel *model = [HNChatMsgModel yy_modelWithJSON:responseObject[@"d"]];
        
        model.avatar = myAvatar;
                
        [self changeCurrentVCData:model];
        
    } faild:^(NSError *error) {
        ERROR;
    }];
}

// 点击表情按钮
- (void)emojiKeyboardClick:(UIButton *)btn
{
    // 退出聊天时隐藏、点击表情按钮时显示
    self.toolsView.emojiScrollView.hidden = NO;

    [self.view layoutIfNeeded];

    [UIView animateWithDuration:0.25 animations:^{
        
        CGRect ToolsViewRect = self.toolsView.frame;
        CGRect emojiScrollViewRect = self.toolsView.emojiScrollView.frame;
        CGRect tableFrame = self.chatTable.frame;
        CGRect headerFrame = self.headerView.frame;
        CGRect followFrame = self.followView.frame;
        
        if (btn.selected == YES) {
            [self.toolsView.TextViewInput resignFirstResponder];
            
            emojiScrollViewRect.origin.y = self.view.height - EmojiKeyboard_Height;
            self.toolsView.emojiScrollView.frame = emojiScrollViewRect;
        }
        else
        {
            [self.toolsView.TextViewInput becomeFirstResponder];
            
            emojiScrollViewRect.origin.y = SCREEN_HEIGHT;
            self.toolsView.emojiScrollView.frame = emojiScrollViewRect;
        }
        
        ToolsViewRect.origin.y = self.view.height - EmojiKeyboard_Height - self.toolsView.frame.size.height;
        self.toolsView.frame = ToolsViewRect;
        
        tableFrame.origin.y = ToolsViewRect.origin.y - tableFrame.size.height;
        self.chatTable.frame = tableFrame;
        
        headerFrame.origin.y = tableFrame.origin.y - headerFrame.size.height;
        self.headerView.frame = headerFrame;
        
        followFrame.origin.y = headerFrame.origin.y + headerFrame.size.height;
        self.followView.frame = followFrame;
        
        [self tableViewScrollToBottom];
    }];
}

// 更新列表frame
- (void)upDataTableViewFrameWith:(HNChatToolsView *)view
{
    [UIView animateWithDuration:0.25 animations:^{
        
        CGRect tableFrame = self.chatTable.frame;
        tableFrame.origin.y = view.frame.origin.y - tableFrame.size.height;
        self.chatTable.frame = tableFrame;
        
        CGRect headerFrame = self.headerView.frame;
        headerFrame.origin.y = tableFrame.origin.y - headerFrame.size.height;
        self.headerView.frame = headerFrame;
        
        CGRect followFrame = self.followView.frame;
        followFrame.origin.y = headerFrame.origin.y + headerFrame.size.height;
        self.followView.frame = followFrame;
        
        [self tableViewScrollToBottom];
    }];
}

#pragma mark - UIScrollView协议方法

- (void)scrollViewWillBeginDragging:(UIScrollView *)scrollView
{
    [self.view endEditing:YES];
    
    [UIView animateWithDuration:0.25 animations:^{
        CGRect ToolsViewRect = self.toolsView.frame;
        CGRect emojiScrollViewRect = self.toolsView.emojiScrollView.frame;
        
        emojiScrollViewRect.origin.y = SCREEN_HEIGHT;
        self.toolsView.emojiScrollView.frame = emojiScrollViewRect;
        
        ToolsViewRect.origin.y = SCREEN_HEIGHT - self.toolsView.frame.size.height;
        self.toolsView.frame = ToolsViewRect;
        
        self.toolsView.emojiBtn.selected = NO;
    }];
}

#pragma mark - privateMethod

- (void)changeCurrentVCData:(HNChatMsgModel *)model
{
    [self.chatList addObject:model];
    [self.chatTable reloadData];
    [self tableViewScrollToBottom];
}

//tableView Scroll to bottom
- (void)tableViewScrollToBottom
{
    if (self.chatList.count==0)
        return;
    
    NSIndexPath *indexPath = [NSIndexPath indexPathForRow:self.chatList.count-1 inSection:0];
    [self.chatTable scrollToRowAtIndexPath:indexPath atScrollPosition:UITableViewScrollPositionBottom animated:YES];
}

-(void)keyboardChange:(NSNotification *)notification
{
    NSDictionary *userInfo = [notification userInfo];
    
    NSTimeInterval animationDuration;
    UIViewAnimationCurve animationCurve;
    CGRect keyboardEndFrame;
    
    [[userInfo objectForKey:UIKeyboardAnimationCurveUserInfoKey] getValue:&animationCurve];
    [[userInfo objectForKey:UIKeyboardAnimationDurationUserInfoKey] getValue:&animationDuration];
    [[userInfo objectForKey:UIKeyboardFrameEndUserInfoKey] getValue:&keyboardEndFrame];
    
    [self.view layoutIfNeeded];

    [UIView animateWithDuration:animationDuration animations:^{
        
        CGRect newFrame = self.toolsView.frame;
       
        newFrame.origin.y = keyboardEndFrame.origin.y - newFrame.size.height;
        self.toolsView.frame = newFrame;
        
        CGRect tableFrame = self.chatTable.frame;
        CGRect headerFrame = self.headerView.frame;
        CGRect followFrame = self.followView.frame;
        
        tableFrame.origin.y = self.toolsView.frame.origin.y - tableFrame.size.height;
        self.chatTable.frame = tableFrame;
        
        headerFrame.origin.y = self.chatTable.frame.origin.y - headerFrame.size.height;
        self.headerView.frame = headerFrame;
        
        followFrame.origin.y = headerFrame.origin.y + headerFrame.size.height;
        self.followView.frame = followFrame;
        
    } completion:^(BOOL finished) {
        
        [self tableViewScrollToBottom];
        
    }];
    
    if (keyboardEndFrame.origin.y != SCREEN_HEIGHT)
    {
        self.toolsView.emojiBtn.selected = NO;
        
        CGRect emojiScrollViewRect = self.toolsView.emojiScrollView.frame;
        emojiScrollViewRect.origin.y = SCREEN_HEIGHT;
        self.toolsView.emojiScrollView.frame = emojiScrollViewRect;
    }
}

// 返回按钮处理
- (void)backBtnClick
{
    if (self.chatList.count > 0)
    {
        [self exitMessageDetail];
    }
    
    [UIView animateWithDuration:0.25 animations:^{
        
        // 退出聊天时隐藏、点击表情按钮时显示
        self.toolsView.emojiScrollView.hidden = YES;

        [self.view removeFromSuperview];
        [self removeFromParentViewController];
        
    } completion:^(BOOL finished) {
       
       
    }];

}

// 退出按钮处理
- (void)exitBtnClick
{
    if (self.chatList.count > 0)
    {
        [self exitMessageDetail];
    }
    
    [UIView animateWithDuration:0.25 animations:^{
        
        [self.view removeFromSuperview];
        [self removeFromParentViewController];
        
    } completion:^(BOOL finished) {
        
        // 退出聊天时隐藏、点击表情按钮时显示
        self.toolsView.emojiScrollView.hidden = YES;
        
        // 告诉自己的父视图，移除消息列表
        [[NSNotificationCenter defaultCenter] postNotificationName:@"liveMessageShowOrHidden" object:@"removeMessageList"];

        if (self.ExitVCEnd)
        {
            self.ExitVCEnd();
        }
        
    }];
}

#pragma mark - setUI

- (void)setUI
{
    [self.view addSubview:self.headerView];
    [self.headerView addSubview:self.backBtn];
    [self.headerView addSubview:self.descLab];
    [self.headerView addSubview:self.exitBtn];
    [self.headerView addSubview:self.line];
    
    [self.view addSubview:self.chatTable];
    [self.view addSubview:self.toolsView];
    
    [self.headerView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.width.mas_equalTo(self.view);
        make.height.mas_offset(Handle_height(85 / 2));
        make.bottom.mas_offset(-Handle(512 / 2));
    }];
    
    [self.backBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_offset(kSpaceToLeftOrRight);
        make.centerY.mas_equalTo(self.headerView.mas_centerY);
    }];
    
    [self.descLab mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.centerX.mas_equalTo(self.headerView);
    }];
    
    [self.exitBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.mas_offset(-kSpaceToLeftOrRight);
        make.centerY.mas_equalTo(self.headerView.mas_centerY);
    }];
    
    [self.line mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.width.bottom.mas_equalTo(self.headerView);
        make.height.mas_offset(Handle(0.5));
    }];
    
    [self.chatTable mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.width.mas_equalTo(self.view);
        make.top.mas_equalTo(self.headerView.mas_bottom);
        make.bottom.mas_offset(-ChatToolsHeight);
    }];
    
    [self.toolsView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.width.bottom.mas_equalTo(self.view);
        make.height.mas_offset(ChatToolsHeight);
    }];
    
    [self.view layoutIfNeeded];
}

#pragma mark - getter

- (UIView *)headerView
{
    if(!_headerView)
    {
        _headerView = InsertView(nil, CGRectZero, CString(WhiteColor));
    }
    return _headerView;
}

- (UILabel *)descLab
{
    if(!_descLab)
    {
        _descLab = InsertLabel(nil, CGRectZero, NSTextAlignmentLeft, @"", SystemFontSize18, CString(TitleColor));
    }
    return _descLab;
}

- (UIButton *)backBtn
{
    if(!_backBtn)
    {
        _backBtn = InsertImageButton(nil, CGRectZero, 888, GetImage(@"live_back"), nil, self, @selector(backBtnClick));
        
        [_backBtn setEnlargeEdgeWithTop:10 right:10 bottom:10 left:10];
    }
    return _backBtn;
}

- (UIButton *)exitBtn
{
    if(!_exitBtn)
    {
        _exitBtn = InsertImageButton(nil, CGRectZero, 999, GetImage(@"tuichu_liaotian"), nil, self, @selector(exitBtnClick));
        
        [_exitBtn setEnlargeEdgeWithTop:10 right:10 bottom:10 left:10];
    }
    return _exitBtn;
}

- (UIView *)line
{
    if(!_line)
    {
        _line = InsertView(nil, CGRectZero, CString(LineColor));
    }
    return _line;
}

- (HNChatTable *)chatTable
{
    if (!_chatTable)
    {
        _chatTable = [HNChatTable chatTable];
        
        _chatTable.dataSourceArray = self.chatList;
        
        _weakself;
        _chatTable.mj_header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
            
            [weakself headerRefreshing];
        }];
        _chatTable.mj_footer.automaticallyHidden = YES;
    }
    return _chatTable;
}

- (HNChatToolsView *)toolsView
{
    if (!_toolsView)
    {
        _toolsView = [[HNChatToolsView alloc] initWithSuperVC:self];
        _toolsView.delegate = self;
        _toolsView.placeHolder.text = @"说点什么";
    }
    return _toolsView;
}

- (HNChatHeaderFollowView *)followView
{
    if (!_followView)
    {
        _followView = [[HNChatHeaderFollowView alloc] init];
        _followView.frame = CGRectMake(0, self.headerView.bottom, SCREEN_WIDTH, 0);
    }
    return _followView;
}

@end
