//
//  HNLiveVC.m
//  LiveShow
//
//  Created by Sunwanwan on 2017/7/17.
//  Copyright © 2017年 HN. All rights reserved.
//

/**
 *  开始直播前，使用AVCaptureVideoPreviewLayer 来做一个视频预览输出， 使用相机界面录像。 这里用到的一个第三方写的一个类WCLRecordEngine
 */

#import "HNLiveVC.h"
#import "WCLRecordEngine.h"
#import "WCLRecordProgressView.h"
#import <MediaPlayer/MediaPlayer.h>
#import "HNLocationManager.h"
#import "HNPhotoChangeManager.h"
#import "HNLiveAnchorModel.h"
#import "HNAnchorLiveVC.h"
#import "HNLiveInfoModel.h"
#import "HNLiveUserModel.h"
#import "HNQiNiuUpFilesTool.h"
#import "HNTencentUploadTools.h"
#import "HNLiveChatMsgModel.h"

@interface HNLiveVC () <UITextFieldDelegate>
{
    NSString *_qiniuToken;
    NSString *_qiuniuUrl;
    NSString *_qiuniuKey;
}

//-------------------  界面UI ---------------------------
@property (nonatomic, strong) UIView *maskBgView; // 蒙版层
@property (nonatomic, strong) UIImageView *maskBGImage; //  背景图片蒙层 (暂时添加在蒙版层上面，如果需要打开预览， 则可以直接删除这一层)

@property (nonatomic, strong) UIButton *addressBtn;  // 定位地址按钮
@property (nonatomic, strong) UIButton *exitBtn;

@property (nonatomic, strong) UIView *liveInfoView;  // 视频信息视图
@property (nonatomic, strong) UITextField *liveTitleText;
@property (nonatomic, strong) UIButton *addCoverBtn; // 添加封面

@property (nonatomic, strong) UIButton *freeLiveBtn;   //

@property (nonatomic, strong) UIButton *startLiveBtn;  // 开始直播


// ------------------- 视频录制 -----------------------------
//@property (nonatomic, strong) WCLRecordEngine *recordEngine;


// ------------------- 视频相关属性
@property (nonatomic, strong) NSString *liveTitle;
@property (nonatomic, strong) NSString *liveLogoUrl;
@property (nonatomic, strong) NSString *liveAddress;
@property (nonatomic, strong) NSString *liveTyp;  // 直播类型
@property (nonatomic, strong) NSString *livePrice;

@property (nonatomic, strong) HNLiveAnchorModel *anchorModel;


@end

@implementation HNLiveVC

- (void)dealloc
{
//    self.recordEngine = nil;
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
    [self.navigationController setNavigationBarHidden:YES animated:YES];
}

- (void)viewDidLoad {
    [super viewDidLoad];
//    self.freeLiveBtn.hidden=YES;
    // Do any additional setup after loading the view.
    
    [self setUI];
    
    // 接受通知
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(exitLive) name:@"dismissPresentVC" object:nil];
    
    /*  9/15  暂时屏蔽， 看后期的版本是否要打开视频预览
    // 视频录制前准备， 视频预览
    [self recordingToVideo];
     */

}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    
//    [self.recordEngine shutdown];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - loadData

- (void)startLive
{
    NSDictionary *dic = @{
                          @"live_title" : self.liveTitle ? self.liveTitle :  @"",
                          @"live_logo" : self.liveLogoUrl ? self.liveLogoUrl : @"",
                          @"live_address" : self.liveAddress ?self.liveAddress  : @"",
                          @"live_type" : self.liveTyp,
                          @"live_price" : self.livePrice ? self.self.livePrice : @""
                          };
    _weakself;
    [[HNRequestManager manager] sendRequestWithRequestMethodType:HNRequestMethodTypePOST requestAPICode:StartLive requestParameters:dic requestHeader:@{@"authorization" : kTOKEN} success:^(id responseObject) {
        _strongSelf;
        if (CODE != 200)
        {
            HNAlertView *view = [[HNAlertView alloc] initWithTitle:@"提示" Content:responseObject[@"m"] whitTitleArray:@[@"我知道了"] withType:@"center"];
            [view showAlertView:nil];
            
            return ;
        }
        
        HNLiveAnchorModel *anchorModel = [HNLiveAnchorModel yy_modelWithJSON:responseObject[@"d"][@"anchor"]];
        HNLiveInfoModel *infoModel = [HNLiveInfoModel yy_modelWithJSON:responseObject[@"d"][@"live"]];
        
        NSArray *robotArray = [NSArray yy_modelArrayWithClass:[HNLiveUserModel class] json:responseObject[@"d"][@"robot"][@"list"]];
        NSArray *chstListArrray = [NSArray yy_modelArrayWithClass:[HNLiveChatMsgModel class] json:responseObject[@"d"][@"robot"][@"list"]];
        NSString *webSocketURL = responseObject[@"d"][@"notify"];
        
        HNAnchorLiveVC *vc = [[HNAnchorLiveVC alloc] init];
        
        vc.infoModel = infoModel;
        vc.anchorModel = anchorModel;
        vc.notify = webSocketURL;
        vc.isRecording=strongSelf.freeLiveBtn.selected;
        vc.lookUserArr = [NSMutableArray arrayWithArray:robotArray];
        vc.chatsArray = chstListArrray;
        vc.liveType = strongSelf.liveTyp;
        vc.notice = responseObject[@"d"][@"notice"];
        vc.liveImage= strongSelf.addCoverBtn.currentBackgroundImage;
        [strongSelf.navigationController pushViewController:vc animated:YES];
        
    } faild:^(NSError *error) {
        ERROR;
    }];
}

#pragma mark - privateMethod

// 退出直播
- (void)exitLive
{
    [self dismissViewControllerAnimated:YES completion:nil];
}

// 开始直播
- (void)startLiveBtnClick
{
    // 停止录制
//    [self.recordEngine shutdown];
   
        self.liveTyp = @"0";
    
   [self startLive];
}

// 点击免费直播
- (void)freeLiveBtnClick
{
     self.freeLiveBtn.selected = !self.freeLiveBtn.selected;
}

#pragma mark --------------- 定位

- (void)addressBtnClick:(UIButton *)btn
{
    // 先获取下授权信息
    if ([CLLocationManager authorizationStatus] == kCLAuthorizationStatusDenied)
    {
        NSString *string = [NSString stringWithFormat:@"允许“%@”在您使用该应用时访问您的位置吗？",kAppName];
        HNAlertView *view = [[HNAlertView alloc] initWithTitle:nil Content:string whitTitleArray:@[@"不允许",@"允许"] withType:@"center"];
        [view showAlertView:^(NSInteger index) {
            if (index == 0)
            {
                [MBProgressHUD showError:@"获取位置失败"];
                return ;
            }
            else
            {
                NSURL * url = [NSURL URLWithString:UIApplicationOpenSettingsURLString];
                
                if([[UIApplication sharedApplication] canOpenURL:url])
                {
                    [[UIApplication sharedApplication] openURL:url];
                };
            }
        }];
    }
    else
    {
        [self startLocation];
    }
}

- (void)startLocation
{
    // 开始定位
    HNLocationManager *manager = [HNLocationManager shareManager];
    
    _weakself;
    [manager getCityName:^(NSString *city, NSString *province)
     {
         NSString *string = @"";
         if (province.length == 0)
         {
             string = city;
         }
         else
         {
             string = [NSString stringWithFormat:@"%@ %@",province,city];
         }
         
         NSString *contentStr = [NSString stringWithFormat:@"%@\n%@",[NSString stringWithFormat:@"定位到您在%@",string],@"是否使用？"];
         
         HNAlertView *view = [[HNAlertView alloc] initWithTitle:nil Content:contentStr whitTitleArray:@[@"取消",@"使用"] withType:@"center"];
         [view showAlertView:^(NSInteger index) {
             
             if (index == 1)
             {
                 [weakself.addressBtn setTitle:string forState:UIControlStateNormal];
                  weakself.liveAddress = string;
             }
             else
             {
                 [weakself.addressBtn setTitle:@"未知" forState:UIControlStateNormal];
             }
         }];
         
        
     }];
}

#pragma mark --------------- 选择添加封面

- (void)addCoverBtnClick
{
   [[HNPhotoChangeManager manager] showInVC:self image:^(UIImage *image) {
       
        UIImage *newImage = [HNTools imageCompressForSize:image targetSize:CGSizeMake((SCREEN_WIDTH - 70) * 2, 4 * (SCREEN_WIDTH - 60) /3.0)];
       
       [MBProgressHUD showMessage:@"正在上传图片..." toView:self.view];
       
       _weakself;
       NSDictionary *headerDic = @{@"authorization" : kTOKEN};
       [[HNRequestManager manager] uploadImageWithRequestAPICode:@"/common/0/cover/upload" requestParameters:nil requestHeader:headerDic image:newImage success:^(id responseObject) {
           _strongSelf;
            [MBProgressHUD hideHUDForView:strongSelf.view];
          strongSelf.liveLogoUrl = [responseObject valueForKeyPath:@"d.path"];
          [strongSelf.addCoverBtn setBackgroundImage:newImage forState:UIControlStateNormal];
          strongSelf.addCoverBtn.imageView.hidden = YES;
          strongSelf.addCoverBtn.titleLabel.text = @"";
           
//           [btn sd_setImageWithURL:[NSURL URLWithString:[HNTools pictureStr:[responseObject valueForKeyPath:@"d.path"]]] forState:UIControlStateNormal];
//           [weakself.imagesArr replaceObjectAtIndex:index withObject:[responseObject valueForKeyPath:@"d.path"]];
       } faild:^(NSError *error) {
           [MBProgressHUD hideHUDForView:self.view];
           [MBProgressHUD showError:@"图片上传失败"];
       }];
       
   }];
}

#pragma mark --------------- 输入限制

- (void)textFieldDidChange:(UITextField *)textField
{
    if (self.liveTitleText == textField)
    {
        if (textField.text.length > 16)
        {
            textField.text = [textField.text substringToIndex:16];
            
            [MBProgressHUD showError:@"标题不能超过16个字"];
        }
    }
    else
    {
        if (textField.text.length > 4)
        {
            textField.text = [textField.text substringToIndex:4];
        }
    }
}

- (void)textFieldDidEndEditing:(UITextField *)textField
{
    if (self.liveTitleText == textField)
    {
        self.liveTitle = textField.text;
    }
}

#pragma mark - setUI

- (void)setUI
{
    [self.view addSubview:self.maskBgView];
    [self.maskBgView addSubview:self.maskBGImage];
    
    [self.maskBgView addSubview:self.addressBtn];
    [self.maskBgView addSubview:self.exitBtn];
    
    [self.maskBgView addSubview:self.liveInfoView];
    [self.maskBgView addSubview:self.liveTitleText];
    [self.maskBgView addSubview:self.addCoverBtn];
    
    [self.maskBgView addSubview:self.freeLiveBtn];
    
    
    [self.maskBgView addSubview:self.startLiveBtn];
    
    [self.maskBgView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.size.mas_equalTo(CGSizeMake(SCREEN_WIDTH, SCREEN_HEIGHT));
        make.top.mas_equalTo(self.view);
    }];
    
    [self.maskBGImage mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.left.width.bottom.mas_equalTo(self.maskBgView);
    }];
    
    [self.addressBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_offset(Handle(12) + 20);
        make.left.mas_offset(Handle(15));
        make.width.mas_offset(Handle_width(150));
        make.height.mas_offset(Handle_height(20));
    }];
    
    [self.exitBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.mas_offset(-Handle(15));
        make.top.mas_offset(Handle(12) + 20);
    }];
    
    [self.liveInfoView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_offset(kNavigationHeight +  Handle(30));
        make.left.width.mas_equalTo(self.maskBgView);
        make.height.mas_offset(Handle_height(190));
    }];
    
    [self.liveTitleText mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(self.liveInfoView.mas_top).mas_offset(Handle(30));
        make.centerX.mas_equalTo(self.liveInfoView);
        make.width.mas_offset(SCREEN_WIDTH - Handle(30));
        make.height.mas_offset(Handle_height(25));
    }];
    
    [self.addCoverBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.mas_equalTo(self.liveInfoView);
        make.top.mas_equalTo(self.liveTitleText.mas_bottom).mas_offset(Handle(35));
        make.size.mas_equalTo(CGSizeMake(Handle_width(150 / 2), Handle_height(150 / 2)));
    }];
    
    [self.freeLiveBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_offset(Handle(30));
        make.top.mas_equalTo(self.liveInfoView.mas_bottom).mas_offset(Handle(35));
    }];


    [self.startLiveBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.mas_equalTo(self.maskBgView);
        make.top.mas_equalTo(self.freeLiveBtn.mas_bottom).mas_offset(Handle(372 / 2));
        make.width.mas_offset(Handle_width(550 / 2));
        make.height.mas_offset(Handle_height(78 / 2));
    }];
    
    
    [self.view layoutIfNeeded];
    
    self.addCoverBtn.contentHorizontalAlignment = UIControlContentHorizontalAlignmentCenter;//使图片和文字水平居中显示
    [self.addCoverBtn setTitleEdgeInsets:UIEdgeInsetsMake(self.addCoverBtn.imageView.frame.size.height + Handle(10) ,-self.addCoverBtn.imageView.frame.size.width, 0.0,0.0)];//文字距离上边框的距离增加imageView的高度，距离左边框减少imageView的宽度，距离下边框和右边框距离不变
    [self.addCoverBtn setImageEdgeInsets:UIEdgeInsetsMake(-Handle(10), 0.0,0.0, -self.addCoverBtn.titleLabel.bounds.size.width)];//图片距离右边框距离减少图片的宽度，其它不边

}

#pragma mark - getter

- (UIView *)maskBgView
{
    if(!_maskBgView)
    {
        _maskBgView = InsertView(nil, CGRectZero, UIColorFromHEXA(0x000000, 0.2));
    }
    return _maskBgView;
}

- (UIImageView *)maskBGImage
{
    if(!_maskBGImage)
    {
        _maskBGImage = InsertImageView(nil, CGRectZero, GetImage(@"beijing_kaishizhibo"));
    }
    return _maskBGImage;
}

- (UIButton *)addressBtn
{
    if(!_addressBtn)
    {
        _addressBtn = InsertTitleAndImageButton(nil, CGRectZero, 1000, @"未知", UIEdgeInsetsZero, SystemFontSize12, [UIColor whiteColor], nil, nil, nil, self, @selector(addressBtnClick:));
        [_addressBtn setImage:GetImage(@"icon_location_white") forState:UIControlStateNormal];
        _addressBtn.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft;
        _addressBtn.imageEdgeInsets = UIEdgeInsetsMake(0, -Handle(10) , 0, 0);
    }
    return _addressBtn;
}

- (UIButton *)exitBtn
{
    if(!_exitBtn)
    {
        _exitBtn = InsertImageButton(nil, CGRectZero, 1002, GetImage(@"close_single"), nil, self, @selector(exitLive));
        
        [_exitBtn setEnlargeEdgeWithTop:10 right:10 bottom:10 left:10];
    }
    return _exitBtn;
}

- (UIView *)liveInfoView
{
    if(!_liveInfoView)
    {
        _liveInfoView = InsertView(nil, CGRectZero, UIColorFromHEXA(0x000000, 0.2));
    }
    return _liveInfoView;
}

- (UITextField *)liveTitleText
{
    if (!_liveTitleText)
    {
        _liveTitleText = InsertTextField(nil, self, CGRectZero, @"你的观众更喜欢有趣的标题", SystemFontSize(20), NSTextAlignmentCenter, UIControlContentVerticalAlignmentCenter);
//        [_liveTitleText setValue:[UIColor whiteColor] forKeyPath:@"_placeholderLabel.textColor"];
        NSAttributedString *attributedString =  [[NSAttributedString alloc] initWithString:@"你的观众更喜欢有趣的标题" attributes:@{NSForegroundColorAttributeName:[UIColor whiteColor]}];
         [_liveTitleText setAttributedPlaceholder:attributedString];
        _liveTitleText.textColor = [UIColor whiteColor];
        _liveTitleText.tintColor = [UIColor whiteColor];
        _liveTitleText.clearButtonMode = UITextFieldViewModeAlways;
        [_liveTitleText addTarget:self action:@selector(textFieldDidChange:) forControlEvents:UIControlEventEditingChanged];
    }
    return _liveTitleText;
}

- (UIButton *)addCoverBtn
{
    if(!_addCoverBtn)
    {
        _addCoverBtn =  InsertTitleAndImageButton(nil, CGRectZero, 1003, @"添加封面", UIEdgeInsetsZero, SystemFontSize10, [UIColor whiteColor], nil, nil, nil, self, @selector(addCoverBtnClick));
        _addCoverBtn.backgroundColor = UIColorFromRGBA(1, 1, 1, 0.2);
        [_addCoverBtn setImage:GetImage(@"Set_cover") forState:UIControlStateNormal];
        _addCoverBtn.imageView.contentMode = UIViewContentModeScaleAspectFill;
        _addCoverBtn.imageView.clipsToBounds = YES;
    }
    return _addCoverBtn;
}

- (UIButton *)freeLiveBtn
{
    if(!_freeLiveBtn)
    {
        _freeLiveBtn = InsertTitleAndImageButton(nil, CGRectZero, 888, @"开启录制", UIEdgeInsetsZero, SystemFontSize14, [UIColor whiteColor], nil, nil, nil, self, @selector(freeLiveBtnClick));
        [_freeLiveBtn setImage:GetImage(@"select_def") forState:UIControlStateNormal];
        [_freeLiveBtn setImage:GetImage(@"select_sel") forState:UIControlStateSelected];
        
        _freeLiveBtn.imageEdgeInsets = UIEdgeInsetsMake(0, -Handle(5), 0, 0);
//        _freeLiveBtn.hidden=YES;
        _freeLiveBtn.selected = NO;
    }
    return _freeLiveBtn;
}


- (UIButton *)startLiveBtn
{
    if(!_startLiveBtn)
    {
        _startLiveBtn = InsertTitleAndImageButton(nil, CGRectZero, 1005, @"开始直播", UIEdgeInsetsZero, SystemFontSize15, [UIColor whiteColor], nil, GetImage(@"btn"), nil, self, @selector(startLiveBtnClick));
        _startLiveBtn.layer.cornerRadius = Handle(78 / 4);
        _startLiveBtn.layer.masksToBounds = YES;
    }
    return _startLiveBtn;
}


@end
