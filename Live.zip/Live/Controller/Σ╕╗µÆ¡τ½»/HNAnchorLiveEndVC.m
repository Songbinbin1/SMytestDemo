//
//  HNAnchorLiveEndVC.m
//  LiveShow
//
//  Created by Sunwanwan on 2017/8/30.
//  Copyright © 2017年 HN. All rights reserved.
//

#import "HNAnchorLiveEndVC.h"
#import "HNLiveVC.h"

@interface HNAnchorLiveEndVC ()

@property (nonatomic, strong) UIImageView *bgImgView;
@property (nonatomic, strong) UIButton *exitBtn;

@property (nonatomic, strong) UILabel *titleLab;

@property (nonatomic, strong) UILabel *descLab;
@property (nonatomic, strong) UIView *leftLine;
@property (nonatomic, strong) UIView *rightLine;

@property (nonatomic, strong) UILabel *timeTitleLab;
@property (nonatomic, strong) UILabel *timeLab;
@property (nonatomic, strong) UILabel *seeNumberTitleLab;
@property (nonatomic, strong) UILabel *seeNumberLab;
@property (nonatomic, strong) UILabel *pariseTitleLab;
@property (nonatomic, strong) UILabel *pariseLab;
@property (nonatomic, strong) UILabel *dotTitleLab;
@property (nonatomic, strong) UILabel *dotLab;

@end

@implementation HNAnchorLiveEndVC

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
    [self.navigationController setNavigationBarHidden:YES animated:YES];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    [self setUI];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - privateMethod

- (void)exitBtnClick
{
    DLog(@"------  %@ ------%@",self.navigationController.superclass, self.navigationController.viewControllers);
    
    for (UIViewController *vc in self.navigationController.viewControllers)
    {
        if ([vc isKindOfClass:[HNLiveVC class]])
        {
            [[NSNotificationCenter defaultCenter] postNotificationName:@"dismissPresentVC" object:nil];
            
            [self.navigationController popToViewController:vc animated:YES];
        }
    }
}

- (void)setEndModel:(HNAnchorLiveEndModel *)endModel
{
    _endModel = endModel;
    
    self.timeLab.text = [HNTools changMinuteToTime:endModel.live_time];
    self.seeNumberLab.text = endModel.watch_num;
    self.pariseLab.text = endModel.like_num;
    self.dotLab.text = endModel.get_dot;
}

#pragma mark - setUI

- (void)setUI
{
    [self.view addSubview:self.bgImgView];
    [self.view addSubview:self.exitBtn];
    [self.view addSubview:self.titleLab];
    [self.view addSubview:self.descLab];
    [self.view addSubview:self.leftLine];
    [self.view addSubview:self.rightLine];
    [self.view addSubview:self.timeTitleLab];
    [self.view addSubview:self.timeLab];
    [self.view addSubview:self.seeNumberTitleLab];
    [self.view addSubview:self.seeNumberLab];
    [self.view addSubview:self.pariseTitleLab];
    [self.view addSubview:self.pariseLab];
    [self.view addSubview:self.dotTitleLab];
    [self.view addSubview:self.dotLab];
    
    [self.exitBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.mas_offset(-Handle(15));
        make.top.mas_offset(Handle(20) + 20);
    }];
    
    [self.titleLab mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_offset(Handle(296 / 2));
        make.centerX.mas_equalTo(self.view.mas_centerX);
    }];
    
    [self.descLab mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.mas_equalTo(self.view.mas_centerX);
        make.top.mas_equalTo(self.titleLab.mas_bottom).mas_offset(Handle(210 / 2));
    }];
    
    [self.leftLine mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.mas_equalTo(self.descLab.mas_left).mas_offset(-Handle(5));
        make.height.mas_offset(Handle(0.5));
        make.width.mas_offset(Handle_width(72));
        make.centerY.mas_equalTo(self.descLab.mas_centerY);
    }];
    
    [self.rightLine mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(self.descLab.mas_right).mas_offset(Handle(5));
        make.centerY.mas_equalTo(self.descLab.mas_centerY);
        make.width.height.mas_equalTo(self.leftLine);
    }];
    
    [self.timeTitleLab mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(self.leftLine.mas_right).mas_offset(-Handle(20));
        make.top.mas_equalTo(self.descLab.mas_bottom).mas_offset(Handle(40));
    }];
    
    [self.timeLab mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(self.rightLine.mas_left).mas_offset(-Handle(35));
        make.centerY.mas_equalTo(self.timeTitleLab.mas_centerY);
    }];
    
    [self.seeNumberTitleLab mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(self.timeTitleLab);
        make.top.mas_equalTo(self.timeTitleLab.mas_bottom).mas_offset(Handle(18));
    }];
    
    [self.seeNumberLab mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(self.timeLab.mas_left);
        make.centerY.mas_equalTo(self.seeNumberTitleLab.mas_centerY);
    }];
    
    [self.pariseTitleLab mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(self.seeNumberTitleLab);
        make.top.mas_equalTo(self.seeNumberTitleLab.mas_bottom).mas_offset(Handle(18));
    }];
    
    [self.pariseLab mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(self.seeNumberLab.mas_left);
        make.centerY.mas_equalTo(self.pariseTitleLab.mas_centerY);
    }];
    
    [self.dotTitleLab mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(self.pariseTitleLab);
        make.top.mas_equalTo(self.pariseTitleLab.mas_bottom).mas_offset(Handle(18));
    }];
    
    [self.dotLab mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(self.pariseLab.mas_left);
        make.centerY.mas_equalTo(self.dotTitleLab.mas_centerY);
    }];
}

#pragma mark - getter

- (UIImageView *)bgImgView
{
    if(!_bgImgView)
    {
        _bgImgView = InsertImageView(nil, self.view.bounds, GetImage(@"bg_liveover"));
    }
    return _bgImgView;
}

- (UIButton *)exitBtn
{
    if(!_exitBtn)
    {
        _exitBtn = InsertImageButton(nil, CGRectZero, 999, GetImage(@"close_single"), nil, self, @selector(exitBtnClick));
        
        [_exitBtn setEnlargeEdgeWithTop:10 right:10 bottom:10 left:10];
    }
    return _exitBtn;
}

- (UILabel *)titleLab
{
    if(!_titleLab)
    {
        _titleLab = InsertLabel(nil, CGRectZero, NSTextAlignmentCenter, @"直播已结束", SystemFontSize(28), [UIColor whiteColor]);
    }
    return _titleLab;
}

- (UILabel *)descLab
{
    if(!_descLab)
    {
        _descLab = InsertLabel(nil, CGRectZero, NSTextAlignmentCenter, @"本场直播成就", SystemFontSize17, [UIColor whiteColor]);
    }
    return _descLab;
}

- (UIView *)leftLine
{
    if(!_leftLine)
    {
        _leftLine = InsertView(nil, CGRectZero, UIColorFromHEXA(0xDEE1EB, 0.3));
    }
    return _leftLine;
}

- (UIView *)rightLine
{
    if(!_rightLine)
    {
        _rightLine = InsertView(nil, CGRectZero, UIColorFromHEXA(0xDEE1EB, 0.3));
    }
    return _rightLine;
}

- (UILabel *)timeTitleLab
{
    if(!_timeTitleLab)
    {
        _timeTitleLab = InsertLabel(nil, CGRectZero, NSTextAlignmentLeft, @"直播时长", SystemFontSize12, UIColorFromHEXA(0xFFFFFF, 0.4));
    }
    return _timeTitleLab;
}

- (UILabel *)timeLab
{
    if(!_timeLab)
    {
        _timeLab = InsertLabel(nil, CGRectZero, NSTextAlignmentLeft, @"--:--:--", SystemFontSize15, [UIColor whiteColor]);
    }
    return _timeLab;
}

- (UILabel *)seeNumberTitleLab
{
    if(!_seeNumberTitleLab)
    {
        _seeNumberTitleLab = InsertLabel(nil, CGRectZero, NSTextAlignmentLeft, @"观看人数", SystemFontSize12, UIColorFromHEXA(0xFFFFFF, 0.4));
    }
    return _seeNumberTitleLab;
}

- (UILabel *)seeNumberLab
{
    if(!_seeNumberLab)
    {
        _seeNumberLab = InsertLabel(nil, CGRectZero, NSTextAlignmentLeft, @"--", SystemFontSize15, [UIColor whiteColor]);
    }
    return _seeNumberLab;
}

- (UILabel *)pariseTitleLab
{
    if(!_pariseTitleLab)
    {
        _pariseTitleLab = InsertLabel(nil, CGRectZero, NSTextAlignmentLeft, @"收到赞", SystemFontSize12, UIColorFromHEXA(0xFFFFFF, 0.4));
    }
    return _pariseTitleLab;
}

- (UILabel *)pariseLab
{
    if(!_pariseLab)
    {
        _pariseLab = InsertLabel(nil, CGRectZero, NSTextAlignmentLeft, @"--", SystemFontSize15, [UIColor whiteColor]);
    }
    return _pariseLab;
}

- (UILabel *)dotTitleLab
{
    if(!_dotTitleLab)
    {
        _dotTitleLab = InsertLabel(nil, CGRectZero, NSTextAlignmentLeft, @"红豆", SystemFontSize12, UIColorFromHEXA(0xFFFFFF, 0.4));
    }
    return _dotTitleLab;
}

- (UILabel *)dotLab
{
    if(!_dotLab)
    {
        _dotLab = InsertLabel(nil, CGRectZero, NSTextAlignmentLeft, @"--", SystemFontSize15, [UIColor whiteColor]);
    }
    return _dotLab;
}

@end
