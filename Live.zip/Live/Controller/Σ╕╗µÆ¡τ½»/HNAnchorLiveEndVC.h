//
//  HNAnchorLiveEndVC.h
//  LiveShow
//
//  Created by Sunwanwan on 2017/8/30.
//  Copyright © 2017年 HN. All rights reserved.
//  主播直播结束界面

#import "HNBaseViewController.h"
#import "HNAnchorLiveEndModel.h"

@interface HNAnchorLiveEndVC : HNBaseViewController

@property (nonatomic, strong) HNAnchorLiveEndModel *endModel;

@end
