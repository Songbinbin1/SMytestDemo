//
//  HNAnchorLiveVC.h
//  LiveShow
//
//  Created by Sunwanwan on 2017/8/30.
//  Copyright © 2017年 HN. All rights reserved.
//  主播端

#import "HNBaseViewController.h"
#import "HNLiveInfoModel.h"
#import "HNLiveAnchorModel.h"

@interface HNAnchorLiveVC : HNBaseViewController

@property (nonatomic, strong) HNLiveInfoModel *infoModel;
@property (nonatomic, strong) HNLiveAnchorModel *anchorModel;

@property (nonatomic, strong) NSString *notify;   // 房间websocket地址
@property (nonatomic, strong) NSMutableArray *lookUserArr;
@property (nonatomic, strong) NSArray *chatsArray;

@property (nonatomic, strong) NSString *liveType; // 直播类型
@property (nonatomic, strong) UIImage *liveImage; // 直播类型
@property (nonatomic, strong) NSString *notice; // 系统公告
@property (nonatomic, assign) BOOL  isRecording; //是否开启录制
@end
