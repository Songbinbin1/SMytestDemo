//
//  HNAnchorLiveVC.m
//  LiveShow
//
//  Created by Sunwanwan on 2017/8/30.
//  Copyright © 2017年 HN. All rights reserved.
//

#import "HNAnchorLiveVC.h"
#import "HNLiveAnchorUserInfoView.h"
#import "HNAnchorLiveEndVC.h"
#import "HNTXLivePushView.h"
#import "HNLiveChatTable.h"
#import <SRWebSocket.h>
#import "HNLiveSeeUserCollectionCell.h"
#import "HNUserInfoCardView.h"
#import "HNLiveChatMsgModel.h"
#import "HNAnimationManager.h"
#import "HNGiftListModel.h"
#import "HNLiveChatToolsView.h"
#import "HNLiveMessageVC.h"
#import "UIButton+HNAddBadge.h"
#import "HNBigGiftView.h"
#import "HNFlyManger.h"
#import "HNLiveChatMessageVC.h"
#import "HNDownloadManager.h"
#import "ZipArchive.h"
#import "HNSkinCareView.h"
#import "HNFansContributionListVC.h"
#import "HNAESSecurity.h"
#import "HNPersonalHomeHageVC.h"
#import "MLTransition.h"
#import "HNShareView.h"
#import "DMHeartFlyView.h"
//#import "XSJBeautifulShowTimeView.h"
#import "HNTXLivePlayerView.h"
#import "HNHttpRequest.h"
#import "HNHeadsetView.h"
#import "JXButton.h"
@interface HNAnchorLiveVC () <UIScrollViewDelegate, UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout, SRWebSocketDelegate, HNLiveChatToolsDelegate, HNUserInfoCardViewDelegate, HNBigGiftViewDelegate, HNLiveChatTableDelegate, HNSkinCareViewDelegate,  HNLiveAnchorUserInfoViewDelegate, UIGestureRecognizerDelegate,UINavigationControllerDelegate>

// -------------- 界面UI --------------------
@property (nonatomic, strong) UIScrollView *scrollerView;
@property (nonatomic, strong) UIImageView *streamBgImageView;
@property (nonatomic, strong) HNTXLivePushView *streamView;  // 推流时图

@property (nonatomic, strong) HNTXLivePlayerView *pullFlowView1;  // 连麦1
@property (nonatomic, strong) HNTXLivePlayerView *pullFlowView2;  // 连麦2
@property (nonatomic, strong) HNTXLivePlayerView *pullFlowView3;  // 连麦2
@property (nonatomic, strong) UIView *oneBgView;
@property (nonatomic, strong) HNLiveAnchorUserInfoView *userInfoView; // 主播信息视图

@property (nonatomic, strong) UICollectionView *lookUserCollection;  // 观看用户区域

@property (nonatomic, strong) HNLiveChatTable *liveChatTable;  // 聊天视图

@property (nonatomic, strong) HNLiveChatToolsView *chatToolsView;  // 评论视图

@property (nonatomic, strong) UIButton *commentBtn; // 评论按钮
@property (nonatomic, strong) UIButton *privateMsgBtn; // 私信按钮
@property (nonatomic, strong) UIButton *cameraBtn;  // 摄像头按钮
@property (nonatomic, strong) UIButton *skinCareBtn; // 美颜按钮
@property (nonatomic, strong) UIButton *changeTypeBtn; // 分享
@property (nonatomic, strong) UIButton *exitLiveBtn;  // 退出按钮

@property (nonatomic, strong) JXButton *connectBtn;
@property (nonatomic, strong) HNBigGiftView *bigGiftView;  // 大礼物动画视图
@property (nonatomic, strong) HNUserInfoCardView *infoView;  // 用户卡片信息
@property (nonatomic, strong) HNSkinCareView *skinCareView;  // 美颜视图
@property (nonatomic, strong) HNLiveMessageVC      *liveMessageVC;// 私信列表
@property (nonatomic, strong)HNHeadsetView *headsetView;//连麦控件
// ------------------ 数据信息 ----------------

@property (nonatomic, strong) NSMutableArray *bottomBtnArr;  // 底部按钮数组

@property (nonatomic, strong) NSTimer *heartTimer;

@property (nonatomic, strong) NSString *onlines; // 当前在线人数

@property (nonatomic, strong) NSMutableArray *giftListArr;  // 礼物列表
@property (nonatomic, strong) NSMutableArray *bigGiftImageArr;  // 大礼物动画数组

@property (nonatomic, strong) NSMutableArray *giftImageArr;  // 动画列表

@property (nonatomic, strong) NSMutableArray *chatListArr;

@property (nonatomic, strong) NSMutableArray *joinUserIdArr;  // 当前直播间的用户的id数组， 只要是用来切换直播间的时候给服务器传参

@property (nonatomic, strong) NSMutableArray<HNLiveAnchorModel *> *congUserIdArr;

// ------------------ webSocket -------------

@property (nonatomic, strong) SRWebSocket *socket;
@property (nonatomic, assign) float connectTime;


// -----------------  其他的判断变量
@property (nonatomic, assign) BOOL isForbidden;   // 是否被停播

@property (nonatomic, strong) HNLiveChatMsgModel *currentSendGiftMsgModel;  // 当前送礼的聊天模型（只用于当一个用户发送的礼物不在当前礼物列表里时）
@property (nonatomic, strong) HNLiveChatMsgModel *continueSendGiftMsgModel;  // 收到礼物正在做动画时候，又收到了礼物
@property (nonatomic, assign) NSInteger continueShowBigGiftCount;   // 继续播放大礼物动画的次数
//@property (nonatomic, strong)XSJBeautifulShowTimeView*  beautifulView;    //滤镜

@end

@implementation HNAnchorLiveVC

- (void)dealloc
{
     [[UIApplication sharedApplication] setIdleTimerDisabled:NO];
     [[NSNotificationCenter defaultCenter] removeObserver:self];
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
     self.navigationController.delegate = self;
    [self.navigationController setNavigationBarHidden:YES animated:YES];
    
    // 直播间里禁止系统自带的滑动手势
//    self.navigationController.interactivePopGestureRecognizer.enabled = NO;
//    [UIApplication sharedApplication].idleTimerDisabled = YES;
    
    // 直播间出现键盘的时候不需要页面向上滚动
//    IQKeyboardManager *manager = [IQKeyboardManager sharedManager];
//    manager.enable = NO;
//    manager.enableAutoToolbar = NO;
    
    self.automaticallyAdjustsScrollViewInsets = NO;
}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    
    // 页面消失时处理掉这个界面相对应的设置
//    self.navigationController.interactivePopGestureRecognizer.enabled = NO;
//    [UIApplication sharedApplication].idleTimerDisabled = YES;
    
//    IQKeyboardManager *manager = [IQKeyboardManager sharedManager];
//    manager.enable = YES;
//    manager.enableAutoToolbar = YES;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
     self.view.disableMLTransition=YES;
    [[UIApplication sharedApplication] setIdleTimerDisabled:YES];
    // 创建UI
    [self setUI];
    
    // 添加通知
    [self addNSNotification];
    
    // 开始直播
    [self startLive];
    
    // 获取下礼物列表
    NSData *gidtData = [[UserDefault objectForKey:@"giftList"] copy];
    self.giftListArr = [[NSKeyedUnarchiver unarchiveObjectWithData:gidtData] copy];
     [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(sendData) name:@"socketsendDataHeat" object:nil];
    // 进入直播间的时候， 要先处理下有没有未读消息的
    NSString *unreadCount = [UserDefault objectForKey:UnreadMessageCount];
    if ([unreadCount integerValue] > 0)
    {
        [self.privateMsgBtn showBadge];
    }
    
    self.isForbidden = NO;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - 开始直播
- (void)startLive
{
    [self.view addSubview:self.streamBgImageView];
    [self.streamBgImageView sd_setImageWithURL:[NSURL URLWithString:[HNTools pictureStr:self.anchorModel.avatar]]];
    
    self.streamView.streamCloudURL =self.infoModel.up_url;//@"rtmp://21764.livepush.myqcloud.com/live/21764_fbb0ff5917?bizid=21764&txSecret=d00a87453cc6701ca0d24cc5804d46a2&txTime=5ADF547F"; //// [HNAESSecurity AES128Decrypt:self.infoModel.up_url];
    
        self.streamView.enableNearestIP = YES;

    [self.streamView startPush];

    self.userInfoView.model = self.anchorModel;
    
    // 设置网速显示
    _weakself;
    self.streamView.netStatusBlock = ^(NSString *spd) {
        weakself.userInfoView.networkKBS = spd;
    };
    
    // 设置机器人
    if (self.lookUserArr.count > 0)
    {
        // 可是刚直播异常退出了， 现在重新进来是有机器人的
        [self.lookUserCollection reloadData];
        
        self.userInfoView.onlines = [NSString stringWithFormat:@"%ld",(unsigned long)self.lookUserArr.count];
    }
    
    // 聊天信息视图
    if (![HNTools dx_isNullOrNilWithObject:self.notice] && self.notice.length > 0)
    {
        HNLiveChatMsgModel *noticeMsgModel = [[HNLiveChatMsgModel alloc] init];
        noticeMsgModel.msg_content = [NSString stringWithFormat:@"系统公告：%@",self.notice];
        
        [self insertChatTableWithModel:noticeMsgModel];
    }
    
    // 连接webSocket
    [self reconnect];
    
    // 判断直播类型,看是否开启心跳
    if ([self.liveType integerValue] == 0 || [self.liveType integerValue] == 3)
    {
        if (_heartTimer == nil)
        {
            _heartTimer = [NSTimer scheduledTimerWithTimeInterval:30 target:self selector:@selector(heartTimerStart) userInfo:nil repeats:YES];
        }
    }
}

- (void)heartTimerStart
{
    [[HNRequestManager manager] sendRequestWithRequestMethodType:HNRequestMethodTypeGET requestAPICode:AnchorHeartbeat requestParameters:nil requestHeader:@{@"authorization" : kTOKEN} success:^(id responseObject) {
        DLog(@"1344");
    } faild:^(NSError *error) {
        ERROR;
    }];
}
- (void)sendData{
//    _weakself;

    if (self.socket != nil) {
        // 只有 SR_OPEN 开启状态才能调 send 方法，不然要崩
        if (self.socket.readyState == SR_OPEN) {
            [self.socket send:@"heart"];    // 发送数据
            
        } else if (self.socket.readyState == SR_CONNECTING) {
            NSLog(@"正在连接中，重连后其他方法会去自动同步数据");
            // 每隔2秒检测一次 socket.readyState 状态，检测 10 次左右
            // 只要有一次状态是 SR_OPEN 的就调用 [ws.socket send:data] 发送数据
            // 如果 10 次都还是没连上的，那这个发送请求就丢失了，这种情况是服务器的问题了，小概率的
            dispatch_main_async_safe(^{
//                [[NSNotificationCenter defaultCenter] postNotificationName:@"reconnectSocket" object:nil userInfo:nil];
                                  [self reconnect];
            });
        } else if (self.socket.readyState == SR_CLOSING || self.socket.readyState == SR_CLOSED) {
            // websocket 断开了，调用 reConnect 方法重连
            dispatch_main_async_safe(^{
//                [[NSNotificationCenter defaultCenter] postNotificationName:@"reconnectSocket" object:nil];
                                    [self reconnect];
            });
        }
    } else {
        dispatch_main_async_safe(^{
            //                [[NSNotificationCenter defaultCenter] postNotificationName:@"reconnectSocket" object:nil];
            [self reconnect];
        });
        NSLog(@"没网络，发送失败，一旦断网 socket 会被我设置 nil 的");
    }
}
#pragma mark - 结束直播
// 退出直播间前需要的操作，关闭处理
- (void)exitRoomCancelTransaction
{
    [self.userInfoView.timer invalidate];
    self.userInfoView.timer = nil;
    
    [self.heartTimer invalidate];
    self.heartTimer = nil;
    
    // 停止直播
    [self.streamView stopPush];
    [self.streamView removeFromSuperview];
    self.streamView = nil;
    
    if (self.pullFlowView1) {
        [self.pullFlowView1 stopPlay];
        [self.pullFlowView1 removeFromSuperview];
        self.pullFlowView1=nil;
    }
    if (self.pullFlowView2) {
        [self.pullFlowView2 stopPlay];
        [self.pullFlowView2 removeFromSuperview];
        self.pullFlowView2=nil;
    }
    if (self.pullFlowView3) {
        [self.pullFlowView3 stopPlay];
        [self.pullFlowView3 removeFromSuperview];
        self.pullFlowView3=nil;
    }
    // 停止websocket
    [self.socket close];
//    self.socket.delegate = nil;

    // 界面上的视图都移除
    
    [_chatToolsView.emojiScrollView removeFromSuperview];
    _chatToolsView.emojiScrollView = nil;
    
    [_chatToolsView removeFromSuperview];
    _chatToolsView = nil;
    
    [_infoView removeFromSuperview];
    _infoView = nil;
    
    [_skinCareView removeFromSuperview];
    _skinCareView = nil;
    

    [self.liveChatTable removeFromSuperview];
    self.liveChatTable = nil;
    
    [self.oneBgView removeFromSuperview];
    
    [self.lookUserArr removeAllObjects];
    [self.chatListArr removeAllObjects];
    
    // 通知也处理了
    [[NSNotificationCenter defaultCenter] removeObserver:self];
    
    // 处理当前是否有弹框
    for (UIView *view in KEY_WINDOW.subviews)
    {
        if ([view isKindOfClass:[HNAlertView class]])
        {
            if (view.tag != 1111)
            {
                HNAlertView *alert = (HNAlertView *)view;
                [alert dissmis];
            }
        }
    }
}

- (void)stopLive
{
    _weakself;
    [[HNRequestManager manager] sendRequestWithRequestMethodType:HNRequestMethodTypeGET requestAPICode:StopLive requestParameters:nil requestHeader:@{@"authorization" : kTOKEN} success:^(id responseObject) {
        _strongSelf;
        if (CODE != 200)
        {
            if (CODE == 201)
            {
                [[NSNotificationCenter defaultCenter] postNotificationName:@"dismissPresentVC" object:nil];
                [self.navigationController popViewControllerAnimated:YES];
            }
            else
            {
                MBErrorMsg;
            }
            return ;
        }
    
        NSDictionary *dic = responseObject[@"d"][@"live_result"];
        [strongSelf exitRoomCancelTransaction];
        HNAnchorLiveEndModel *model = [HNAnchorLiveEndModel yy_modelWithDictionary:dic];
        
        HNAnchorLiveEndVC *vc = [[HNAnchorLiveEndVC alloc] init];
        vc.endModel = model;
        [strongSelf.navigationController pushViewController:vc animated:NO];
    
    } faild:^(NSError *error) {
        ERROR;
    }];
}

//添加连麦播放器
-(void)addConnectView:(NSString *)down_url uid:(NSString *)uid{
   
    if (_pullFlowView1) {
        if (_pullFlowView2) {
            if (_pullFlowView3) {
                DLog(@"连麦已满");
            }else{
                self.pullFlowView3.uid = uid;
                self.pullFlowView3.rtmpURL =down_url;
                [self.pullFlowView3 startPlay];
            }
        }else{
            self.pullFlowView2.uid = uid;
            self.pullFlowView2.rtmpURL =down_url;
            [self.pullFlowView2 startPlay];
        }

    }else{
        self.pullFlowView1.uid = uid;
        self.pullFlowView1.rtmpURL =down_url;
        [self.pullFlowView1 startPlay];
    }
     [self updateconectBtn];
}

#pragma mark ----------  updateconectBtn
-(void)updateconectBtn{
    if (_pullFlowView3) {
        [self.connectBtn mas_updateConstraints:^(MASConstraintMaker *make) {
            make.bottom.mas_equalTo(self.exitLiveBtn.mas_top).mas_offset(-Handle(10)- Y(350)*3);
        }];
    }else if (_pullFlowView2){
        [self.connectBtn mas_updateConstraints:^(MASConstraintMaker *make) {
            make.bottom.mas_equalTo(self.exitLiveBtn.mas_top).mas_offset(-Handle(10)- Y(350)*2);
        }];
    }else if (_pullFlowView1){
        [self.connectBtn mas_updateConstraints:^(MASConstraintMaker *make) {
            make.bottom.mas_equalTo(self.exitLiveBtn.mas_top).mas_offset(-Handle(10)- Y(350)*1);
        }];
    }else{
        [self.connectBtn mas_updateConstraints:^(MASConstraintMaker *make) {
            make.bottom.mas_equalTo(self.exitLiveBtn.mas_top).mas_offset(-Handle(10));
        }];
    }
    [self.connectBtn updateFocusIfNeeded];
}
#pragma mark ----------  websocket

- (void)reconnect
{
    // 先断开连接再重新连接
    if (!self.notify) {
        return;
    }
    if(self.socket){
        self.socket.delegate = nil;
        [self.socket close];
    }
   
    self.socket = [[SRWebSocket alloc] initWithURLRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:self.notify]]];
    self.socket.delegate = self;
    [self.socket open];
}

- (void)webSocket:(SRWebSocket *)webSocket didReceiveMessage:(id)message
{
    NSDictionary *messageDict = [HNTools dictionaryWithJsonString:message];
    DLog(@"----websocketMsg:--  %@",messageDict);
     NSLog(@"Task %@ ", [NSThread currentThread]);
    // 在线人数
    if (Type(@"onlines"))
    {
        NSString *onlines = [NSString stringWithFormat:@"%@",messageDict[@"liveonlines"]];
        NSInteger anchorOnlines = [onlines integerValue] - 1;
        self.userInfoView.onlines = [NSString stringWithFormat:@"%ld",(long)anchorOnlines];
        
        NSArray *array = [NSArray yy_modelArrayWithClass:[HNLiveUserModel class] json:messageDict[@"data"]];
        
        // 主播端需要减去自己
        NSMutableArray *attArr = [NSMutableArray arrayWithArray:array];
        
        for (HNUserModel *model in array)
        {
            if ([model.uid isEqualToString:self.anchorModel.uid])
            {
                [attArr removeObject:model];
                
                break;
            }
        }
        
        self.lookUserArr = attArr;
        
        [self reloadUserCollection];
    }
    
    // 进入直播间
    if (Type(@"join"))
    {
        HNLiveUserModel *model = [HNLiveUserModel yy_modelWithJSON:messageDict[@"data"][@"fuser"]];
        if ([model.uid isEqualToString:self.anchorModel.uid])
        {
            return;
        }
        
        // 观看人数区域处理
        [self insertLookUserWithModel:model type:@"user"];
        
        // 聊天区域处理
        HNLiveChatMsgModel *msgModel = [HNLiveChatMsgModel yy_modelWithJSON:messageDict[@"data"][@"fuser"]];
        msgModel.msg_content = @"入场了";
         msgModel.msgType = TipsMsgType;
        [self insertChatTableWithModel:msgModel];
        
        self.userInfoView.onlines= [NSString stringWithFormat:@"%ld",[self.userInfoView.onlines integerValue]+1];
        
        // 将进入直播间的人的uid加入到用户id数组里
        [self.joinUserIdArr addObject:model.uid];
    }
    
    // 机器人进入直播间
    if (Type(@"robot_join"))
    {        
        // 观看人数区域处理
        HNLiveUserModel *model = [HNLiveUserModel yy_modelWithJSON:messageDict[@"data"][@"robot"]];
        [self insertLookUserWithModel:model type:@"robot"];
        
        // 聊天区域处理
        HNLiveChatMsgModel *msgModel = [HNLiveChatMsgModel yy_modelWithJSON:messageDict[@"data"][@"robot"]];
        msgModel.msg_content = @"入场了";
         msgModel.msgType = TipsMsgType;
        [self insertChatTableWithModel:msgModel];
        
        self.userInfoView.onlines= [NSString stringWithFormat:@"%ld",[self.userInfoView.onlines integerValue]+1];
    }
    
    // 公聊
    if (Type(@"public_msg"))
    {
        NSDictionary *userDic = messageDict[@"data"][@"user_info"];
        HNLiveChatMsgModel *msgModel = [HNLiveChatMsgModel yy_modelWithDictionary:userDic];
        msgModel.msg_content = messageDict[@"data"][@"content"][@"word"];
//         [msgModel calculationcellHeight];
         [self insertChatTableWithModel:msgModel];
//        if([msgModel.msg_content isEqualToString:@"连麦"]){
//            [self addConnectView:@"http://wssource.rtc.inke.cn/live/1539593831607128.flv?ikHost=ws&ikOp=1&codecInfo=8192&dpSrc=push&ikDnsOp=1001"];
//        }
//        [self.chatListArr addObject:msgModel];
//···
//        [self chatTableScrollToBottom];
    }
    
    // 弹幕
    if (Type(@"barrage"))
    {
        NSDictionary *userDic = messageDict[@"data"][@"user_info"];
        HNLiveChatMsgModel *msgModel = [HNLiveChatMsgModel yy_modelWithDictionary:userDic];
        msgModel.msg_content = messageDict[@"data"][@"content"][@"word"];
        
        // 飘屏
        [[HNFlyManger sharedManger] mangerShowWithModel:msgModel parentView:self.oneBgView];
    }

    // 送礼
    if (Type(@"send_gift"))
    {
        // 主播获得优币处理
        self.userInfoView.exceptionalMoney = messageDict[@"data"][@"gift"][@"total_dot"];
        
        NSDictionary *userDic = messageDict[@"data"][@"user_info"];
        HNLiveChatMsgModel *msgModel = [HNLiveChatMsgModel yy_modelWithDictionary:userDic];
        msgModel.g_num = @"1";
         msgModel.msgType = GiftMsgType;
        NSString *giftId = messageDict[@"data"][@"gift"][@"id"];
        BOOL localIsHavegift = NO;
        for (HNGiftListModel *model in self.giftListArr)
        {
            if ([giftId isEqualToString:model.giftId])
            {
                msgModel.g_name = model.name;
                msgModel.g_icon = model.icon;
                msgModel.g_id = model.giftId;
                
                localIsHavegift = YES;
                
                break;
            }
        }
        
        if (localIsHavegift == NO)
        {
            // 说明本地没有这个礼物，则要从服务器去获取单个礼物的信息
            self.currentSendGiftMsgModel = msgModel;
            [self requestOneGiftWithGiftId:giftId chatMsgModel:msgModel];
        }
        else
        {
            HNAnimationManager *manger = [HNAnimationManager sharedAnimationManager];
            manger.superView = self.oneBgView;
            [manger animaWithMsgModel:msgModel finishedBlock:^(BOOL result, NSInteger finishCount) {
                
                // 聊天区域处理
                msgModel.msg_content = [NSString stringWithFormat:@"赠送了%ld个%@",(long)finishCount,msgModel.g_name];
                
                [self insertChatTableWithModel:msgModel];
                //                    [self.chatListArr addObject:msgModel];
                //                    [self chatTableScrollToBottom];
            }];
            NSString *giftKey = [NSString stringWithFormat:@"%@_%@",msgModel.g_id,msgModel.g_name];
            //
            if ([[HNTools BigGiftNameArray] containsObject:giftKey])
            {
                //                // 说明赠送的是大礼物
                [self.giftImageArr addObject:msgModel];
                
                if (!self.currentSendGiftMsgModel) {
                    [self continueReplaceShowBigGiftView];
                }
            }
        }
    }
    
    // 离开直播间
    if (Type(@"leave"))
    {
        HNLiveUserModel *model = [HNLiveUserModel yy_modelWithJSON:messageDict[@"data"][@"fuser"]];
        NSMutableArray *tempArr = self.lookUserArr;
        for (HNLiveUserModel *allModel in self.lookUserArr)
        {
            if ([model.uid isEqualToString:allModel.uid])
            {
                [tempArr removeObject:allModel];
                
                break;
            }
        }
        
        self.lookUserArr = tempArr;
        
        [self reloadUserCollection];
        
        self.userInfoView.onlines= [NSString stringWithFormat:@"%ld",[self.userInfoView.onlines integerValue]-1];
        
        // 用户离开直播间的时候把当前这个id从userid数组里删除掉
        [self.joinUserIdArr removeObject:model.uid];
    }

    
    // 机器人离开直播间
    if (Type(@"robot_leave"))
    {
        HNLiveUserModel *model = [HNLiveUserModel yy_modelWithJSON:messageDict[@"data"][@"robot"]];
        NSMutableArray *tempArr = self.lookUserArr;
        for (HNLiveUserModel *allModel in self.lookUserArr)
        {
            if ([model.uid isEqualToString:allModel.uid])
            {
                [tempArr removeObject:allModel];
                
                break;
            }
        }
        
        self.lookUserArr = tempArr;
        
        [self reloadUserCollection];
        
        self.userInfoView.onlines= [NSString stringWithFormat:@"%ld",[self.userInfoView.onlines integerValue]-1];
    }
    
    // 主播获得房间收入
    if (Type(@"anchor_get_room_price"))
    {
        NSString *anchorId = messageDict[@"data"][@"anchor_uid"];
        if ([self.anchorModel.uid isEqualToString:anchorId])
        {
            // 是当前这个直播间的
            self.userInfoView.exceptionalMoney = messageDict[@"data"][@"total_dot"];
        }
    }
    
    // 用户升级
    if (Type(@"level_up"))
    {
        HNLiveChatMsgModel *model = [HNLiveChatMsgModel yy_modelWithJSON:messageDict[@"data"][@"user_info"]];
        if ([model.uid isEqualToString:self.anchorModel.uid])
        {
            model.msg_content = [NSString stringWithFormat:@"系统消息： 恭喜主播等级升至%@级",model.level];
        }
        else
        {
            model.msg_content = [NSString stringWithFormat:@"系统消息： 恭喜%@等级升至%@级",model.nick,model.level];
        }
         [self insertChatTableWithModel:model];

    }
    
    // 点赞主播
    if (Type(@"attitude"))
    {
        HNLiveChatMsgModel *model = [HNLiveChatMsgModel yy_modelWithJSON:messageDict[@"data"][@"user_info"]];
        model.msg_content = @"点赞了主播";
        model.msgType = TipsMsgType;
        [self insertChatTableWithModel:model];
        [self  heartFlyViewAnimation];
    }
    


    // 设置场控
    if (Type(@"setFieldControl"))
    {
        HNLiveChatMsgModel *model = [HNLiveChatMsgModel yy_modelWithJSON:messageDict[@"data"][@"user_info"]];
          model.msgType = TipsMsgType;
        if ([model.is_field_control integerValue] == 1)
        {
            model.msg_content = @"已被设为场控";
             [self insertChatTableWithModel:model];

        }
    }
    
    // 禁言
    if (Type(@"setBannedSay"))
    {
        HNLiveChatMsgModel *model = [HNLiveChatMsgModel yy_modelWithJSON:messageDict[@"data"][@"user_info"]];
         model.msgType = SystemMsgType;
          model.msgType = TipsMsgType;
        if ([model.is_banned_say integerValue] == 1)
        {
            model.msg_content = @"已被禁言";
        }
        else
        {
            model.msg_content = @"解除禁言";
        }
         [self insertChatTableWithModel:model];

    }
}

#pragma mark - 点赞动画
-(void)heartFlyViewAnimation{
    DMHeartFlyView* heart = [[DMHeartFlyView alloc]initWithFrame:CGRectMake(0, 0, Handle(42), Handle(42))];
    [self.view addSubview:heart];
    
    CGPoint fountainSource = CGPointMake( SCREEN_WIDTH - SCREEN_WIDTH / 8.0 * 1.5 - Handle(10), self.view.bounds.size.height - SCREEN_WIDTH / 8.0);
    heart.center = fountainSource;
    [heart animateInView:self.view];
}
- (void)webSocket:(SRWebSocket *)webSocket didFailWithError:(NSError *)error
{
    // 连接失败， 这里实现掉线重连，注意以下问题
    // 1, 判断当前网络环境， 断网下不需要重连， 等待网络到来再发起重连
    // 2, 连接次数限制，如果连接失败，重试10次就可以了， 防止死循环啊
    
    self.socket = nil;
    self.connectTime++;
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(self.connectTime*NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [self reconnect];
    });
}

- (void)webSocketDidOpen:(SRWebSocket *)webSocket
{
    DLog(@"连接成功， 开启心跳");
    self.connectTime = 0;
}

- (void)webSocket:(SRWebSocket *)webSocket didCloseWithCode:(NSInteger)code reason:(NSString *)reason wasClean:(BOOL)wasClean
{
    DLog(@"客户端主动关闭连接， 清空对象，关闭心跳");
    
//    self.socket.delegate = nil;
//    self.socket = nil;
//    self.connectTime ++;
//    
//    [self.heartTimer invalidate];
//    self.heartTimer = nil;
}

#pragma mark ---------  通知

- (void)addNSNotification
{
    // 网络监测
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(NetworkChange:) name:NetworkChangeNotification object:nil];
    
    // 推流断开连接， 且重连失败了
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(streamStartFailed) name:@"StreamReconteactFaild" object:nil];
    
    // 推流成功
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(streamStartSuccess:) name:@"PLStreamStartStateSuccess" object:nil];
    
    // 被人挤掉了
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(hasLogout) name:@"YouHasLogout" object:nil];
    
    // 未读消息数改变
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(changePrivateMsgBtnUnread:) name:kChangeTotalUnread object:nil];
    
    // 收到私信消息推送
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(showPrivateMsgUnread) name:@"privateMessage" object:nil];
    
    // 收到系统消息推送
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(showPrivateMsgUnread) name:@"systemMessage" object:nil];
    
    //    // 点击了弹幕头像
    //    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(clickFlyViewHeader:) name:@"jhClickFlyViewHeaderImage" object:nil];
    
    // 主播被禁用账户
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(UserForbidden:) name:@"UserForbidden" object:nil];
    
    // 主播被禁播了
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(LiveForbidden:) name:@"LiveForbidden" object:nil];
    
    // 主播被警告了
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(LiveWarning:) name:@"LiveWarning" object:nil];
    
    // 单个大礼物下载并且解压成功
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(oneGiftZipArchiveSuccess:) name:@"ZipArchiveSuccess" object:nil];
    
    // 移除消息列表
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(liveMessageShowOrHidden:) name:@"liveMessageShowOrHidden" object:nil];
    
    // 键盘通知（主要用来处理用户切换直播类型的时候修改视图的frame。  --在这里写通知的原因是ios9一下的系统，每次点击都闪退。崩溃在view里面的键盘通知事件里，不好解决，所以拿出来在vc上处理） (---- 又重新处理了下公聊toolsView出来的时候界面滚动处理， 所以在通知里面会有一个区分)
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(keyboardChange:) name:UIKeyboardWillShowNotification object:nil];
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(keyboardChange:) name:UIKeyboardWillHideNotification object:nil];
    
    // 收到连麦申请
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(connecting:) name:@"HNuser_to_connect" object:nil];
    // 收到连麦成功
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(connectSuccess:) name:@"HNconnect_flow" object:nil];
    
    // 关闭连麦
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(cancelSuccess:) name:@"HNcancel_flow" object:nil];
    
}

// 网络切换
- (void)NetworkChange:(NSNotification *)notifi
{
    NSInteger states = [notifi.userInfo[@"NetworkStatus"] integerValue];
    
    if (AFNetworkReachabilityStatusUnknown == states || AFNetworkReachabilityStatusNotReachable)
    {
        // 没网或者未知网络
        [self.streamView stopPush];
        
        HNAlertView *view = [[HNAlertView alloc] initWithTitle:@"提示" Content:@"网络连接异常，请检查网络设置" whitTitleArray:@[@"去设置",@"好的"] withType:@"center"];
        
        _weakself;
        [view showAlertView:^(NSInteger index) {
            if (index == 1)
            {
                [weakself.userInfoView.timer invalidate];
                weakself.userInfoView.timer = nil;
                
                // 停止直播
                [weakself.streamView stopPush];
                [weakself.streamView removeFromSuperview];
                
                // 停止websocket
                [weakself.socket close];
//                weakself.socket.delegate = nil;
                
                [weakself stopLive];
            }
            else
            {
                NSURL *url = [NSURL URLWithString:UIApplicationOpenSettingsURLString];
                
                if ([[UIApplication sharedApplication] canOpenURL:url]) {
                    
                    [[UIApplication sharedApplication] openURL:url];
                }
            }
        }];
    }
    else if (AFNetworkReachabilityStatusReachableViaWWAN == states)
    {
        // 手机网络
        //        [self.streamView pa];
        [self.streamView pausePush];
        
        HNAlertView *view = [[HNAlertView alloc] initWithTitle:nil Content:@"当前网络无WIFI，继续播放可能会被运营商收取流量费用" whitTitleArray:@[@"去设置",@"继续播放"] withType:@"center"];
        [view showAlertView:^(NSInteger index) {
            if (index == 1)
            {
                [self.streamView resumePush];
            }
            else
            {
                NSURL *url = [NSURL URLWithString:UIApplicationOpenSettingsURLString];
                
                if ([[UIApplication sharedApplication] canOpenURL:url]) {
                    
                    [[UIApplication sharedApplication] openURL:url];
                    
                }
            }
        }];
    }
}

- (void)streamStartFailed
{
    [self.socket close];
//    self.socket.delegate = nil;
    
    // 推流失败或者推流重连失败了
    HNAlertView *view = [[HNAlertView alloc] initWithTitle:@"提示" Content:@"当前网络不给力，直播中断，请检查网络设置后重试" whitTitleArray:@[@"我知道了"] withType:@"center"];
    
    _weakself;
    [view showAlertView:^(NSInteger index)
     {
         [weakself exitRoomCancelTransaction];
         [weakself.navigationController popViewControllerAnimated:YES];
     }];
}

- (void)streamStartSuccess:(NSNotification *)notifi
{
    DLog(@"-----  推流成功了------");
    
    if (notifi.object == nil)
    {
        if (![self.userInfoView.timer isValid])
        {
            // 推流成功，默认打开美颜
//            [MBProgressHUD showSuccess:@"美颜打开"];
            NSString *skinType = [[UserDefault objectForKey:kSkinType] stringValue];
            if (skinType == nil)
            {
                [self.streamView changeSkinCareWithType:YES skinCareValue:6 whiteningValue:6 ruddyValue:6];
            }
            else
            {
                [self.streamView changeSkinCareWithType:[skinType isEqualToString:@"1"] ? YES : NO skinCareValue:[[UserDefault objectForKey:kSkincareValue] floatValue] whiteningValue:[[UserDefault objectForKey:kWhiteningValue] floatValue] ruddyValue:[[UserDefault objectForKey:kRuddyValue] floatValue]];
            }
            
            // 此时开始计时
            [self.userInfoView startTimer];
        }
    }
    else
    {
        // 此时首桢画面已经采集成功了， 就移除背景图
        [self.streamBgImageView removeFromSuperview];
    }
}

// 被挤掉了
- (void)hasLogout
{
    [self.streamView stopPush];
    [self.streamView removeFromSuperview];
    
    [self.socket close];
    self.socket = nil;
    
    [self.heartTimer invalidate];
    self.heartTimer = nil;
    
    [self stopLive];
}

// 修改当前的未读消息数
- (void)changePrivateMsgBtnUnread:(NSNotification *)noti
{
    NSString *unread = noti.userInfo[kUnReadKey];
    
    if ([unread integerValue] == 0)
    {
        [self.privateMsgBtn hideBadge];
    }
}

// 收到私信消息推动
- (void)showPrivateMsgUnread
{
    // 这里只处理界面上私信按钮的未读消息显示， 其余在聊天界面也会接收通知
    [self.privateMsgBtn showBadge];
}

// 单个大礼物解压成功 界面上显示处理
- (void)oneGiftZipArchiveSuccess:(NSNotification *)noti
{
    NSString *fileName = noti.userInfo[@"fileName"];
    HNGiftListModel *model = noti.userInfo[@"model"];
    self.bigGiftImageArr = [HNTools getBigGiftPictureArray:fileName];
    self.bigGiftView.infoLabel.text = [NSString stringWithFormat:@"%@送给主播一个%@",self.currentSendGiftMsgModel.nick,model.name];
     [self.oneBgView insertSubview:self.bigGiftView atIndex:0];
//    [self.oneBgView addSubview:self.bigGiftView];
}
#pragma mark ----------------- 连麦申请 -----------------

- (void)connecting:(NSNotification *)noti
{

    HNLiveAnchorModel *model = [HNLiveAnchorModel yy_modelWithDictionary:noti.userInfo];
    model.conetState = @"0";
    [self.connectBtn sd_setImageWithURL:[NSURL URLWithString:model.avatar] forState:UIControlStateNormal];
    [self.congUserIdArr enumerateObjectsWithOptions:NSEnumerationReverse usingBlock:^(id obj, NSUInteger idx, BOOL * _Nonnull stop) {
        HNLiveAnchorModel *anchorModel = obj;
        if ([anchorModel.uid isEqualToString:model.uid]) {
            [self.congUserIdArr removeObject:anchorModel];
             *stop = YES;
        }
    }];
    
    [self.congUserIdArr addObject:model];
    [self updateConnectBtn];

}
- (void)connectSuccess:(NSNotification *)noti
{
    HNLiveAnchorModel *model = [HNLiveAnchorModel yy_modelWithDictionary:noti.userInfo];
    
    [self addConnectView:model.rtmpURL uid:model.uid];
    for ( HNLiveAnchorModel *anchorModel in self.congUserIdArr) {
        if ([anchorModel.uid isEqualToString:model.uid]) {
            anchorModel.conetState = @"3";
            return;
        }
    }
    [self updateconectBtn];
}

-(void)updateConnectBtn{
    if (self.congUserIdArr.count>0) {
         [self.connectBtn setTitle:[NSString stringWithFormat:@"%lu人申请",(unsigned long)self.congUserIdArr.count] forState:UIControlStateNormal];
         HNLiveAnchorModel *anchorModel = [self.congUserIdArr lastObject];
        [self.connectBtn sd_setImageWithURL:[NSURL URLWithString:anchorModel.avatar] forState:UIControlStateNormal];
    }else{
         [self.connectBtn setImage:[UIImage imageNamed:@"connect"] forState:0];
         [self.connectBtn setTitle:@"等待申请" forState:UIControlStateNormal];
    }
}

- (void)cancelSuccess:(NSNotification *)noti{
    NSDictionary *dic = noti.userInfo;
    _weakself;
    [self.congUserIdArr enumerateObjectsWithOptions:NSEnumerationReverse usingBlock:^(id obj, NSUInteger idx, BOOL * _Nonnull stop) {
        _strongSelf;
        HNLiveAnchorModel *anchorModel = obj;
        if ([anchorModel.uid isEqualToString:dic[@"uid"]]) {
            [strongSelf.congUserIdArr removeObject:anchorModel];
            *stop = YES;
        }
    }];
     [self stopPlay:dic[@"uid"]];
     [self updateConnectBtn];
     [self updateconectBtn];
}

-(void)stopPlay:(NSString *) uid{
    if (_pullFlowView1 && [_pullFlowView1.uid isEqualToString:uid]) {
        [self.pullFlowView1 stopPlay];
        [self.pullFlowView1 removeFromSuperview];
        self.pullFlowView1=nil;
    }else if (_pullFlowView2 && [_pullFlowView2.uid isEqualToString:uid]){
        [self.pullFlowView2 stopPlay];
        [self.pullFlowView2 removeFromSuperview];
        self.pullFlowView2=nil;
    }else if (_pullFlowView3 && [_pullFlowView3.uid isEqualToString:uid]){
        [self.pullFlowView3 stopPlay];
        [self.pullFlowView3 removeFromSuperview];
        self.pullFlowView3=nil;
    }
}
#pragma mark ----------------- 主播被警告 -----------------

- (void)LiveWarning:(NSNotification *)noti
{
    NSString *uid = noti.userInfo[@"uid"];
    if ([uid isEqualToString:self.anchorModel.uid])
    {
        NSString *content = noti.userInfo[@"content"];
        HNAlertView *view = [[HNAlertView alloc] initWithTitle:@"警告" Content:content whitTitleArray:@[@"我知道了"] withType:@"center"];
        [view showAlertView:^(NSInteger index) {
            
        }];
    }
}

#pragma mark ----------------- 主播被禁播 -----------------

- (void)LiveForbidden:(NSNotification *)noti
{
    self.isForbidden = YES;
    
    NSString *uid = noti.userInfo[@"uid"];
    if ([uid isEqualToString:self.anchorModel.uid])
    {
        NSString *content = @"";
        if ([noti.userInfo[@"till"] integerValue] == -1)
        {
            content = @"您已被禁播，请与后台客服联系";
        }
        else
        {
             NSString *timeString = [HNTools turnTimeTimestamp:noti.userInfo[@"till"] withType:@"yyyy-MM-dd HH:mm"];
            content = [NSString stringWithFormat:@"您已被停播，请%@后重试",timeString];
        }
        
        HNAlertView *view = [[HNAlertView alloc] initWithTitle:@"提示" Content:content whitTitleArray:@[@"我知道了"] withType:@"center"];
        _weakself;
        [view showAlertView:^(NSInteger index)
         {
             // 直播过程中被禁播了
             [self exitRoomCancelTransaction];

            [[NSNotificationCenter defaultCenter] postNotificationName:@"dismissPresentVC" object:nil];
             
            [weakself.navigationController popViewControllerAnimated:YES];
        }];
    }
}

#pragma mark ----------------- 主播账号被禁用 -----------------

- (void)UserForbidden:(NSNotification *)notifi
{
    self.isForbidden = YES;
    
    NSString *uid = notifi.userInfo[@"uid"];
    if ([uid isEqualToString:self.anchorModel.uid])
    {
        // 是当前直播间的主播账号被禁用了
        [self exitRoomCancelTransaction];
    }
}

#pragma mark ----------------- 从服务器获取单个礼物处理 -----------------

- (void)requestOneGiftWithGiftId:(NSString *)giftId chatMsgModel:(HNLiveChatMsgModel *)msgModel
{
    NSDictionary *dic = @{
                          @"gift_id" : giftId
                          };
    
    [[HNRequestManager manager] sendRequestWithRequestMethodType:HNRequestMethodTypeGET requestAPICode:GetOneGift requestParameters:dic requestHeader:@{@"authorization" : kTOKEN} success:^(id responseObject) {
        
        if (CODE != 200)
        {
            return ;
        }
        
        HNGiftListModel *model = [HNGiftListModel yy_modelWithJSON:responseObject[@"d"][@"gift"]];
        
        msgModel.g_name = model.name;
        msgModel.g_icon = model.icon;
        msgModel.g_id = model.giftId;
        
        if ([model.animation isEqualToString:@""])
        {
            // 小礼物
            HNAnimationManager *manger = [HNAnimationManager sharedAnimationManager];
            manger.superView = self.oneBgView;
            [manger animaWithMsgModel:msgModel finishedBlock:^(BOOL result, NSInteger finishCount) {
                
                // 聊天区域处理
                msgModel.msg_content = [NSString stringWithFormat:@"赠送了%ld个%@",finishCount,msgModel.g_name];
//                [self.chatListArr addObject:msgModel];
//                [self chatTableScrollToBottom];
                 [self insertChatTableWithModel:msgModel];
                
            }];
        }
        else
        {
            // 大礼物
             [HNTools downloadAndZipArchiveWithGiftModel:model];
        }
        
        
        [self updateLocalGiftListWithGiftModel:model];
        
        
    } faild:^(NSError *error) {
        
    }];
}

- (void)updateLocalGiftListWithGiftModel:(HNGiftListModel *)model
{
    // 保存到本地(先判断本地是不是存在， 存在只更新， 不存在添加在最后)
    NSData *gidtData = [[UserDefault objectForKey:@"giftList"] copy];
    NSArray *array = [[NSKeyedUnarchiver unarchiveObjectWithData:gidtData] copy];
    
    BOOL _localIsHaveGift = NO;
    NSMutableArray *attArr = [NSMutableArray arrayWithArray:array];
    for (int i = 0; i < array.count; ++i)
    {
        HNGiftListModel *localModel = array[i];
        if ([localModel.giftId isEqualToString:model.giftId])
        {
            [attArr replaceObjectAtIndex:i withObject:model];
            _localIsHaveGift = YES;
            break;
        }
    }
    
    if (_localIsHaveGift == NO)
    {
        [self.giftListArr addObject:model];
    }
    else
    {
        self.giftListArr = attArr;
    }
    
    NSData * tempArchive = [NSKeyedArchiver archivedDataWithRootObject:self.giftListArr];
    
    [UserDefault setObject:tempArchive forKey:@"giftList"];
    [UserDefault synchronize];
}


//#pragma mark ----------------- 点击弹幕头像 -----------------
//
//- (void)clickFlyViewHeader:(NSNotification *)noti
//{
//    NSString *uid = noti.object;
//    
//    [self clickUserHeaderWithUid:uid];
//}
//
//- (void)clickUserHeaderWithUid:(NSString *)uid
//{
//    if ([uid isEqualToString:kUserID])
//    {
//        return;
//    }
//    
//    if (self.infoView.superview == nil)
//    {
//        self.infoView.uid = uid;
//        [self.infoView slidingShowWithSuperView:nil];
//    }
//}

#pragma mark ----------------- HNLiveChatToolsDelegate (公聊) -----------------

- (void)inputFuntionView:(HNLiveChatToolsView *)toolsView sendMessage:(NSString *)message barrageBtnSelect:(BOOL)isSelect
{
    if (message.length == 0)
    {
        [MBProgressHUD showError:@"请输入聊天信息"];
        return;
    }
    
    NSDictionary *dic = @{
                          @"word" : message,
                          @"send_type" : isSelect ? @"barrage" : @"public_msg",
                          @"uid" : self.anchorModel.uid
                          };
    [[HNRequestManager manager] sendRequestWithRequestMethodType:HNRequestMethodTypePOST requestAPICode:LiveSendMsg requestParameters:dic requestHeader:@{@"authorization" : kTOKEN} success:^(id responseObject) {
        
        if (CODE != 200)
        {
            MBErrorMsg;
            return ;
        }
        
    } faild:^(NSError *error) {
        ERROR;
    }];
}

- (void)didClickEmojiBtnWithBtn:(UIButton *)emojiBtn
{
    self.chatToolsView.emojiScrollView.hidden = NO;
    
    [self.view layoutIfNeeded];

    [UIView animateWithDuration:0.25 animations:^{
        
        CGRect ToolsViewRect = self.chatToolsView.frame;
        CGRect emojiScrollViewRect = self.chatToolsView.emojiScrollView.frame;
        CGRect oneBgViewRect = self.liveChatTable.frame;
        
        if (emojiBtn.selected == YES)
        {
            [self.chatToolsView.inputTextField resignFirstResponder];
            
            emojiScrollViewRect.origin.y = SCREEN_HEIGHT - EmojiKeyboard_Height;
            self.chatToolsView.emojiScrollView.frame = emojiScrollViewRect;
            
            ToolsViewRect.origin.y = SCREEN_HEIGHT - EmojiKeyboard_Height - self.chatToolsView.frame.size.height;
            self.chatToolsView.frame = ToolsViewRect;
        }
        else
        {
            [self.chatToolsView.inputTextField becomeFirstResponder];
            
            emojiScrollViewRect.origin.y = SCREEN_HEIGHT;
            self.chatToolsView.emojiScrollView.frame = emojiScrollViewRect;
        }
        
        oneBgViewRect.origin.y = ToolsViewRect.origin.y - oneBgViewRect.size.height;
        self.liveChatTable.frame = oneBgViewRect;
        
    }];
}
#pragma mark - UINavigationControllerDelegate

- (void)navigationController:(UINavigationController *)navigationController willShowViewController:(UIViewController *)viewController animated:(BOOL)animated
{
//    BOOL isShow = [viewController isKindOfClass:[self class]];
    [navigationController setNavigationBarHidden:YES animated:NO];
}

// 键盘监听
- (void)keyboardChange:(NSNotification *)notification
{
    NSDictionary *userInfo = [notification userInfo];
    
    NSTimeInterval animationDuration;
    UIViewAnimationCurve animationCurve;
    CGRect keyboardEndFrame;
    
    [[userInfo objectForKey:UIKeyboardAnimationCurveUserInfoKey] getValue:&animationCurve];
    [[userInfo objectForKey:UIKeyboardAnimationDurationUserInfoKey] getValue:&animationDuration];
    [[userInfo objectForKey:UIKeyboardFrameEndUserInfoKey] getValue:&keyboardEndFrame];
    
    if (self.liveMessageVC.view.superview && self.liveMessageVC != nil)
    {
        // 如果是私信
        return;
    }
    else
    {
        [UIView animateWithDuration:animationDuration animations:^{
            
            CGRect newFrame = self.chatToolsView.frame;
            newFrame.origin.y = keyboardEndFrame.origin.y - newFrame.size.height;
            self.chatToolsView.frame = newFrame;
            
            CGRect oneBgViewFrame = self.liveChatTable.frame;
            oneBgViewFrame.origin.y = newFrame.origin.y - oneBgViewFrame.size.height;
            self.liveChatTable.frame = oneBgViewFrame;
            
        } completion:^(BOOL finished)
         {
             for (UIButton *btn in self.bottomBtnArr)
             {
                 btn.hidden = NO;
             }
             if (self.chatToolsView.y == SCREEN_HEIGHT)
             {
             
                 
                 [self.chatToolsView.emojiScrollView removeFromSuperview];
                 [self.chatToolsView removeFromSuperview];
                 self.chatToolsView = nil;
             }

         }];
        
        CGRect emojiScrollViewRect = self.chatToolsView.emojiScrollView.frame;
        
        if (keyboardEndFrame.origin.y != SCREEN_HEIGHT)
        {
            self.chatToolsView.emojiBtn.selected = NO;
            
            emojiScrollViewRect.origin.y = SCREEN_HEIGHT;
            self.chatToolsView.emojiScrollView.frame = emojiScrollViewRect;
        }
        else
        {
            CGRect newFrame = self.chatToolsView.frame;
            newFrame.origin.y = SCREEN_HEIGHT;
            self.chatToolsView.frame = newFrame;
            
//            CGRect oneBgViewFrame = self.liveChatTable.frame;
//            oneBgViewFrame.origin.y = 0;
//            self.liveChatTable.frame = oneBgViewFrame;
        }
    }
}

#pragma mark ----------------- HNBigGiftViewDelegate(大礼物动画) -----------------


- (void)cleanView
{
    [self.bigGiftView removeFromSuperview];
    self.bigGiftView = nil;
    self.bigGiftImageArr = nil;
    [self.giftImageArr removeObject:self.giftImageArr.firstObject];
    [self continueReplaceShowBigGiftView];
    
}


// 再次进行大礼物动画的播放
- (void)continueReplaceShowBigGiftView
{
    if (self.giftImageArr.count > 0) {
        HNLiveChatMsgModel *msgModel = self.giftImageArr.firstObject;
        NSString *giftKey = [NSString stringWithFormat:@"%@_%@",msgModel.g_id,msgModel.g_name];
        
        if ([[HNTools BigGiftNameArray] containsObject:giftKey])
        {
            
            [self.bigGiftImageArr removeAllObjects];
            self.bigGiftImageArr = [HNTools getBigGiftPictureArray:giftKey];
            self.currentSendGiftMsgModel = msgModel;
            self.bigGiftView.infoLabel.text = [NSString stringWithFormat:@"%@送给主播一个%@",msgModel.nick,msgModel.g_name];
            [self.oneBgView insertSubview:self.bigGiftView atIndex:0];

        }
    }else{
        self.currentSendGiftMsgModel = nil;
    }

}


#pragma mark ----------------- HNLiveChatTableDelegate(聊天视图) -----------------

- (void)showUserInfoCardWithUid:(NSString *)uid
{
    if ([uid isEqualToString:kUserID])
    {
        return;
    }
    
    if (self.infoView.superview == nil)
    {
        self.infoView.anchorId = self.anchorModel.uid;
        self.infoView.uid = uid;
        [self.infoView slidingShowWithSuperView:self];
    }
}

#pragma mark ----------------- HNUserInfoCardViewDelegate （用户信息） -----------------

- (void)didClickFollowBtnWithChangeButton:(UIButton *)followBtn
{
    if (followBtn.isSelected)
    {
        // 关注
        NSDictionary *dic = @{
                              @"type" : @"add",
                              @"uid" : self.infoView.uid
                              };
        
        [[HNRequestManager manager] sendRequestWithRequestMethodType:HNRequestMethodTypePOST requestAPICode:ChangeFollow requestParameters:dic requestHeader:@{@"authorization" : kTOKEN} success:^(id responseObject) {
            
            if (CODE != 200)
            {
                MBErrorMsg;
                followBtn.selected = NO;
                return ;
            }
            
            followBtn.selected = YES;
            [followBtn setTitle:@"已关注" forState:UIControlStateSelected];
            
        } faild:^(NSError *error) {
            
            followBtn.selected = NO;
            ERROR;
        }];
    }
    else
    {
        // 取消关注
        NSDictionary *dic = @{
                              @"type" : @"cancel",
                              @"uid" : self.infoView.uid
                              };
        
        [[HNRequestManager manager] sendRequestWithRequestMethodType:HNRequestMethodTypePOST requestAPICode:ChangeFollow requestParameters:dic requestHeader:@{@"authorization" : kTOKEN} success:^(id responseObject) {
            
            if (CODE != 200)
            {
                MBErrorMsg;
                followBtn.selected = YES;
                return ;
            }
            
            followBtn.selected = NO;
            [followBtn setTitle:@"+关注" forState:UIControlStateNormal];
            
        } faild:^(NSError *error) {
            
            followBtn.selected = YES;
            ERROR;
        }];
    }
}

// 点击私信按钮
- (void)didClickPrivateMessageWithModel:(HNMessageModel *)model
{
    HNLiveChatMessageVC *vc = [[HNLiveChatMessageVC alloc] init];
    vc.uid = model.uid;
    vc.nick = model.nick;
    
    vc.ExitVCEnd = ^{
        
        [UIView animateWithDuration:0.25 animations:^{
            
            vc.view.transform = CGAffineTransformMakeTranslation(0, SCREEN_HEIGHT);
            
        } completion:^(BOOL finished) {
            
        }];
    };
    
    vc.view.frame = CGRectMake(0, SCREEN_HEIGHT, SCREEN_WIDTH, SCREEN_HEIGHT);
    [self addChildViewController:vc];
    [self.view addSubview:vc.view];
    
    [UIView  animateWithDuration:0.25 animations:^{
        vc.view.transform = CGAffineTransformMakeTranslation(0, -SCREEN_HEIGHT);;
    }];
}

-(void)headerBgAction:(HNMessageModel *)model{
    HNPersonalHomeHageVC *personalHomeHageVC=[HNPersonalHomeHageVC new];
     personalHomeHageVC.uid=model.uid;
    [self.navigationController pushViewController:personalHomeHageVC animated:YES];
}
// 私信消息列表界面消失
- (void)liveMessageShowOrHidden:(NSNotification *)notifi
{
    NSString *str = notifi.object;
    if ([str isEqualToString:@"removeMessageList"])
    {
        [UIView animateWithDuration:0.25 animations:^{
            self.liveMessageVC.view.transform =CGAffineTransformMakeTranslation(0, SCREEN_HEIGHT);
            
        } completion:^(BOOL finished) {
            
            self.chatToolsView.emojiScrollView.hidden = YES;
            
            [self.liveMessageVC removeFromParentViewController];
            self.liveMessageVC = nil;
        }];
    }
}

- (void)didChangeShutupStatusWithButton:(UIButton *)shutupBtn
{
    NSDictionary *dic = @{
                          @"is_banned_say" :  shutupBtn.isSelected ? @"1" : @"0",
                          @"banned_say_uid" : self.infoView.uid,
                          @"rid" : self.anchorModel.uid
                          };
    
    [[HNRequestManager manager] sendRequestWithRequestMethodType:HNRequestMethodTypePOST requestAPICode:SetBannedSay requestParameters:dic requestHeader:@{@"authorization" : kTOKEN} success:^(id responseObject) {
        
        if (CODE != 200)
        {
            MBErrorMsg;
            shutupBtn.selected = shutupBtn.isSelected ? NO : YES;
            return ;
        }
        
        if (shutupBtn.isSelected)
        {
            shutupBtn.selected = YES;
            [shutupBtn setTitle:@"解除禁言" forState:UIControlStateSelected];
        }
        else
        {
            shutupBtn.selected = NO;
            [shutupBtn setTitle:@"禁言" forState:UIControlStateNormal];
        }
        
    } faild:^(NSError *error) {
        
        shutupBtn.selected = shutupBtn.isSelected ? NO : YES;
        ERROR;
    }];
}

- (void)didChangeFieldControlStatusWithButton:(UIButton *)fieldControlBtn
{
    NSDictionary *dic = @{
                          @"is_field_control" : fieldControlBtn.isSelected ? @"1" : @"0",
                          @"uid" : self.infoView.uid
                          };
    
    [[HNRequestManager manager] sendRequestWithRequestMethodType:HNRequestMethodTypePOST requestAPICode:SetFieldControl requestParameters:dic requestHeader:@{@"authorization" : kTOKEN} success:^(id responseObject) {
        
        if (CODE != 200)
        {
            MBErrorMsg;
            fieldControlBtn.selected = fieldControlBtn.isSelected ? NO : YES;
            return ;
        }
        
        if (fieldControlBtn.isSelected)
        {
            fieldControlBtn.selected = YES;
            [fieldControlBtn setTitle:@"取消场控" forState:UIControlStateSelected];
        }
        else
        {
            fieldControlBtn.selected = NO;
            [fieldControlBtn setTitle:@"设为场控" forState:UIControlStateNormal];
        }
        
    } faild:^(NSError *error) {
        
        fieldControlBtn.selected = fieldControlBtn.isSelected ? NO : YES;
        ERROR;
    }];
}

#pragma mark ----------------- HNLiveAnchorUserInfoViewDelegate(主播信息) -----------------

- (void)didClickShowFansContributionList
{
    HNFansContributionListVC *vc = [[HNFansContributionListVC alloc] init];
    vc.rid = self.anchorModel.uid;
    [self.navigationController pushViewController:vc animated:YES];
}

#pragma mark ----------------- HNSkinCareViewDelegate(美颜) -----------------

- (void)sliderValueChangeWithSkinCareValue:(CGFloat)skinCare whiteningValue:(CGFloat)whitening ruddyValue:(CGFloat)ruddy type:(BOOL)isSmooth
{
    [self.streamView changeSkinCareWithType:isSmooth skinCareValue:skinCare whiteningValue:whitening ruddyValue:ruddy];
}

#pragma mark -  界面按钮点击
- (void)viewsBtnClick:(UIButton *)btn
{
    
    
    
    switch (btn.tag)
    {
        case 7000:
        {
            // 评论
            
            [self.view addSubview:self.chatToolsView];
            [self.chatToolsView.inputTextField becomeFirstResponder];
            
            for (UIButton *button in self.bottomBtnArr)
            {
                button.hidden = YES;
            }
            
            
        }
            break;
            
        case 7001:
        {
            // 私信
            self.liveMessageVC = [[HNLiveMessageVC alloc] init];
            self.liveMessageVC.anchorModel = self.anchorModel;
            self.liveMessageVC.isAnchor = YES;
            self.liveMessageVC.view.frame = CGRectMake(0, SCREEN_HEIGHT, SCREEN_WIDTH, SCREEN_HEIGHT);
            [self addChildViewController:self.liveMessageVC];
            [self.view addSubview:self.liveMessageVC.view];
            
            [UIView animateWithDuration:0.25 animations:^{
                self.liveMessageVC.view.transform =CGAffineTransformMakeTranslation(0, -SCREEN_HEIGHT);
            }];
        }
            break;
            
        case 7002:
        {
            // 切换摄像头
            btn.selected = !btn.selected;
            
            [self.streamView changeCamer];
        }
            break;
            
        case 7003:
        {
            // 美颜
            btn.selected = !btn.selected;
            HNSkinCareView *view = [[HNSkinCareView alloc] init];
            view.skinDelegate = self;
            [view show];
            
            self.skinCareView = view;
            
        }
            break;
            
        case 7005:
        {


            HNShareModel *shareModel=[HNShareModel new];
            shareModel.title=@"快来看我直播吧";
            shareModel.Desc=@"夕阳红直播，中老年人的专属直播平台，中国第一中老年直播平台";
            shareModel.webpageUrl=[NSString stringWithFormat:@"%@/live/%@/detail",WEBREQUEST,self.anchorModel.uid];;
            shareModel.thumImg=self.liveImage;//[UIImage imageNamed:_anchorModel.avatar];
            HNShareView *shareView=[HNShareView initHNShareView];
            [shareView showView:nil shareModel:shareModel];
//            [self addConnectView:@"http://wssource.rtc.inke.cn/live/1535440528663624.flv?ikHost=ws&ikOp=1&codecInfo=8192&dpSrc=push&ikDnsOp=1001"];
        }
            break;
            
        case 7004:
        {
            // 退出
            
            NSString *string = [NSString stringWithFormat:@"当前有%ld人观看",(long)[self.userInfoView.onlines integerValue]];
            NSString *allStr = [NSString stringWithFormat:@"%@\t%@",string,@"你确定结束直播吗？"];
            HNAlertView *view = [[HNAlertView alloc] initWithTitle:nil Content:allStr whitTitleArray:@[@"取消",@"确定"] withType:@"center"];
            
            _weakself;
            [view showAlertView:^(NSInteger index) {
                if (index == 1)
                {
                    
                    
                    weakself.isForbidden = YES;
                    
                    [weakself stopLive];
                }
            }];
        }
            break;
        case 7006:
        {
            [self  updateconectBtn];
            _weakself;
            self.headsetView.cancelBtnBlock = ^{
                _strongSelf;
                strongSelf.headsetView = nil;
            };
            [self.headsetView show:3 congUserIdArr:self.congUserIdArr];
        }
            break;
        default:
            break;
    }
}

#pragma mark - privateMethod

// 观看区域处理
- (void)insertLookUserWithModel:(HNLiveUserModel *)model type:(NSString *)type
{
    dispatch_async(dispatch_get_main_queue(), ^{
        
        if (self.lookUserArr.count > 50)
        {
            // 观众榜最多显示50个人
            [self.lookUserArr removeObjectAtIndex:50];
        }
        
        for ( HNLiveUserModel *userModel in self.lookUserArr.reverseObjectEnumerator) {
            if ([userModel.uid isEqualToString:model.uid])
            {
                [self.lookUserArr removeObject:model];
            }
        }
        if ([type isEqualToString:@"user"]) {
            [self.lookUserArr insertObject:model atIndex:0];
        }else{
            [self.lookUserArr addObject:model];
        }
        [self reloadUserCollection];
    });
}

- (void)reloadUserCollection
{
    [self.lookUserCollection mas_updateConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(self.userInfoView.headerBgView.mas_right).mas_offset(Handle(10));
    }];

    [self.lookUserCollection reloadData];
}

// 聊天区域处理
- (void)insertChatTableWithModel:(HNLiveChatMsgModel *)msgModel
{
    [msgModel calculationcellHeight];
    [self.chatListArr addObject:msgModel];

    if (self.chatListArr.count > 50)
    {
        [self.chatListArr removeObjectAtIndex:0];
    }
    
    if ([msgModel.level integerValue] >= 15)
    {
        // 进场动画
        [[HNFlyManger sharedManger] mangerPeopleEnterRoom:msgModel parentView:self.oneBgView];
    }
    
    [self chatTableScrollToBottom];
 

}

- (void)chatTableScrollToBottom
{
//     @synchronized(self) {
    
            [self.liveChatTable reloadData];
    
            if (self.chatListArr.count == 0)
            {
                return ;
            }
            
            if (self.chatListArr.count > 1)
            {
                @try {
                    NSIndexPath *indexPath = [NSIndexPath indexPathForRow:self.chatListArr.count - 1 inSection:0];

                    [self.liveChatTable scrollToRowAtIndexPath:indexPath atScrollPosition:UITableViewScrollPositionBottom animated:NO];
                } @catch (NSException *exception) {
                    
                } @finally {
                    
                }
               
            }
    
        
//     }
}

#pragma mark - UICollectionViewDelegate

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    if (self.lookUserArr.count > 50) {
        return 50;
    }
    else
    {
        return self.lookUserArr.count;
    }
}

- (__kindof UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    HNLiveSeeUserCollectionCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"seeCell" forIndexPath:indexPath];
    
    if (indexPath.row < 50) {
        cell.userModel = self.lookUserArr[indexPath.row];
    }
    
    return cell;
}

- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath
{
    return CGSizeMake(Handle_width(40), Handle_height(40));
}

- (UIEdgeInsets)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout insetForSectionAtIndex:(NSInteger)section
{
    return UIEdgeInsetsMake(Handle(5), 0, Handle(5), 0);
}

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.row < 50) {
        [collectionView deselectItemAtIndexPath:indexPath animated:YES];
        
        HNUserModel *model = self.lookUserArr[indexPath.row];
        
        [self showUserInfoCardWithUid:model.uid];
    }
}

#pragma mark - setUI

- (void)setUI
{
    [self.view addSubview:self.scrollerView];
//    [self.view insertSubview:self.streamView aboveSubview:self.oneBgView];
   
    [self.scrollerView addSubview:self.oneBgView];
    [self.oneBgView addSubview:self.streamView];
    [self.oneBgView addSubview:self.userInfoView];
    [self.oneBgView addSubview:self.lookUserCollection];
    [self.oneBgView bringSubviewToFront:self.lookUserCollection];
    [self.oneBgView addSubview:self.liveChatTable];
    
    [self.oneBgView addSubview:self.commentBtn];
    [self.oneBgView addSubview:self.privateMsgBtn];
    [self.oneBgView addSubview:self.cameraBtn];
    [self.oneBgView addSubview:self.skinCareBtn];
    [self.oneBgView addSubview:self.changeTypeBtn];
//     self.changeTypeBtn.hidden=YES;
    [self.oneBgView addSubview:self.exitLiveBtn];
    [self.oneBgView addSubview:self.connectBtn];

    [self setMasonry];
    
}

- (void)setMasonry
{
    [self.userInfoView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.left.right.mas_equalTo(self.oneBgView).priorityHigh();
    }];
    
    [self.lookUserCollection mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.mas_equalTo(self.oneBgView.mas_right).mas_offset(-Handle(4.5));
        make.height.mas_offset(Handle_height(55));
        make.centerY.mas_equalTo(self.userInfoView.headerBgView.mas_centerY);
        make.left.mas_equalTo(self.userInfoView.headerBgView.mas_right).mas_offset(Handle(10));
    }];
    
    [self.liveChatTable mas_makeConstraints:^(MASConstraintMaker *make) {
        make.bottom.mas_equalTo(self.commentBtn.mas_top).mas_offset(-Handle(20));
        make.left.mas_equalTo(self.oneBgView);
        make.height.mas_offset(Handle_height(160));
        make.width.mas_offset(Handle_width(285));
    }];
    
    [self.commentBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_offset(kSpaceToLeftOrRight);
        make.bottom.mas_equalTo(self.oneBgView.mas_bottom).mas_offset(-kSpaceToLeftOrRight);
    }];
    
    [self.privateMsgBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(self.commentBtn.mas_right).mas_offset(Handle(10));
        make.centerY.mas_equalTo(self.commentBtn);
    }];
    
    [self.cameraBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(self.privateMsgBtn.mas_right).mas_offset(Handle(10));
        make.centerY.mas_equalTo(self.privateMsgBtn);
    }];
    
    [self.skinCareBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(self.cameraBtn.mas_right).mas_offset(Handle(10));
        make.centerY.mas_equalTo(self.cameraBtn);
    }];
    
    [self.changeTypeBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(self.skinCareBtn.mas_right).mas_offset(Handle(10));
        make.centerY.mas_equalTo(self.skinCareBtn);
    }];
    [self.connectBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.bottom.mas_equalTo(self.exitLiveBtn.mas_top).mas_offset(-Handle(10));
        make.right.mas_equalTo(self.oneBgView).mas_offset(-kSpaceToLeftOrRight);
        make.height.mas_offset(Handle_height(60));
        make.width.mas_offset(Handle_width(60));
    }];
    [self.exitLiveBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.mas_equalTo(self.oneBgView).mas_offset(-kSpaceToLeftOrRight);
        make.centerY.mas_equalTo(self.commentBtn);
    }];
    
    [self.view layoutIfNeeded];
}

#pragma mark - getter

- (UIScrollView *)scrollerView
{
    if (!_scrollerView)
    {
        _scrollerView = InsertScrollView(nil, CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT), 88, self);
        _scrollerView.backgroundColor = [UIColor clearColor];
        _scrollerView.showsHorizontalScrollIndicator = NO;
        _scrollerView.pagingEnabled = NO;
        _scrollerView.bounces = NO;
        _scrollerView.contentSize = CGSizeMake(SCREEN_WIDTH * 2, 0);
        _scrollerView.contentOffset = CGPointMake(SCREEN_WIDTH, 0);
        
        _scrollerView.userInteractionEnabled = YES;
        _scrollerView.scrollEnabled = NO;
    }
    return _scrollerView;
}

- (UIView *)oneBgView
{
    if(!_oneBgView)
    {
        _oneBgView = InsertView(nil, CGRectMake(SCREEN_WIDTH, 0, SCREEN_WIDTH, SCREEN_HEIGHT), [UIColor clearColor]);
        _oneBgView.tag = 666;
    }
    return _oneBgView;
}

- (UIImageView *)streamBgImageView
{
    if (!_streamBgImageView)
    {
        _streamBgImageView = InsertImageView(nil, CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT), nil);
    }
    return _streamBgImageView;
}

- (HNTXLivePushView *)streamView
{
    if (!_streamView)
    {
        _streamView = [HNTXLivePushView livePushView];
        _streamView.isRecording=_isRecording;
    }
    return _streamView;
}

- (HNTXLivePlayerView *)pullFlowView1
{
    if (!_pullFlowView1)
    {
        _pullFlowView1 = [HNTXLivePlayerView livePlayerView];
        _pullFlowView1.frame= CGRectMake(SCREEN_WIDTH-(X(250)+10), SCREEN_HEIGHT-(Y(354)*1)-30-20, X(250), Y(350));
        _weakself;
        _pullFlowView1.colseBlock = ^{
            _strongSelf;
            strongSelf.pullFlowView1=nil;
        };
//         [self.oneBgView insertSubview:_pullFlowView1 atIndex:0];
        [self.view insertSubview:_pullFlowView1 aboveSubview:self.streamView];
    }
    return _pullFlowView1;
}
- (HNTXLivePlayerView *)pullFlowView2
{
    if (!_pullFlowView2)
    {
        _pullFlowView2 = [HNTXLivePlayerView livePlayerView];
        _pullFlowView2.frame= CGRectMake(SCREEN_WIDTH-(X(250)+10), SCREEN_HEIGHT-(Y(354)*2)-30-20, X(250), Y(350));
        _weakself;
        _pullFlowView2.colseBlock = ^{
            _strongSelf;
            strongSelf.pullFlowView2=nil;
        };

//        [self.oneBgView insertSubview:_pullFlowView2 atIndex:0];
        [self.view insertSubview:_pullFlowView2 aboveSubview:self.streamView];

    }
    return _pullFlowView2;
}
- (HNTXLivePlayerView *)pullFlowView3
{
    if (!_pullFlowView3)
    {
        _pullFlowView3 = [HNTXLivePlayerView livePlayerView];
        _pullFlowView3.frame=CGRectMake(SCREEN_WIDTH-(X(250)+10), SCREEN_HEIGHT-(Y(354)*3)-30-20, X(250), Y(350));
        _weakself;
        _pullFlowView3.colseBlock = ^{
            _strongSelf;
            strongSelf.pullFlowView3=nil;
        };
        [self.view insertSubview:_pullFlowView3 aboveSubview:self.streamView];
//        [self.oneBgView insertSubview:_pullFlowView3 atIndex:0];
//                [self.view insertSubview:_pullFlowView3 aboveSubview:self.scrollerView];

    }
    return _pullFlowView3;
}
- (HNLiveAnchorUserInfoView *)userInfoView
{
    if (!_userInfoView)
    {
        _userInfoView = [[HNLiveAnchorUserInfoView alloc] init];
        _userInfoView.isAnchor = YES;
        _userInfoView.infoViewDelegate = self;
    }
    return _userInfoView;
}

- (UICollectionView *)lookUserCollection
{
    if (!_lookUserCollection)
    {
        UICollectionViewFlowLayout *layout=[[UICollectionViewFlowLayout alloc]init];
        layout.scrollDirection = UICollectionViewScrollDirectionHorizontal;
        layout.minimumInteritemSpacing = Handle(10);
        
        _lookUserCollection = [[UICollectionView alloc] initWithFrame:CGRectZero collectionViewLayout:layout];
        _lookUserCollection.backgroundColor = [UIColor clearColor];
        _lookUserCollection.delegate = self;
        _lookUserCollection.dataSource = self;
        
         _lookUserCollection.showsVerticalScrollIndicator = NO;
        
        [_lookUserCollection registerClass:[HNLiveSeeUserCollectionCell class] forCellWithReuseIdentifier:@"seeCell"];
    }
    return _lookUserCollection;
}

- (HNLiveChatTable *)liveChatTable
{
    if (!_liveChatTable)
    {
        _liveChatTable = [HNLiveChatTable liveChatTable];
        _liveChatTable.backgroundColor = [UIColor clearColor];
        _liveChatTable.dataSourceArr = self.chatListArr;
        _liveChatTable.tableDelegate = self;
    }
    return _liveChatTable;
}

- (UIButton *)commentBtn
{
    if(!_commentBtn)
    {
        _commentBtn = InsertImageButton(nil, CGRectZero, 7000, GetImage(@"xinxi"), nil, self, @selector(viewsBtnClick:));
        
        [self.bottomBtnArr addObject:self.commentBtn];
    }
    return _commentBtn;
}

- (UIButton *)privateMsgBtn
{
    if(!_privateMsgBtn)
    {
        _privateMsgBtn = InsertImageButton(nil, CGRectZero, 7001, GetImage(@"sixin"), nil, self, @selector(viewsBtnClick:));
        
        [self.bottomBtnArr addObject:self.privateMsgBtn];
    }
    return _privateMsgBtn;
}

- (UIButton *)cameraBtn
{
    if(!_cameraBtn)
    {
        _cameraBtn = InsertImageButton(nil, CGRectZero, 7002, GetImage(@"xiangji_noselect"), nil, self, @selector(viewsBtnClick:));
        
        [self.bottomBtnArr addObject:self.cameraBtn];
    }
    return _cameraBtn;
}

- (UIButton *)skinCareBtn
{
    if(!_skinCareBtn)
    {
        _skinCareBtn = InsertImageButton(nil, CGRectZero, 7003, GetImage(@"meiyan"), nil, self, @selector(viewsBtnClick:));
        _skinCareBtn.selected = YES;
        
        [self.bottomBtnArr addObject:self.skinCareBtn];
    }
    return _skinCareBtn;
}

- (UIButton *)changeTypeBtn
{
    if(!_changeTypeBtn)
    {
        _changeTypeBtn = InsertImageButton(nil, CGRectZero, 7005, GetImage(@"share1"), nil, self, @selector(viewsBtnClick:));
        _changeTypeBtn.selected = YES;
        
        [self.bottomBtnArr addObject:self.changeTypeBtn];
    }
    return _changeTypeBtn;
}

- (UIButton *)exitLiveBtn
{
    if(!_exitLiveBtn)
    {
        _exitLiveBtn = InsertImageButton(nil, CGRectZero, 7004, GetImage(@"tuichu_zhibojian"), nil, self, @selector(viewsBtnClick:));
        
        [self.bottomBtnArr addObject:self.exitLiveBtn];
    }
    return _exitLiveBtn;
}

- (JXButton *)connectBtn
{
    if(!_connectBtn)
    {
        _connectBtn = [[JXButton alloc] initWithFrame:CGRectZero];
        _connectBtn.tag = 7006;
        [_connectBtn addTarget:self action:@selector(viewsBtnClick:) forControlEvents:UIControlEventTouchUpInside];
        _connectBtn.layer.cornerRadius = 5;
        //        [_connectBtn setTitle:@"Oh,Dog!" forState:0];
        [_connectBtn setTitle:@"连麦互动" forState:UIControlStateNormal];
        _connectBtn.backgroundColor = [UIColor colorWithWhite:0.f alpha:0.3];
        [_connectBtn setTitleColor:[UIColor blackColor] forState:0];
        [_connectBtn setImage:[UIImage imageNamed:@"connect"] forState:0];
        [_connectBtn setTitleColor: [UIColor whiteColor] forState:UIControlStateNormal];
        
        [self.bottomBtnArr addObject:_connectBtn];
    }
    return _connectBtn;
}
- (HNLiveChatToolsView *)chatToolsView
{
    if (!_chatToolsView)
    {
        _chatToolsView = [[HNLiveChatToolsView alloc] initWithSuperView:self.view];
        _chatToolsView.toolsDelegate = self;
        _chatToolsView.barragePrice = self.infoModel.barrage_price;
    }
    return _chatToolsView;
}

- (HNBigGiftView *)bigGiftView
{
    if (!_bigGiftView)
    {
        _bigGiftView = [[HNBigGiftView alloc] initWithFrame:self.view.bounds WithAnimalArray:self.bigGiftImageArr withTimeinterval:0.1 withTimes:1];
        _bigGiftView.delegate = self;
    }
    return _bigGiftView;
}

- (HNUserInfoCardView *)infoView
{
    if (!_infoView)
    {
        _infoView = [[HNUserInfoCardView alloc] init];
        _infoView.isShowLive = YES;
        _infoView.isAnchor = YES;
        _infoView.cardDelegate = self;
    }
    return _infoView;
}

- (NSMutableArray *)bigGiftImageArr
{
    if (!_bigGiftImageArr)
    {
        _bigGiftImageArr = [NSMutableArray array];
    }
    return _bigGiftImageArr;
}

- (NSMutableArray *)bottomBtnArr
{
    if (!_bottomBtnArr)
    {
        _bottomBtnArr = [NSMutableArray array];
    }
    return _bottomBtnArr;
}

- (NSMutableArray *)lookUserArr
{
    if (!_lookUserArr)
    {
        _lookUserArr = [NSMutableArray array];
    }
    return _lookUserArr;
}

- (NSMutableArray *)chatListArr
{
    if (!_chatListArr)
    {
        _chatListArr = [NSMutableArray array];
    }
    return _chatListArr;
}

- (NSMutableArray *)joinUserIdArr
{
    if (!_joinUserIdArr)
    {
        _joinUserIdArr = [NSMutableArray array];
    }
    return _joinUserIdArr;
}

- (NSMutableArray *)giftImageArr
{
    if (!_giftImageArr)
    {
        _giftImageArr = [NSMutableArray array];
    }
    return _giftImageArr;
}

- (NSMutableArray *)congUserIdArr
{
    if (!_congUserIdArr)
    {
        _congUserIdArr = [NSMutableArray array];
    }
    return _congUserIdArr;
}

-(HNHeadsetView *)headsetView{
    if (!_headsetView) {
        _headsetView=[[HNHeadsetView alloc]initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT)];
    }
    return  _headsetView;
}
//- (XSJBeautifulShowTimeView *)beautifulView{
//    if (!_beautifulView) {
//        _beautifulView = [[XSJBeautifulShowTimeView alloc] initWithFrame:self.view.bounds];
//        
//    }
//    return _beautifulView;
//}


@end
