//
//  HNLiveSystemMessageVC.h
//  SunsetLive
//
//  Created by Sunwanwan on 2017/10/31.
//  Copyright © 2017年 HN. All rights reserved.
//

#import "HNBaseViewController.h"

@interface HNLiveSystemMessageVC : HNBaseViewController

@property (nonatomic, strong) NSString *uid;  // 用户uid

@end
