//
//  HNLiveMessageVC.h
//  SunsetLive
//
//  Created by Sunwanwan on 2017/9/15.
//  Copyright © 2017年 HN. All rights reserved.
//  直播间私聊视图

#import "HNBaseViewController.h"
#import "HNLiveAnchorModel.h"

@interface HNLiveMessageVC : HNBaseViewController

@property (nonatomic, assign) BOOL isAnchor; // 主播端还是用户端
@property (nonatomic, strong) HNLiveAnchorModel *anchorModel; // 当前主播

@end
