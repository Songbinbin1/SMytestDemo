//
//  HNLiveChatMessageVC.h
//  SunsetLive
//
//  Created by Sunwanwan on 2017/9/15.
//  Copyright © 2017年 HN. All rights reserved.
//

#import "HNBaseViewController.h"

@interface HNLiveChatMessageVC : HNBaseViewController

@property (nonatomic, strong) NSString *uid;  // 用户uid
@property (nonatomic, strong) NSString *nick; // 用户昵称

@property (nonatomic, strong) void(^ExitVCEnd) ();

@end
