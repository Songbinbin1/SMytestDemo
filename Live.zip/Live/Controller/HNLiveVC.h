//
//  HNLiveVC.h
//  LiveShow
//
//  Created by Sunwanwan on 2017/7/17.
//  Copyright © 2017年 HN. All rights reserved.
//  开启直播

#import "HNBaseViewController.h"

@interface HNLiveVC : HNBaseViewController

@property (nonatomic, strong) NSString *uid;

@property (nonatomic, strong) NSString *rule_url; // 推流地址

@end
