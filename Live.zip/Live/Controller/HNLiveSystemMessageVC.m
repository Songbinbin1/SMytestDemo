//
//  HNLiveSystemMessageVC.m
//  SunsetLive
//
//  Created by Sunwanwan on 2017/10/31.
//  Copyright © 2017年 HN. All rights reserved.
//

#import "HNLiveSystemMessageVC.h"
#import "HNSystemMessageCell.h"

@interface HNLiveSystemMessageVC () <UITableViewDelegate, UITableViewDataSource>
{
    NSInteger _page;
}

@property (nonatomic, strong) UIView *headerView;
@property (nonatomic, strong) UILabel *descLab;
@property (nonatomic, strong) UIButton *backBtn;
@property (nonatomic, strong) UIView *line;

@property (nonatomic, strong) UITableView *mainTable;

@property (nonatomic, strong) NSMutableArray *dataArray;

@end

@implementation HNLiveSystemMessageVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    self.view.backgroundColor = [UIColor clearColor];
    self.automaticallyAdjustsScrollViewInsets = NO;
    
    [self setUI];
    _page = 0;
    [self.mainTable.mj_header beginRefreshing];
    
     self.descLab.text = @"系统消息";

}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - loadData

- (void)loadDataWithPage:(NSInteger)page
{
    NSDictionary *dic = @{
                          @"page" : @(page)
                          };
    
    [[HNRequestManager manager] sendRequestWithRequestMethodType:HNRequestMethodTypeGET requestAPICode:SystemMessageList requestParameters:dic requestHeader:@{@"authorization" : kTOKEN} success:^(id responseObject) {
        
        [self.mainTable.mj_header endRefreshing];
        [self.mainTable.mj_footer endRefreshing];
        
        if (CODE != 200)
        {
            MBErrorMsg;
            return ;
        }
        
        NSArray *array = [NSArray yy_modelArrayWithClass:[HNSystemMessageModel class] json:responseObject[@"d"][@"msg_list"][@"items"]];
        
        if (page == 1)
        {
            self.dataArray = [NSMutableArray arrayWithArray:array];
        }
        else
        {
            [self.dataArray addObjectsFromArray:array];
        }
        
        if (array.count>0) {
            _page ++;
        }
        if (self.dataArray.count < [responseObject[@"d"][@"msg_list"][@"total"] integerValue])
        {
            self.mainTable.mj_footer.hidden = NO;
        }
        else
        {
            self.mainTable.mj_footer.hidden = YES;
        }
        
        if (self.dataArray.count == 0)
        {
            [self loadAbankViewWithSuperView:self.mainTable frame:self.mainTable.bounds imageStr:@"defaultpage_null" descStr:@"暂时还没有消息哦"];
        }
        else
        {
            [self.baseBankView removeFromSuperview];
        }
        
        [self.mainTable reloadData];
        
    } faild:^(NSError *error) {
        
        [self.mainTable.mj_header endRefreshing];
        [self.mainTable.mj_footer endRefreshing];
        
        ERROR;
        
    }];
}

- (void)exitMessageDetail
{
    NSDictionary *dic = @{
                          @"uid" : self.uid
                          };
    
    [[HNRequestManager manager] sendRequestWithRequestMethodType:HNRequestMethodTypePOST requestAPICode:QuitChat requestParameters:dic requestHeader:@{@"authorization" : kTOKEN} success:^(id responseObject) {
        
        if (CODE != 200)
        {
            
            return ;
        }
        
        // 发个通知处理用户的总的未读消息数
        NSString *total_unread = responseObject[@"d"][@"total_unread"];
        
        [UserDefault setValue:total_unread forKey:UnreadMessageCount];
        [UserDefault synchronize];
        
        [[NSNotificationCenter defaultCenter] postNotificationName:kChangeTotalUnread object:nil userInfo:@{kUnReadKey:total_unread}];
        
        // 处理当前用户在消息列表里面的未读小红点显示
        [[NSNotificationCenter defaultCenter] postNotificationName:@"ChangeCurrentIDUnread" object:nil userInfo:@{@"uid" : self.uid}];
        
        // 在这里发一个通知到消息界面， 把当前用户的未读消息数处理了
        [[NSNotificationCenter defaultCenter] postNotificationName:@"allMessageisReadWithUser" object:nil userInfo:@{@"uid" : self.uid}];
        
    } faild:^(NSError *error) {
        
    }];
}


#pragma mark - MJRefresh

- (void)headerRefreshing
{
    _page = 1;
    [self loadDataWithPage:_page];
}

- (void)footerRefreshing
{
   
    [self loadDataWithPage:_page];
}

#pragma mark - privateMethod

- (void)backBtnClick
{
    [self exitMessageDetail];
    
    [UIView animateWithDuration:0.25 animations:^{
        
        [self.view removeFromSuperview];
        [self removeFromParentViewController];
        
    } completion:^(BOOL finished) {
        
        
    }];
}

#pragma mark - 数据源方法
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.dataArray.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    HNSystemMessageCell *cell = [HNSystemMessageCell systemMessageCellWithTableView:tableView];
    
    cell.model = self.dataArray[indexPath.row];
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    HNSystemMessageCell *cell = (HNSystemMessageCell *)[self tableView:tableView cellForRowAtIndexPath:indexPath];
    return [cell cellHeight];
}

#pragma mark - setUI

- (void)setUI
{
    [self.view addSubview:self.headerView];
    [self.headerView addSubview:self.backBtn];
    [self.headerView addSubview:self.descLab];
    [self.headerView addSubview:self.line];
    
    [self.view addSubview:self.mainTable];
    
    [self.headerView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.width.mas_equalTo(self.view);
        make.height.mas_offset(Handle_height(85 / 2));
        make.bottom.mas_offset(-Handle(512 / 2));
    }];
    
    [self.backBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_offset(kSpaceToLeftOrRight);
        make.centerY.mas_equalTo(self.headerView.mas_centerY);
    }];
    
    [self.descLab mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.centerX.mas_equalTo(self.headerView);
    }];
    
    [self.line mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.width.bottom.mas_equalTo(self.headerView);
        make.height.mas_offset(Handle(0.5));
    }];
    
    [self.mainTable mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.width.bottom.mas_equalTo(self.view);
        make.top.mas_equalTo(self.headerView.mas_bottom);
    }];
    
    [self.view layoutIfNeeded];
}

#pragma mark - getter

- (UIView *)headerView
{
    if(!_headerView)
    {
        _headerView = InsertView(nil, CGRectZero, CString(WhiteColor));
    }
    return _headerView;
}

- (UILabel *)descLab
{
    if(!_descLab)
    {
        _descLab = InsertLabel(nil, CGRectZero, NSTextAlignmentLeft, @"", SystemFontSize18, CString(TitleColor));
    }
    return _descLab;
}

- (UIButton *)backBtn
{
    if(!_backBtn)
    {
        _backBtn = InsertImageButton(nil, CGRectZero, 888, GetImage(@"live_back"), nil, self, @selector(backBtnClick));
        
        [_backBtn setEnlargeEdgeWithTop:10 right:10 bottom:10 left:10];
    }
    return _backBtn;
}

- (UIView *)line
{
    if(!_line)
    {
        _line = InsertView(nil, CGRectZero, CString(LineColor));
    }
    return _line;
}

- (UITableView *)mainTable
{
    if (!_mainTable)
    {
        _mainTable = InsertTableView(nil, self.view.bounds, self, self, UITableViewStylePlain, UITableViewCellSeparatorStyleNone);
        _mainTable.showsVerticalScrollIndicator = NO;
        
        _weakself;
        _mainTable.mj_header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
            
            [weakself headerRefreshing];
        }];
        _mainTable.mj_footer = [MJRefreshAutoNormalFooter footerWithRefreshingBlock:^{
            
            [weakself footerRefreshing];
        }];
    }
    return _mainTable;
}

- (NSMutableArray *)dataArra
{
    if (!_dataArray)
    {
        _dataArray = [[NSMutableArray alloc] init];
    }
    return _dataArray;
}

@end
