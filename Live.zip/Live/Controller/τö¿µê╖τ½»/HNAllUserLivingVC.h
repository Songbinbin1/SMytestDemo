//
//  HNAllUserLivingVC.h
//  SunsetLive
//
//  Created by Sunwanwan on 2017/10/10.
//  Copyright © 2017年 HN. All rights reserved.
//  上下直播屏切换

#import "HNBaseViewController.h"

@interface HNAllUserLivingVC : HNBaseViewController

@property (nonatomic, strong) NSArray *roomsArray;  // 首页的数据源
@property (nonatomic, assign) NSInteger currentIndex;

@end
