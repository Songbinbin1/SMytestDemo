//
//  HNAllUserLivingVC.m
//  SunsetLive
//
//  Created by Sunwanwan on 2017/10/10.
//  Copyright © 2017年 HN. All rights reserved.
//

#import "HNAllUserLivingVC.h"
#import "HNUserLiveVC.h"
#import "HNLiveListModel.h"
#import "HNUserLiveEndVC.h"
#import "HNHttpRequest.h"
@interface HNAllUserLivingVC () <UIScrollViewDelegate, UINavigationControllerDelegate>
{
    HNUserLiveVC *live1;
    HNUserLiveVC *live2;
    HNUserLiveVC *live3;
}

@property (nonatomic, strong) UIScrollView *mainScrollView;
@property (nonatomic, strong) dispatch_source_t watchtimer;
@end

@implementation HNAllUserLivingVC

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
    self.navigationController.delegate = self;
    
    if (@available(iOS 11.0, *))
    {
        self.mainScrollView.contentInsetAdjustmentBehavior = UIScrollViewContentInsetAdjustmentNever;
    }
    else
    {
        self.automaticallyAdjustsScrollViewInsets = NO;
    }
    
    self.automaticallyAdjustsScrollViewInsets = NO;
    
    // 直播间出现键盘的时候不需要页面向上滚动
//    IQKeyboardManager *manager = [IQKeyboardManager sharedManager];
//    manager.enable = NO;
//    manager.enableAutoToolbar = NO;
    if (kUserID != nil &&  ![kUserID isEqualToString:@""])
    {
        
        dispatch_queue_t queue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0);
        _watchtimer = dispatch_source_create(DISPATCH_SOURCE_TYPE_TIMER, 0, 0, queue);
        
        dispatch_source_set_timer(_watchtimer,dispatch_walltime(NULL, 2.0*NSEC_PER_SEC),2.0*NSEC_PER_SEC, 0); //每秒执行
        _weakself;
        dispatch_source_set_event_handler(_watchtimer, ^{
            _strongSelf;
            [strongSelf watchTime];
            
        });
        dispatch_resume(_watchtimer);
    }
}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    
//    IQKeyboardManager *manager = [IQKeyboardManager sharedManager];
//    manager.enable = YES;
//    manager.enableAutoToolbar = YES;
    if(_watchtimer){
        dispatch_source_cancel(_watchtimer);
        _watchtimer=nil;
    }
}
-(void)watchTime{
    if (!HNWatch_Time) {
        [[NSUserDefaults standardUserDefaults] setObject:@"0" forKey:@"HNWatch_Time"];
    }
     int time=[HNWatch_Time intValue];
    time=time+2;
    DLog(@"-=-=-=-=-=-=-=-=%ld",(long)time);
    [[NSUserDefaults standardUserDefaults] setObject:[NSString stringWithFormat:@"%ld", (long)time] forKey:@"HNWatch_Time"];
    [UserDefault synchronize];
    if ((time%HNwatchNum)==0) {
        //观看超过30分钟
        [HNHttpRequest watchTimeWithidSuccess:^(id responseObject) {
            
            if (time==HNwatchNum*2) {
                [[NSUserDefaults standardUserDefaults] setObject:@"0" forKey:@"HNWatch_Time"];
                [UserDefault synchronize];
            }
        } failure:^(NSError *error) {
            
        }];
    }
}
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    [self setUI];
    
    
    // 初始化视图居中
    [self childViewReloadDataWithVC:live2];
    self.mainScrollView.contentOffset = CGPointMake(0, SCREEN_HEIGHT);
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(back:) name:@"popViewController" object:nil];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(liveMessageShowOrHidden:) name:@"liveMessageShowOrHidden" object:nil];
    
    if (self.roomsArray.count == 1)
    {
        self.mainScrollView.scrollEnabled = NO;
    }
//    [HNHttpRequest userCancelFlowWithSuccess:^(id responseObject) {
//
//    } failure:^(NSError *error) {
//
//    }];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - UINavigationControllerDelegate

- (void)navigationController:(UINavigationController *)navigationController willShowViewController:(UIViewController *)viewController animated:(BOOL)animated
{
    BOOL isShow = [viewController isKindOfClass:[self class]];
    [navigationController setNavigationBarHidden:isShow animated:YES];
}

#pragma mark - privateMethod

- (void)back:(NSNotification *)notifi
{
    if (notifi.object == nil)
    {
         [self.navigationController popViewControllerAnimated:YES];
    }
    else
    {
        // 主播结束直播
        HNLiveListModel *model = self.roomsArray[self.currentIndex];
        
        HNUserLiveEndVC *vc = [[HNUserLiveEndVC alloc] init];
        vc.uid = model.uid;
        [self.navigationController pushViewController:vc animated:YES];
    }
   
}

// 子视图的消息界面出来或者消失
- (void)liveMessageShowOrHidden:(NSNotification *)notifi
{
    NSString *isShow = notifi.object;
    if ([isShow isEqualToString:@"Show"])
    {
        self.mainScrollView.scrollEnabled = NO;
    }
    else
    {
        if (self.roomsArray.count == 1)
        {
            self.mainScrollView.scrollEnabled = NO;
        }
        else
        {
            self.mainScrollView.scrollEnabled = YES;
        }
        
    }
}

- (void)childViewReloadDataWithVC:(HNUserLiveVC *)vc
{
    HNLiveListModel *listModel = self.roomsArray[self.currentIndex];
    
    vc.down_url = listModel.down_url;
    
    HNLiveAnchorModel *anchorModel = [[HNLiveAnchorModel alloc] init];
    anchorModel.avatar = listModel.avatar;
    anchorModel.uid = listModel.uid;
    anchorModel.nick = listModel.nick;
    vc.anchorModel = anchorModel;
    
    vc.pullBgImage = listModel.live_logo ? listModel.live_logo : listModel.avatar;
    
    [vc startLoadData];
}

//滚到上一个
- (void)allControllerMoveDown:(CGFloat)height {
    
    _currentIndex--;
    if (_currentIndex < 0)
    {
        _currentIndex = _roomsArray.count - 1;
    }
    DLog(@"_currentIndex -%ld", (long)_currentIndex);
     [live2 cancelApply];
    [self childViewReloadDataWithVC:live1];
   
    HNUserLiveVC *live = live3;
    [live2 exitRoom];
    live3 = live2;
    live2 = live1;
    live1 = live;
    
    [self setSubViewFrame];
}

//滚到下一个
- (void)allControllerMoveUp:(CGFloat)height
{
    _currentIndex++;
    if (_currentIndex == _roomsArray.count)
    {
        _currentIndex = 0;
    }
    DLog(@"_currentIndex -%ld", (long)_currentIndex);
    
    
   [live2 cancelApply];
    [self childViewReloadDataWithVC:live3];
 
    HNUserLiveVC *live = live1;
    [live2 exitRoom];
    live1 = live2;
    live2 = live3;
    live3 = live;
    
    [self setSubViewFrame];
}

#pragma mark - UIScrollViewDelegate

- (void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    CGPoint currentOffset = scrollView.contentOffset;
    NSInteger index = 1;
    
    if ( currentOffset.y > SCREEN_HEIGHT)
    {
        index = _currentIndex + 1;
        if (index >= self.roomsArray.count)
        {
            index = 0;
        }
        
        HNLiveListModel *model = self.roomsArray[index];
        live3.pullBgImage = model.live_logo ? model.live_logo : model.avatar;
    }
    else if ( currentOffset.y < SCREEN_HEIGHT)
    {
        index = _currentIndex - 1;
        if (index < 0)
        {
            index = _roomsArray.count - 1;
        }
        
        HNLiveListModel *model = self.roomsArray[index];
        live1.pullBgImage = model.live_logo ? model.live_logo : model.avatar;
    }
}

- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView
{
    CGFloat pageHeight = scrollView.frame.size.height;
  
    int page = floor((scrollView.contentOffset.y - pageHeight / 2) / pageHeight) + 1;
    if(page == 1)
    {
        //用户拖动了，但是滚动事件没有生效
        return;
    }
    else if (page == 0)
    {
        [self allControllerMoveDown:pageHeight];
    }
    else
    {
        [self allControllerMoveUp:pageHeight];
    }
    
    CGPoint p = CGPointZero;
    p.y = pageHeight;
    [scrollView setContentOffset:p animated:NO];
    
}

#pragma mark - setUI

- (void)setUI
{
    [self.view addSubview:self.mainScrollView];
    
    CGRect frame = self.view.frame;
    frame.origin.y = 0.0f;
    
    NSInteger live2Index = _currentIndex;
    NSInteger live1Index = live2Index - 1;
    NSInteger live3Index = live2Index + 1;

    live1Index = live1Index < 0 ? self.roomsArray.count - 1 : live1Index;
    live1Index = live1Index >= self.roomsArray.count ? 0 : live1Index;
    
    live3Index = live3Index < 0 ? self.roomsArray.count - 1 : live3Index;
    live3Index = live3Index >= self.roomsArray.count ? 0 : live3Index;
    
    live1 = [[HNUserLiveVC alloc] init];
    live2 = [[HNUserLiveVC alloc] init];
    live3 = [[HNUserLiveVC alloc] init];
    _weakself;
    live1.prohibitSlideBlcok = ^(BOOL isProhibit) {
        _strongSelf;
        strongSelf.mainScrollView.scrollEnabled = isProhibit;
    };
    live2.prohibitSlideBlcok = ^(BOOL isProhibit) {
        _strongSelf;
        strongSelf.mainScrollView.scrollEnabled = isProhibit;
    };
    live3.prohibitSlideBlcok = ^(BOOL isProhibit) {
        _strongSelf;
        strongSelf.mainScrollView.scrollEnabled = isProhibit;
    };
    [self setSubViewFrame];
    
    [self addChildViewController:live1];
    [self addChildViewController:live2];
    [self addChildViewController:live3];
    [self.mainScrollView addSubview:live1.view];
    [self.mainScrollView addSubview:live2.view];
    [self.mainScrollView addSubview:live3.view];
}

- (void)setSubViewFrame
{
    CGRect frame = self.view.frame;
    [live1.view setFrame:frame];
    
    frame.origin.y += self.view.frame.size.height;
    [live2.view setFrame:frame];
    
    frame.origin.y += self.view.frame.size.height;
    [live3.view setFrame:frame];

}

#pragma mark - getter

- (UIScrollView *)mainScrollView
{
    if (!_mainScrollView)
    {
        _mainScrollView = InsertScrollView(nil, CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT), 0, self);
        _mainScrollView.contentSize = CGSizeMake(SCREEN_WIDTH, 3 * SCREEN_HEIGHT);
        _mainScrollView.backgroundColor = [UIColor clearColor];
        _mainScrollView.showsHorizontalScrollIndicator = NO;
        _mainScrollView.pagingEnabled = YES;
        _mainScrollView.bounces = YES;
    }
    return _mainScrollView;
}

@end
