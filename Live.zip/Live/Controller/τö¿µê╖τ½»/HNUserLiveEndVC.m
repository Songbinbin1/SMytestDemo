//
//  HNUserLiveEndVC.m
//  SunsetLive
//
//  Created by Sunwanwan on 2017/9/11.
//  Copyright © 2017年 HN. All rights reserved.
//

#import "HNUserLiveEndVC.h"
#import "HNHomeVC.h"
#import "HNMessageModel.h"
#import "UIImage+ColorImage.h"

@interface HNUserLiveEndVC () <UINavigationControllerDelegate>

@property (nonatomic, strong) UIImageView *bgImg;

@property (nonatomic, strong) UIView *headerBgView;
@property (nonatomic, strong) UIImageView *headerImg;
@property (nonatomic, strong) UILabel *nickLab;
@property (nonatomic, strong) UIImageView *sexImg;
@property (nonatomic, strong) UIButton *levelBtn;  // 用户等级
@property (nonatomic, strong) UIButton *liveLevelBtn;  // 主播等级

@property (nonatomic, strong) UILabel *descLab;
@property (nonatomic, strong) UIView *leftLine;
@property (nonatomic, strong) UIView *rightLine;

@property (nonatomic, strong) UIButton *followBtn;  // 关注按钮
@property (nonatomic, strong) UIButton *backBtn;  // 返回首页

@end

@implementation HNUserLiveEndVC

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
    self.navigationController.delegate = self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    [self setUI];
    
    // 获取下用户信息
    [self loadData];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - loadData

- (void)loadData
{
    NSDictionary *dic = @{
                          @"uid" : self.uid,
                           @"rid":self.uid
                          };
    
    [[HNRequestManager manager] sendRequestWithRequestMethodType:HNRequestMethodTypeGET requestAPICode:GetUserCardInfo requestParameters:dic requestHeader:@{@"authorization" : kTOKEN} success:^(id responseObject) {
        
        if (CODE != 200)
        {
            return ;
        }
        
        HNMessageModel *model = [HNMessageModel yy_modelWithJSON:responseObject[@"d"][@"user_info"]];
     
        [self.headerImg sd_setImageWithURL:[NSURL URLWithString:[HNTools pictureStr:model.avatar]] placeholderImage:DefaultHeaderImage];
        self.nickLab.text = model.nick;
        
        if ([model.gender isEqualToString:@"2"])
        {
            self.sexImg.image = GetImage(@"girl");
        }
        else if ([model.gender isEqualToString:@"1"])
        {
            self.sexImg.image = GetImage(@"nan");
        }
        
        NSString *level = [NSString stringWithFormat:@" %@",model.level];
        [self.levelBtn setTitle:level forState:UIControlStateNormal];
        [self.levelBtn setBackgroundImage:[HNTools returnBackgroundImageNameWithLevel:model.level] forState:UIControlStateNormal];
        
        if ([model.live_level integerValue] == 0)
        {
            self.liveLevelBtn.hidden = YES;
        }
        else
        {
            self.liveLevelBtn.hidden = NO;
            
            NSString *liveLevel = [NSString stringWithFormat:@"%@",model.live_level];
            [self.liveLevelBtn setTitle:liveLevel forState:UIControlStateNormal];
        }
        
        if ([model.is_follow boolValue])
        {
            self.followBtn.selected = YES;
        }
        else
        {
            self.followBtn.selected = NO;
        }
        
    } faild:^(NSError *error) {
        
    }];
}

#pragma mark - UINavigationControllerDelegate

- (void)navigationController:(UINavigationController *)navigationController willShowViewController:(UIViewController *)viewController animated:(BOOL)animated
{
    BOOL isShow = [viewController isKindOfClass:[self class]];
    [navigationController setNavigationBarHidden:isShow animated:YES];
}

#pragma mark - loadData

- (void)addOrCancelFollowWothBtnSelect:(BOOL)isSelect
{
    NSDictionary *dic;
    if (isSelect == YES)
    {
        dic = @{
                @"type" : @"add",
                @"uid" : self.uid
                };
    }
    else
    {
        dic = @{
                @"type" : @"cancel",
                @"uid" : self.uid
                };
    }
    
    [[HNRequestManager manager] sendRequestWithRequestMethodType:HNRequestMethodTypePOST requestAPICode:ChangeFollow requestParameters:dic requestHeader:@{@"authorization" : kTOKEN} success:^(id responseObject) {
        
        if (CODE != 200)
        {
            MBErrorMsg;
            return ;
        }
        
        if (isSelect == YES)
        {
            self.followBtn.selected = YES;
        }
        else
        {
            self.followBtn.selected = NO;
        }
        
    } faild:^(NSError *error) {
        ERROR;
    }];
}

#pragma mark - privateMethod

- (void)followBtnClick:(UIButton *)btn
{
    btn.selected = !btn.selected;
    
    [self addOrCancelFollowWothBtnSelect:btn.selected];
}

// 返回首页
- (void)backBtnClick
{
    DLog(@"------  %@ ------%@",self.navigationController.superclass, self.navigationController.viewControllers);
    
    if (self.navigationController == nil)
    {
        [[NSNotificationCenter defaultCenter] postNotificationName:@"popViewController" object:nil];
    }
    else
    {
        for (UIViewController *vc in self.navigationController.viewControllers)
        {
            if ([vc isKindOfClass:[HNHomeVC class]])
            {
                [self.navigationController popToViewController:vc animated:YES];
            }
        }
    }
}

#pragma mark - setUI

- (void)setUI
{
    [self.view addSubview:self.bgImg];
    [self.view addSubview:self.headerBgView];
    [self.view addSubview:self.headerImg];
    [self.view addSubview:self.nickLab];
    [self.view addSubview:self.sexImg];
    [self.view addSubview:self.levelBtn];
    [self.view addSubview:self.liveLevelBtn];
    [self.view addSubview:self.descLab];
    [self.view addSubview:self.leftLine];
    [self.view addSubview:self.rightLine];
    [self.view addSubview:self.followBtn];
    [self.view addSubview:self.backBtn];
    
    [self.bgImg mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.left.width.height.mas_equalTo(self.view);
    }];
    
    [self.headerBgView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_offset(Handle(290 / 2));
        make.centerX.mas_equalTo(self.view.mas_centerX);
        make.size.mas_equalTo(CGSizeMake(Handle_width(152 / 2), Handle_height(152 / 2)));
    }];
    
    [self.headerImg mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.centerY.mas_equalTo(self.headerBgView);
        make.size.mas_equalTo(CGSizeMake(Handle_width(150 / 2), Handle_height(150 / 2)));
    }];
    
    [self.nickLab mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.mas_equalTo(self.headerBgView.mas_centerX);
        make.top.mas_equalTo(self.headerBgView.mas_bottom).mas_offset(Handle(10));
    }];
    
    [self.sexImg mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(self.nickLab.mas_right).mas_offset(Handle(10));
        make.centerY.mas_equalTo(self.nickLab.mas_centerY);
    }];
    
    [self.levelBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.mas_equalTo(self.sexImg.mas_centerY);
        make.left.mas_equalTo(self.sexImg.mas_right).mas_offset(Handle(5));
        make.size.mas_equalTo(CGSizeMake(Handle_width(56 / 2), Handle_height(13)));
    }];
    
    [self.liveLevelBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.mas_equalTo(self.levelBtn.mas_centerY);
        make.left.mas_equalTo(self.levelBtn.mas_right).mas_offset(Handle(5));
    }];
    
    [self.descLab mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.mas_equalTo(self.view.mas_centerX);
        make.top.mas_equalTo(self.nickLab.mas_bottom).mas_offset(Handle(90));
    }];
    
    [self.leftLine mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.mas_equalTo(self.descLab.mas_left).mas_offset(-Handle(20));
        make.centerY.mas_equalTo(self.descLab.mas_centerY);
        make.height.mas_offset(Handle(0.5));
        make.width.mas_offset(72);
    }];
    
    [self.rightLine mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(self.descLab.mas_right).mas_offset(Handle(20));
        make.centerY.mas_equalTo(self.descLab.mas_centerY);
        make.height.mas_offset(Handle(0.5));
        make.width.mas_offset(72);
    }];
    
    [self.followBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.mas_equalTo(self.view.mas_centerX);
        make.top.mas_equalTo(self.descLab.mas_bottom).mas_offset(Handle(60));
        make.width.mas_offset(Handle_width(550 / 2));
        make.height.mas_offset(Handle_height(78 / 2));
    }];
    
    [self.backBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(self.followBtn.mas_bottom).mas_offset(Handle(30));
        make.centerX.mas_equalTo(self.view.mas_centerX);
        make.width.mas_offset(Handle_width(550 / 2));
        make.height.mas_offset(Handle_height(78 / 2));
    }];
}

#pragma mark - getter

- (UIImageView *)bgImg
{
    if(!_bgImg)
    {
        _bgImg = InsertImageView(nil, CGRectZero, GetImage(@"bg_liveover"));
    }
    return _bgImg;
}

- (UIView *)headerBgView
{
    if(!_headerBgView)
    {
        _headerBgView = InsertView(nil, CGRectZero, [UIColor whiteColor]);
        _headerBgView.layer.cornerRadius = Handle_width(152 / 4);
        _headerBgView.layer.masksToBounds = YES;
    }
    return _headerBgView;
}

- (UIImageView *)headerImg
{
    if(!_headerImg)
    {
        _headerImg = InsertImageView(nil, CGRectZero, DefaultHeaderImage);
        _headerImg.contentMode = UIViewContentModeScaleAspectFill;
        _headerImg.clipsToBounds = YES;
        _headerImg.layer.cornerRadius = Handle_width(150 / 4);
        _headerImg.layer.masksToBounds = YES;
    }
    return _headerImg;
}

- (UILabel *)nickLab
{
    if(!_nickLab)
    {
        _nickLab = InsertLabel(nil, CGRectZero, NSTextAlignmentRight, @"", SystemFontSize14, [UIColor whiteColor]);
    }
    return _nickLab;
}

- (UIImageView *)sexImg
{
    if(!_sexImg)
    {
        _sexImg = InsertImageView(nil, CGRectZero, GetImage(@""));
    }
    return _sexImg;
}

- (UIButton *)levelBtn
{
    if(!_levelBtn)
    {
        _levelBtn = InsertTitleAndImageButton(nil, CGRectZero, 88, @"", UIEdgeInsetsZero, SystemFontSize10, [UIColor whiteColor], nil, nil, nil, self, nil);
        [_levelBtn setImage:GetImage(@"start_level") forState:UIControlStateNormal];
        [_levelBtn setBackgroundImage:GetImage(@"level_user_bg") forState:UIControlStateNormal];
        _levelBtn.layer.cornerRadius = Handle(2);
        _levelBtn.layer.masksToBounds = YES;
        _levelBtn.imageEdgeInsets = UIEdgeInsetsMake(0, 0, 0, _levelBtn.right - _levelBtn.titleLabel.width - 3);
    }
    return _levelBtn;
}

- (UIButton *)liveLevelBtn
{
    if(!_liveLevelBtn)
    {
        _liveLevelBtn = InsertTitleAndImageButton(nil, CGRectZero, 99, @"", UIEdgeInsetsZero, SystemFontSize10, [UIColor whiteColor], nil, nil, nil, self, nil);
        [_liveLevelBtn setImage:GetImage(@"start_level") forState:UIControlStateNormal];
        [_liveLevelBtn setBackgroundImage:GetImage(@"level_bg") forState:UIControlStateNormal];
        _liveLevelBtn.layer.cornerRadius = Handle(2);
        _liveLevelBtn.layer.masksToBounds = YES;
        _liveLevelBtn.titleEdgeInsets = UIEdgeInsetsMake(0, Handle(5), 0, 0);
    }
    return _liveLevelBtn;
}

- (UILabel *)descLab
{
    if(!_descLab)
    {
        _descLab = InsertLabel(nil, CGRectZero, NSTextAlignmentCenter, @"直播已结束", SystemFontSize17, [UIColor whiteColor]);
    }
    return _descLab;
}

- (UIView *)leftLine
{
    if(!_leftLine)
    {
        _leftLine = InsertView(nil, CGRectZero, UIColorFromHEXA(0xDEE1EB, 0.3));
    }
    return _leftLine;
}

- (UIView *)rightLine
{
    if(!_rightLine)
    {
        _rightLine = InsertView(nil, CGRectZero, UIColorFromHEXA(0xDEE1EB, 0.3));
    }
    return _rightLine;
}

- (UIButton *)followBtn
{
    if(!_followBtn)
    {
        _followBtn = InsertTitleAndImageButton(nil, CGRectZero, 777, @"", UIEdgeInsetsZero, SystemFontSize17, [UIColor whiteColor], nil, nil, nil, self, @selector(followBtnClick:));
        [_followBtn setTitle:@"关注主播" forState:UIControlStateNormal];
        [_followBtn setTitle:@"已关注" forState:UIControlStateSelected];
        [_followBtn setBackgroundImage:[UIImage imageWithCustomColor:UIColorFromHEXA(0xC5C5C5, 1.0)] forState:UIControlStateSelected];
        [_followBtn setBackgroundImage:GetImage(@"btn") forState:UIControlStateNormal];
        
        _followBtn.selected = NO;
        
        _followBtn.layer.cornerRadius = Handle(78 / 4);
        _followBtn.layer.masksToBounds = YES;
    }
    return _followBtn;
}

- (UIButton *)backBtn
{
    if(!_backBtn)
    {
        _backBtn = InsertTitleAndImageButton(nil, CGRectZero, 888, @"返回首页", UIEdgeInsetsZero, SystemFontSize17, [UIColor whiteColor], nil, nil, nil, self, @selector(backBtnClick));
        _backBtn.layer.borderColor = [UIColor whiteColor].CGColor;
        _backBtn.layer.borderWidth = Handle(1);
        _backBtn.layer.cornerRadius = Handle(78 / 4);
        _backBtn.layer.masksToBounds = YES;
        _backBtn.backgroundColor = [UIColor clearColor];
    }
    return _backBtn;
}

@end
