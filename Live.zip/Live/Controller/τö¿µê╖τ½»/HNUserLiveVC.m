//
//  HNUserLiveVC.m
//  SunsetLive
//
//  Created by Sunwanwan on 2017/9/11.
//  Copyright © 2017年 HN. All rights reserved.
//

#import "HNUserLiveVC.h"
#import "HNTXLivePlayerView.h"
#import "HNLiveAnchorUserInfoView.h"
#import "HNLiveChatTable.h"
#import "HNUserLiveEndVC.h"
#import "HNUserLiveInfoModel.h"
#import <SRWebSocket.h>
#import "HNMyAccountVC.h"
#import "HNGiftListView.h"
#import "HNAnimationManager.h"
#import "HNUserInfoCardView.h"
#import "HNLiveSeeUserCollectionCell.h"
#import "DMHeartFlyView.h"
#import "HNLiveChatToolsView.h"
#import "HNLiveMessageVC.h"
#import "UIButton+HNAddBadge.h"
#import "HNBigGiftView.h"
#import "HNFlyManger.h"
#import "HNLiveChatMessageVC.h"
#import "HNHomeVC.h"
#import "HNDownloadManager.h"
#import "ZipArchive.h"
#import "HNWebVC.h"
#import "HNCountdownView.h"
#import "HNFansContributionListVC.h"
#import "HNAESSecurity.h"
#import "HNPersonalHomeHageVC.h"
#import "HNPersonalHomeHageVC.h"
#import "MLTransition.h"
#import "NSString+HNFilter.h"
#import "HNShareModel.h"
#import "HNShareView.h"
#import "HNTXLivePushView.h"
#import "HNHeadsetView.h"
#import "HNHttpRequest.h"
#import "JXButton.h"
#define balanceNoSufficienTtitle [NSString stringWithFormat:@"您的%@不足，请兑换",kCoinName]

@interface HNUserLiveVC () <UIScrollViewDelegate, UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout, SRWebSocketDelegate, HNGiftListViewDelegate, HNLiveAnchorUserInfoViewDelegate, HNUserInfoCardViewDelegate, HNLiveChatToolsDelegate, HNBigGiftViewDelegate, UIGestureRecognizerDelegate, HNLiveChatTableDelegate, UINavigationControllerDelegate>

// -------------- 界面UI  --------------

@property (nonatomic, strong) UIScrollView *scrollerView;
@property (nonatomic, strong) UIImageView *pullBgImageView;
@property (nonatomic, strong) HNTXLivePlayerView *pullFlowView;  // 拉流视图

//@property (nonatomic, strong) HNTXLivePlayerView *pullFlowView1;  // 连麦1
//@property (nonatomic, strong) HNTXLivePlayerView *pullFlowView2;  // 连麦2
@property (nonatomic, strong) HNTXLivePushView *streamView;  // 推流时图

@property (nonatomic, strong)HNHeadsetView *headsetView;
@property (nonatomic, strong) UIView *oneBgView;
@property (nonatomic, strong) HNLiveAnchorUserInfoView *userInfoView; // 主播信息视图
@property (nonatomic, strong) UICollectionView *lookUserCollection;  // 观看用户区域
@property (nonatomic, strong) HNLiveChatTable *liveChatTable;  // 聊天视图

@property (nonatomic, strong) UIImageView *effectImg; // 用来遮挡的毛玻璃

@property (nonatomic, strong) UIButton *commentBtn; // 评论按钮
@property (nonatomic, strong) UIButton *privateMsgBtn; // 私信按钮
@property (nonatomic, strong) UIButton *giftBtn;  // 礼物按钮
@property (nonatomic, strong) UIButton *exitLiveBtn;  // 退出按钮
@property (nonatomic, strong) UIButton *buyBtn;  // 按钮
@property (nonatomic, strong) UIButton *shareBtn;

@property (nonatomic, strong) JXButton *connectBtn;
@property (nonatomic, strong) HNLiveChatToolsView *chatToolsView; // 公聊工具栏

@property (nonatomic, strong) HNLiveMessageVC *privateMessageVC;  // 私聊视图

@property (nonatomic, strong) HNGiftListView *giftListView;  // 礼物列表
@property (nonatomic, strong) HNBigGiftView *bigGiftView;  // 大礼物动画视图

@property (nonatomic, strong) HNUserInfoCardView *infoCardView;

@property (nonatomic, strong) HNUserLiveEndVC *liveEndVC;  // 直播结束

@property (nonatomic, strong) HNCountdownView *countDownView;  // 倒计时视图

@property (nonatomic, strong) HNLiveMessageVC      *liveMessageVC;// 私信列表

// -----------  数据信息 ---------------

@property (nonatomic, strong) NSMutableArray *bottomBtnArr;  // 底部按钮视图数组

@property (nonatomic, strong) NSArray *tempRobotArr;
@property (nonatomic, strong) NSMutableArray *lookUserArr;
@property (nonatomic, strong) NSMutableArray *chatListArr;

@property (nonatomic, strong) NSMutableArray<HNLiveAnchorModel *> *congUserIdArr;
@property (nonatomic, strong) HNUserLiveInfoModel *infoModel;  // 房间信息

@property (nonatomic, strong) NSString *userCoin;  // 用户余额
@property (nonatomic, strong) NSString *userLevel;  // 用户等级
@property (nonatomic, strong) NSString *is_field_control; // 是否是场控
@property (nonatomic, strong) NSString *is_inspector;  // 是否是巡官

@property (nonatomic, strong) NSString *notify;   // 房间websocket地址

@property (nonatomic, strong) NSTimer *freeTimer;  // 免费时长定时器
@property (nonatomic, assign) int freeTime;

@property (nonatomic, strong) NSTimer *timer;  // 每分钟扣钱的定时器
@property (nonatomic, assign) int time;

@property (nonatomic, strong) NSMutableArray *giftListArr;  // 礼物列表
@property (nonatomic, strong) NSMutableArray *bigGiftImageArr;  // 大礼物动画数组
@property (nonatomic, strong) NSMutableArray *giftImageArr;  // 动画列表

@property (nonatomic, assign) BOOL isParse;

@property (nonatomic, strong) NSString *recharge_type;  // 当前兑换类型 
@property (nonatomic, strong) NSString *oldLiveType;


@property (nonatomic, strong) HNLiveChatMsgModel *currentSendGiftMsgModel;  // 当前送礼的聊天模型（只用于当一个用户发送的礼物不在当前礼物列表里时）
//@property (nonatomic, strong) HNLiveChatMsgModel *continueSendGiftMsgModel;  // 收到礼物正在做动画时候，又收到了礼物
//@property (nonatomic, assign) NSInteger continueShowBigGiftCount;   // 继续播放大礼物动画的次数

@property (nonatomic, assign) NSInteger playerPlyingSuccessCount;   // 拉流成功的次数
@property (nonatomic, assign) BOOL isChangeLocalGiftArr;  // 本地的礼物列表是否有了更改， 包括礼物下架， 礼物上线等

@property (nonatomic, assign) NSInteger connectState;// 0 没申请连麦 1申请中 2连接中

// ------------------ webSocket -------------

@property (nonatomic, strong) SRWebSocket *socket;
@property (nonatomic, assign) float connectTime;


@end

@implementation HNUserLiveVC

- (void)dealloc
{
    [[UIApplication sharedApplication] setIdleTimerDisabled:NO];
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
  
    // 直播间出现键盘的时候不需要页面向上滚动
    IQKeyboardManager *manager = [IQKeyboardManager sharedManager];
    manager.enable = NO;
    manager.enableAutoToolbar = NO;
    
    self.automaticallyAdjustsScrollViewInsets = NO;
    
    if (self.liveEndVC.superclass)
    {
        [self.liveEndVC removeFromParentViewController];
        [self.liveEndVC.view removeFromSuperview];
    }
    [self.pullFlowView resumePlay ];
//    [[NSUserDefaults standardUserDefaults] setObject:@"0" forKey:@"HNWatch_Time"];
   
}


- (void)viewDidAppear:(BOOL)animated
{
     [super viewDidAppear:animated];
     self.navigationController.delegate = self;
    [self.navigationController setNavigationBarHidden:YES animated:NO];
}
- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    
    if (self.liveEndVC.superclass)
    {
        [self.liveEndVC removeFromParentViewController];
        [self.liveEndVC.view removeFromSuperview];
    }
 
      [ self.pullFlowView pausePlay ];
   
}


- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
     [[UIApplication sharedApplication] setIdleTimerDisabled:YES];
    self.view.disableMLTransition=YES;
    self.connectState = 0;
    if (self.isFollowLive == YES)
    {
       [self startLoadData];
    }

    // 获取下礼物列表
    NSData *gidtData = [[UserDefault objectForKey:@"giftList"] copy];
    NSArray *array = [[NSKeyedUnarchiver unarchiveObjectWithData:gidtData] copy];
    
    NSMutableArray *attarray = [NSMutableArray arrayWithArray:array];
    for (HNGiftListModel *model in array)
    {
        // 只显示上架的礼物
        if ([model.status integerValue] != 1)
        {
            [attarray removeObject:model];
        }
    }

    self.giftListArr = attarray;
    
    self.isParse = NO;
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(sendData) name:@"socketsendDataHeat" object:nil];
   

}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - UINavigationControllerDelegate

- (void)navigationController:(UINavigationController *)navigationController willShowViewController:(UIViewController *)viewController animated:(BOOL)animated
{
//    BOOL isShow = [viewController isKindOfClass:[self class]];
    [navigationController setNavigationBarHidden:YES animated:NO];
}


#pragma mark -  开始播放

- (void)setPullBgImage:(NSString *)pullBgImage
{
    _pullBgImage = pullBgImage;
    
    [self.view addSubview:self.pullBgImageView];
    [self.pullBgImageView sd_setImageWithURL:[NSURL URLWithString:[HNTools pictureStr:pullBgImage]]];
}

- (void)startLoadData
{
    // 创建UI
    [self setUI];

    // 添加通知
    [self addNSNotification];

    [self startPLay];
    
    // 进入直播间的时候， 要先处理下有没有未读消息的
    NSString *unreadCount = [UserDefault objectForKey:UnreadMessageCount];
    if ([unreadCount integerValue] > 0)
    {
        [self.privateMsgBtn showBadge];
    }
    
    // 可能有时候会出现按钮被隐藏然后切换直播间的情况， 所以在开始加载数据的时候， 必须保证此时界面上的按钮是显示的
    for (UIButton *button in self.bottomBtnArr)
    {
        button.hidden = NO;
    }
}

- (void)startPLay
{
    // 开始拉流
    self.pullFlowView.rtmpURL =self.down_url;//@"rtmp://21764.liveplay.myqcloud.com/live/21764_fbb0ff5917";// //[HNAESSecurity AES128Decrypt:self.down_url];
    if (self.down_url) {
         [self.pullFlowView startPlay];
    }
    
    self.userInfoView.model = self.anchorModel;
    
    // 设置网速显示
    _weakself;
    self.pullFlowView.netStatusBlock = ^(NSString *spd) {
        weakself.userInfoView.networkKBS = spd;
    };
    
    // 进入房间
    [self enterRoom];
    
    // 设置遮挡视图
    [self.effectImg sd_setImageWithURL:[NSURL URLWithString:[HNTools pictureStr:self.anchorModel.avatar]] placeholderImage:nil];
}

//-(void)addConnectView:(NSString *)down_url{
//    if (_pullFlowView1) {
//        if (_pullFlowView2) {
//            DLog(@"连麦已满");
//        }else{
//            self.pullFlowView2.rtmpURL =down_url;
//            [self.pullFlowView2 startPlay];
//        }
//
//    }else{
//        self.pullFlowView1.rtmpURL =down_url;
//        [self.pullFlowView1 startPlay];
//    }
//}
#pragma mark - 进入直播间
- (void)enterRoom
{
    _weakself;
    NSDictionary *dic = @{
                          @"uid" : self.anchorModel.uid
                          };
    [[HNRequestManager manager] sendRequestWithRequestMethodType:HNRequestMethodTypeGET requestAPICode:EnterRoom requestParameters:dic requestHeader:@{@"authorization" : kTOKEN} success:^(id responseObject) {
        _strongSelf;
        if (CODE != 200)
        {
            if (CODE == 201)
            {
                [strongSelf exitRoom];
                
                // 主播暂时不在家
                HNUserLiveEndVC *vc = [[HNUserLiveEndVC alloc] init];
                vc.uid = strongSelf.anchorModel.uid;
                [strongSelf addChildViewController:vc];
                [strongSelf.view addSubview:vc.view];
                
                strongSelf.liveEndVC = vc;
            }
            else
            {
                MBErrorMsg;
                
//                [self exitRoom];
            }
           
            
            return ;
        }
        
        HNLiveAnchorModel *anchorModel = [HNLiveAnchorModel yy_modelWithJSON:responseObject[@"d"][@"anchor"]];
        strongSelf.anchorModel = anchorModel;
        strongSelf.userInfoView.model = strongSelf.anchorModel;
        
        HNUserLiveInfoModel *infoModel = [HNUserLiveInfoModel yy_modelWithJSON:responseObject[@"d"][@"live"]];
        strongSelf.infoModel = infoModel;
        if (!strongSelf.down_url) {
            strongSelf.down_url=infoModel.down_url;
            strongSelf.pullFlowView.rtmpURL =strongSelf.down_url;
             [strongSelf.pullFlowView startPlay];
        }
        strongSelf.userCoin = responseObject[@"d"][@"user"][@"coin"];
        strongSelf.userLevel = responseObject[@"d"][@"user"][@"level"];
        strongSelf.is_field_control = responseObject[@"d"][@"user"][@"is_field_control"];
        strongSelf.is_inspector = responseObject[@"d"][@"user"][@"is_inspector"];
        
        
        strongSelf.notify = responseObject[@"d"][@"notify"];
        
        strongSelf.userInfoView.onlines = [NSString stringWithFormat:@"%@",responseObject[@"d"][@"liveonlines"]];
        strongSelf.recharge_type = responseObject[@"d"][@"recharge_type"];
        // 处理机器人  在线人数/观看人数/系统公告
//        @synchronized (self)
//        {
        
            NSArray *robotArray = [NSArray yy_modelArrayWithClass:[HNLiveUserModel class] json:responseObject[@"d"][@"robotData"]];
            NSArray *roomArray = [NSArray yy_modelArrayWithClass:[HNLiveUserModel class] json:responseObject[@"d"][@"roomData"]];
            NSSortDescriptor *sortDescriptor = [NSSortDescriptor sortDescriptorWithKey:@"level" ascending:YES];
        
            NSArray *tempArray = [roomArray sortedArrayUsingDescriptors:[NSArray arrayWithObject:sortDescriptor]];

            strongSelf.tempRobotArr = robotArray;
            if (roomArray.count > 0)
            {
                [strongSelf.lookUserArr addObjectsFromArray:tempArray];
            }
            if (strongSelf.tempRobotArr.count > 0)
            {
                [strongSelf.lookUserArr addObjectsFromArray:self.tempRobotArr];
            }
           [strongSelf reloadUserCollection];
            NSString *notice = responseObject[@"d"][@"notice"];
            
            if (![HNTools dx_isNullOrNilWithObject:notice] && notice.length > 0)
            {
                HNLiveChatMsgModel *noticeMsgModel = [[HNLiveChatMsgModel alloc] init];
                noticeMsgModel.msg_content = [NSString stringWithFormat:@"系统公告：%@",notice];
                
                [strongSelf insertChatTableWithModel:noticeMsgModel];
            }
//        }
        
        // 连接webSocket
        [strongSelf reconnect];
        
    } faild:^(NSError *error) {
        ERROR;
    }];
}

#pragma mark ------------------ 计时处理



#pragma mark ------------------ websocket

- (void)reconnect
{
    // 先断开连接再重新连接
    if (!self.notify) {
        return;
    }
    self.socket.delegate = nil;
   [self.socket close];
    self.socket = [[SRWebSocket alloc] initWithURLRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:self.notify]]];
    self.socket.delegate = self;
    [self.socket open];
}

- (void)webSocket:(SRWebSocket *)webSocket didReceiveMessage:(id)message
{
    NSDictionary *messageDict = [HNTools dictionaryWithJsonString:message];
    DLog(@"----websocketMsg:--  %@",messageDict);
    
    // 在线人数
    if (Type(@"onlines"))
    {
        // 刚进入直播间会收到两个webSocket的推送， 所以这里只处理观看人区域
        NSArray *array = [NSArray yy_modelArrayWithClass:[HNLiveUserModel class] json:messageDict[@"data"]];
        self.lookUserArr = [NSMutableArray arrayWithArray:array];
        
        // 再加上机器人的数量
        if (self.tempRobotArr.count > 0)
        {
            [self.lookUserArr addObjectsFromArray:self.tempRobotArr];
//            for (HNLiveUserModel *model in self.tempRobotArr) {
//                [self insertLookUserWithModel:model];
//            }
        }
        
        
        // 用户端也减去直播自己
        NSMutableArray *attArr = [NSMutableArray arrayWithArray:self.lookUserArr];
        
        for (HNUserModel *model in self.lookUserArr)
        {
            if ([model.uid isEqualToString:self.anchorModel.uid])
            {
                [attArr removeObject:model];
                
                break;
            }
        }
        
        self.userInfoView.onlines = [NSString stringWithFormat:@"%ld",(unsigned long)attArr.count];
        if(attArr.count>50){
            attArr=[NSMutableArray arrayWithArray:[attArr subarrayWithRange:NSMakeRange(0, 50)]];
        }
        self.lookUserArr = attArr;
        [self reloadUserCollection];
    }
    
    // 进入直播间
    if (Type(@"join"))
    {
        
        // 观看人数区域处理
        NSString *avatar=[messageDict valueForKeyPath:@"data.fuser.avatar"];
        if([avatar  isKindOfClass:[NSNull class]]){
            avatar=@"isBlankString";
        }
        [UserDefault setObject:avatar forKey:@"myAvatar"];
        
        HNLiveUserModel *model = [HNLiveUserModel yy_modelWithJSON:messageDict[@"data"][@"fuser"]];
        if ([model.uid isEqualToString:self.anchorModel.uid])
        {
            return;
        }
        
        [self insertLookUserWithModel:model type:@"user"];
        
        self.userInfoView.onlines = [NSString stringWithFormat:@"%ld",[self.userInfoView.onlines integerValue]+1];
        
        // 聊天区域处理
        HNLiveChatMsgModel *msgModel = [HNLiveChatMsgModel yy_modelWithJSON:messageDict[@"data"][@"fuser"]];
        msgModel.msgType = TipsMsgType;
        msgModel.msg_content = @"入场了";
        [self insertChatTableWithModel:msgModel];
    }
    
    // 机器人进入直播间
    if (Type(@"robot_join"))
    {
        NSInteger onlines = [self.userInfoView.onlines integerValue];
        onlines = onlines + 1;
        self.userInfoView.onlines = [NSString stringWithFormat:@"%ld",(long)onlines];
        
        // 观看人数区域处理
        HNLiveUserModel *model = [HNLiveUserModel yy_modelWithJSON:messageDict[@"data"][@"robot"]];
        [self insertLookUserWithModel:model type:@"robot"];
        
        // 聊天区域处理
        HNLiveChatMsgModel *msgModel = [HNLiveChatMsgModel yy_modelWithJSON:messageDict[@"data"][@"robot"]];
        msgModel.msg_content = @"入场了";
        msgModel.msgType = TipsMsgType;
        [self insertChatTableWithModel:msgModel];
    }
    
    // 公聊
    if (Type(@"public_msg"))
    {
        NSDictionary *userDic = messageDict[@"data"][@"user_info"];
        HNLiveChatMsgModel *msgModel = [HNLiveChatMsgModel yy_modelWithDictionary:userDic];
        msgModel.msg_content = messageDict[@"data"][@"content"][@"word"];
         [self insertChatTableWithModel:msgModel];
       
//        [self.chatListArr addObject:msgModel];
//
//        [self chatTableScrollToBottom];
    }
    
    // 弹幕
    if (Type(@"barrage"))
    {
        NSDictionary *userDic = messageDict[@"data"][@"user_info"];
        HNLiveChatMsgModel *msgModel = [HNLiveChatMsgModel yy_modelWithDictionary:userDic];
        msgModel.msg_content = messageDict[@"data"][@"content"][@"word"];
        
        // 飘屏
        [[HNFlyManger sharedManger] mangerShowWithModel:msgModel parentView:self.oneBgView];
    }
    
    // 送礼
    if (Type(@"send_gift"))
    {
        // 主播获得优币处理
        self.userInfoView.exceptionalMoney = messageDict[@"data"][@"gift"][@"total_dot"];
        
        // 礼物动画处理
        NSDictionary *userDic = messageDict[@"data"][@"user_info"];
        HNLiveChatMsgModel *msgModel = [HNLiveChatMsgModel yy_modelWithDictionary:userDic];
        msgModel.g_num = @"1";
        msgModel.msgType = GiftMsgType;
        NSString *giftId = messageDict[@"data"][@"gift"][@"id"];
        BOOL localIsHavegift = NO;
        
        for (HNGiftListModel *model in self.giftListArr)
        {
            if ([giftId isEqualToString:model.giftId])
            {
                msgModel.g_name = model.name;
                msgModel.g_icon = model.icon;
                msgModel.g_id = model.giftId;
                
                localIsHavegift = YES;
                
                break;
            }
        }
        
        // 礼物处理
        if (localIsHavegift == NO)
        {
            // 说明本地没有这个礼物，则要从服务器去获取单个礼物的信息
            self.currentSendGiftMsgModel = msgModel;
            [self requestOneGiftWithGiftId:giftId chatMsgModel:msgModel];
        }
        else
        {
            
            HNAnimationManager *manger = [HNAnimationManager sharedAnimationManager];
            manger.superView = self.oneBgView;
            [manger animaWithMsgModel:msgModel finishedBlock:^(BOOL result, NSInteger finishCount) {
                
                // 聊天区域处理
                msgModel.msg_content = [NSString stringWithFormat:@"赠送了%ld个%@",(long)finishCount,msgModel.g_name];
                
                [self insertChatTableWithModel:msgModel];
                //                    [self.chatListArr addObject:msgModel];
                //                    [self chatTableScrollToBottom];
            }];
            NSString *giftKey = [NSString stringWithFormat:@"%@_%@",msgModel.g_id,msgModel.g_name];
//
            if ([[HNTools BigGiftNameArray] containsObject:giftKey])
            {
//                // 说明赠送的是大礼物
                [self.giftImageArr addObject:msgModel];
               
                if (!self.currentSendGiftMsgModel) {
                     [self continueReplaceShowBigGiftView];
                }
            }

        }
    }
    
    // 离开直播间
    if (Type(@"leave"))
    {
        HNLiveUserModel *model = [HNLiveUserModel yy_modelWithJSON:messageDict[@"data"][@"fuser"]];
        NSMutableArray *tempArr = self.lookUserArr;
        for (HNLiveUserModel *allModel in self.lookUserArr)
        {
            if ([model.uid isEqualToString:allModel.uid])
            {
                [tempArr removeObject:allModel];
                
                break;
            }
        }
        
        self.lookUserArr = tempArr;
        
        [self reloadUserCollection];
        
        self.userInfoView.onlines = [NSString stringWithFormat:@"%ld",[self.userInfoView.onlines integerValue]-1];
    }
    
    // 机器人离开直播间
    if (Type(@"robot_leave"))
    {
        HNLiveUserModel *model = [HNLiveUserModel yy_modelWithJSON:messageDict[@"data"][@"robot"]];
        NSMutableArray *tempArr = self.lookUserArr;
        for (HNLiveUserModel *allModel in self.lookUserArr)
        {
            if ([model.uid isEqualToString:allModel.uid])
            {
                [tempArr removeObject:allModel];
                
                break;
            }
        }
        
        self.lookUserArr = tempArr;
        
        [self reloadUserCollection];
        
        self.userInfoView.onlines = [NSString stringWithFormat:@"%ld",[self.userInfoView.onlines integerValue]-1];
    }

    // 主播结束直播
    if (Type(@"stop_live"))
    {
        // 这里也要区分下是不是直接从开播提醒的弹框过来的
        if (self.isFollowLive == YES)
        {
            [self.navigationController popViewControllerAnimated:YES];
            
            [self exitRoom];
        }
        else
        {
            [self exitRoom];
            
            [[NSNotificationCenter defaultCenter] postNotificationName:@"popViewController" object:@"stop_live"];
        }
    }
    
    // 主播获得房间收入
    if (Type(@"anchor_get_room_price"))
    {
        NSString *anchorId = messageDict[@"data"][@"anchor_uid"];
        if ([self.anchorModel.uid isEqualToString:anchorId])
        {
            // 是当前这个直播间的
            self.userInfoView.exceptionalMoney = messageDict[@"data"][@"total_dot"];
        }
    }
    
    // 用户升级
    if (Type(@"level_up"))
    {
        HNLiveChatMsgModel *model = [HNLiveChatMsgModel yy_modelWithJSON:messageDict[@"data"][@"user_info"]];
         model.msgType = SystemMsgType;
        if ([model.uid isEqualToString:self.anchorModel.uid])
        {
            model.msg_content = [NSString stringWithFormat:@"系统消息： 恭喜主播等级升至%@级",model.level];
        }
        else
        {
             model.msg_content = [NSString stringWithFormat:@"系统消息： 恭喜%@等级升至%@级",model.nick,model.level];
            
            if ([model.uid isEqualToString:kUserID])
            {
                // 如果是当前用户的用户等级升级了， 则对用户等级进行一个更新处理
                self.userLevel = model.level;
            }
        }
        [self insertChatTableWithModel:model];
//        [self.chatListArr addObject:model];
//
//        [self chatTableScrollToBottom];
    }
    
    // 点赞主播
    if (Type(@"attitude"))
    {
        HNLiveChatMsgModel *model = [HNLiveChatMsgModel yy_modelWithJSON:messageDict[@"data"][@"user_info"]];
        model.msg_content = @"点赞了主播";
        model.msgType = TipsMsgType;
        [self insertChatTableWithModel:model];
//        [self.chatListArr addObject:model];
//
//        [self chatTableScrollToBottom];
        [self heartFlyViewAnimation];
    }
    
    // 设置场控
    if (Type(@"setFieldControl"))
    {
        HNLiveChatMsgModel *model = [HNLiveChatMsgModel yy_modelWithJSON:messageDict[@"data"][@"user_info"]];
        if ([model.is_field_control integerValue] == 1)
        {
            if ([model.uid isEqualToString:kUserID])
            {
                // 自己被设置为场控， 则修改当前的状态值
                self.is_field_control = @"1";
            }
            model.msgType = TipsMsgType;
            model.msg_content = @"已被设为场控";
            [self insertChatTableWithModel:model];
//            [self.chatListArr addObject:model];
//
//            [self chatTableScrollToBottom];
        }
        else
        {
            if ([model.uid isEqualToString:kUserID])
            {
                // 自己被取消场控了， 则修改当前的状态值
                self.is_field_control = @"0";
            }
        }
    }
    
    // 禁言
    if (Type(@"setBannedSay"))
    {
        HNLiveChatMsgModel *model = [HNLiveChatMsgModel yy_modelWithJSON:messageDict[@"data"][@"user_info"]];
        model.msgType = TipsMsgType;
        if ([model.is_banned_say integerValue] == 1)
        {
            model.msg_content = @"已被禁言";
        }
        else
        {
            model.msg_content = @"解除禁言";
        }
        
//        [self.chatListArr addObject:model];
//
//        [self chatTableScrollToBottom];
        [self insertChatTableWithModel:model];
    }
    
    // 直播类型切换
//    if (Type(@"changeLive"))
//    {
//        self.oldLiveType = self.infoModel.live_type;
//        self.infoModel.live_type = messageDict[@"data"][@"live_type"];
//        self.infoModel.live_price = messageDict[@"data"][@"live_price"];
//        [self changLiveType];
//    }
}

- (void)webSocket:(SRWebSocket *)webSocket didFailWithError:(NSError *)error
{
    // 连接失败， 这里实现掉线重连，注意以下问题
    // 1, 判断当前网络环境， 断网下不需要重连， 等待网络到来再发起重连
    // 2, 连接次数限制，如果连接失败，重试10次就可以了， 防止死循环啊
    
    self.socket = nil;
    self.connectTime++;
    
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(self.connectTime*NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        
        if (self.connectTime > 10)
        {
            return ;
        }
        
        [self reconnect];

    });
}

- (void)webSocketDidOpen:(SRWebSocket *)webSocket
{
    DLog(@"连接成功， 开启心跳");
    self.connectTime = 0;
}

- (void)webSocket:(SRWebSocket *)webSocket didCloseWithCode:(NSInteger)code reason:(NSString *)reason wasClean:(BOOL)wasClean
{
    DLog(@"链接断开， 清空对象，关闭心跳");
    
//    self.socket = nil;
//    self.connectTime ++;
}

- (void)sendData{
//    _weakself;
    
    if (self.socket != nil) {
        // 只有 SR_OPEN 开启状态才能调 send 方法，不然要崩
        if (self.socket.readyState == SR_OPEN) {
            [self.socket send:@"heart"];    // 发送数据
            
        } else if (self.socket.readyState == SR_CONNECTING) {
            NSLog(@"正在连接中，重连后其他方法会去自动同步数据");
            // 每隔2秒检测一次 socket.readyState 状态，检测 10 次左右
            // 只要有一次状态是 SR_OPEN 的就调用 [ws.socket send:data] 发送数据
            // 如果 10 次都还是没连上的，那这个发送请求就丢失了，这种情况是服务器的问题了，小概率的
            dispatch_main_async_safe(^{
//                [[NSNotificationCenter defaultCenter] postNotificationName:@"reconnectSocket" object:nil userInfo:nil];
                                  [self reconnect];
            });
        } else if (self.socket.readyState == SR_CLOSING || self.socket.readyState == SR_CLOSED) {
            // websocket 断开了，调用 reConnect 方法重连
            dispatch_main_async_safe(^{
//                [[NSNotificationCenter defaultCenter] postNotificationName:@"reconnectSocket" object:nil];
                                    [self reconnect];
            });
        }
    } else {
        dispatch_main_async_safe(^{
            //                [[NSNotificationCenter defaultCenter] postNotificationName:@"reconnectSocket" object:nil];
            [self reconnect];
        });
        NSLog(@"没网络，发送失败，一旦断网 socket 会被我设置 nil 的");
    }
}
#pragma mark - 通知

- (void)addNSNotification
{
    // 视频断开连接， 且重连失败了
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(playReconteactFaild) name:@"PlayReconteactFaild" object:nil];
    
    // 视频开始播放了
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(playerStatusPlaying) name:@"PLPlayerStatusPlaying" object:nil];
    
    // 添加一个通知， 回到前台时继续播放
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(continueToPlay) name:UIApplicationDidBecomeActiveNotification object:nil];
    
    // 兑换成功
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(exchangeSuccessWithData:) name:@"exchangeSuccess" object:nil];
    
    //
    
    // 未读消息数改变
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(changePrivateMsgBtnUnread:) name:kChangeTotalUnread object:nil];
    
    // 收到私信消息推送
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(showPrivateMsgUnread) name:@"privateMessage" object:nil];
    
    // 收到系统消息推送
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(showPrivateMsgUnread) name:@"systemMessage" object:nil];
    
    // 网络监听
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(NetworkChange:) name:NetworkChangeNotification object:nil];
    
    //    // 点击了弹幕头像
    //    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(clickFlyViewHeader:) name:@"jhClickFlyViewHeaderImage" object:nil];
    
    // 私聊界面关注主播成功
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(followAnchorSuccess) name:@"FollowAnchorSuccess" object:nil];
    
    // 被人挤掉了
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(hasLogout) name:@"YouHasLogout" object:nil];
    
    // 兑换类型改变了
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(changeRechargeType:) name:@"change_recharge_type" object:nil];
    
    // 单个大礼物下载并且解压成功
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(oneGiftZipArchiveSuccess:) name:@"ZipArchiveSuccess" object:nil];
    
    // 设置巡官
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(setInspector:) name:@"SetInspector" object:nil];
    
    // 移除消息列表
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(liveMessageShowOrHidden:) name:@"liveMessageShowOrHidden" object:nil];

    // 键盘监听
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardChange:) name:UIKeyboardWillChangeFrameNotification object:nil];
    
    //
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(connecting:) name:@"HNanchor_to_connect" object:nil];
    
    // 推流成功
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(streamStartSuccess:) name:@"PLStreamStartStateSuccess" object:nil];
    
    // 关闭连麦
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(cancelSuccess:) name:@"HNcancel_flow" object:nil];
    
}

- (void)playReconteactFaild
{
    // 多次重连一直失败，
    HNAlertView *view = [[HNAlertView alloc] initWithTitle:@"提示" Content:@"网络连接异常，请检查网络设置" whitTitleArray:@[@"去设置",@"好"] withType:@"center"];
    
    _weakself;
    [view showAlertView:^(NSInteger index) {
        
        if (index == 1)
        {
//            if (weakself.isFollowLive == YES)
//            {
//                [weakself.navigationController popViewControllerAnimated:YES];
//
//                [weakself exitRoom];
//            }
//            else
//            {
//                [weakself exitRoom];
//
//                [[NSNotificationCenter defaultCenter] postNotificationName:@"popViewController" object:nil];
//            }
            
        }
        else
        {
            //            [self.pullFlowView pausePlay];
            
            NSURL *url = [NSURL URLWithString:UIApplicationOpenSettingsURLString];
            
            if ([[UIApplication sharedApplication] canOpenURL:url]) {
                
                [[UIApplication sharedApplication] openURL:url];
                
            }
            return ;
        }
    }];
}

- (void)playerStatusPlaying
{
    self.playerPlyingSuccessCount ++;
    
    DLog(@"--PlyingSuccessCount----  %ld",self.playerPlyingSuccessCount);
    
    if (self.playerPlyingSuccessCount == 1)
    {
        // 开始播放了就把该背景图移除
        self.pullBgImageView.hidden = YES;
//        [self.pullBgImageView removeFromSuperview];
        
//        @synchronized (self)
//        {
//            // 开始计时处理
////            [self startTime];
//        }
    }
}

// 回到前台
- (void)continueToPlay
{
    // 这里要进行区分处理， 如果进入后台的时候是处于有遮挡层， 待或者待， 回到前台保持原样； 反之， 则移除遮挡层
    if (self.buyBtn.hidden == YES)
    {
        [self.effectImg removeFromSuperview];
    }
    
    [self.pullFlowView startPlay];
    
    // 看socket是否掉线了，重连一下socket
    if (self.socket == nil)
    {
        [self reconnect];
    }
}


// 修改当前的未读消息数
- (void)changePrivateMsgBtnUnread:(NSNotification *)noti
{
    NSString *unread = noti.userInfo[kUnReadKey];
    
    if ([unread integerValue] == 0)
    {
        [self.privateMsgBtn hideBadge];
    }
}

// 收到私信消息推动
- (void)showPrivateMsgUnread
{
    // 这里只处理界面上私信按钮的未读消息显示， 其余在聊天界面也会接收通知
    [self.privateMsgBtn showBadge];
}

// 网络切换
- (void)NetworkChange:(NSNotification *)notifi
{
    NSInteger states = [notifi.userInfo[@"NetworkStatus"] integerValue];
    
    if (AFNetworkReachabilityStatusUnknown == states || AFNetworkReachabilityStatusNotReachable)
    {
        // 没网或者未知网络
        [self.pullFlowView stopPlay];
        
        HNAlertView *view = [[HNAlertView alloc] initWithTitle:@"提示" Content:@"网络连接异常，请检查网络设置" whitTitleArray:@[@"去设置",@"好的"] withType:@"center"];
        [view showAlertView:^(NSInteger index) {
            if (index == 1)
            {
                if (self.isFollowLive == YES)
                {
                    [self.navigationController popViewControllerAnimated:YES];
                    
                    [self exitRoom];
                }
                else
                {
                    [self exitRoom];
                    
                    [[NSNotificationCenter defaultCenter] postNotificationName:@"popViewController" object:nil];
                }
            }
            else
            {
                NSURL *url = [NSURL URLWithString:UIApplicationOpenSettingsURLString];
                
                if ([[UIApplication sharedApplication] canOpenURL:url]) {
                    
                    [[UIApplication sharedApplication] openURL:url];
                }
            }
        }];
    }
    else if (AFNetworkReachabilityStatusReachableViaWWAN == states)
    {
        // 手机网络
        [self.pullFlowView pausePlay];
        
        HNAlertView *view = [[HNAlertView alloc] initWithTitle:nil Content:@"当前网络无WIFI，继续播放可能会被运营商收取流量费用" whitTitleArray:@[@"去设置",@"继续播放"] withType:@"center"];
        [view showAlertView:^(NSInteger index) {
            if (index == 1)
            {
                [self.pullFlowView startPlay];
            }
            else
            {
                NSURL *url = [NSURL URLWithString:UIApplicationOpenSettingsURLString];
                
                if ([[UIApplication sharedApplication] canOpenURL:url]) {
                    
                    [[UIApplication sharedApplication] openURL:url];
                    
                }
            }
        }];
    }
}

- (void)followAnchorSuccess
{
    [self.userInfoView followAnchorSuccess];
}

// 被挤掉了
- (void)hasLogout
{
    [self exitRoom];
}

- (void)changeRechargeType:(NSNotification *)noti
{
    NSString *type = noti.userInfo[@"type"];
    self.recharge_type = type;
}

// 单个大礼物解压成功 界面上显示处理
- (void)oneGiftZipArchiveSuccess:(NSNotification *)noti
{
    NSString *fileName = noti.userInfo[@"fileName"];
    HNGiftListModel *model = noti.userInfo[@"model"];
    
    self.bigGiftImageArr = [HNTools getBigGiftPictureArray:fileName];
    self.bigGiftView.infoLabel.text = [NSString stringWithFormat:@"%@送给主播一个%@",self.currentSendGiftMsgModel.nick,model.name];
     [self.oneBgView insertSubview:self.bigGiftView atIndex:0];
//    [self.oneBgView addSubview:self.bigGiftView];
}


#pragma mark ----------------- 设置巡管处理 -----------------

- (void)connecting:(NSNotification *)noti                                                                                                  
{
    NSDictionary *dict = noti.userInfo[@"data"];
//     HNLiveAnchorModel *model = [HNLiveAnchorModel yy_modelWithDictionary:dict];
     self.headsetView.anchorId = self.anchorModel.uid;
    _weakself;
    self.headsetView.cancelBtnBlock = ^{
        _strongSelf;
        strongSelf.connectState = 0;
        [strongSelf.connectBtn setTitle:@"连麦互动" forState:UIControlStateNormal];
        strongSelf.headsetView = nil;
    };
    self.headsetView.connectBtnBlock = ^{
         _strongSelf;
        if (strongSelf.streamView) {
            strongSelf.streamView.streamCloudURL = [dict objectForKey:@"publishUrl"]; //// [HNAESSecurity AES128Decrypt:self.infoModel.up_url];
            strongSelf.streamView.frame=CGRectMake(SCREEN_WIDTH-(X(250)+10), SCREEN_HEIGHT-(Y(354)*1)-30, X(250), Y(350));
            strongSelf.streamView.enableNearestIP = YES;
            //            [self.view insertSubview:self.streamView aboveSubview:self.scrollerView];
            [strongSelf.streamView startPush];
        }
         strongSelf.headsetView = nil;
    };
    [self.headsetView show:4 congUserIdArr:nil];
//    UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"" message:@"是否连接" preferredStyle:UIAlertControllerStyleAlert];
//
//    UIAlertAction *okAction = [UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
//        if (self.streamView) {
//            self.streamView.streamCloudURL = [dict objectForKey:@"publishUrl"]; //// [HNAESSecurity AES128Decrypt:self.infoModel.up_url];
//            self.streamView.frame=CGRectMake(SCREEN_WIDTH-(X(250)+10), SCREEN_HEIGHT-(Y(354)*1)-30, X(250), Y(350));
//            self.streamView.enableNearestIP = YES;
////            [self.view insertSubview:self.streamView aboveSubview:self.scrollerView];
//            [self.streamView startPush];
//        }
//
////        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(30 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
////            [HNHttpRequest connectFlowWithUid:[dict objectForKey:@"roomId"] Success:^(id responseObject) {
////
////            } failure:^(NSError *error) {
////
////            }];
////        });
//
//
//    }];
//
//    UIAlertAction *cancelAction = [UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:^(UIAlertAction *action) {
//
//    }];
//
//
//    [alertController addAction:okAction];
//    [alertController addAction:cancelAction];
//    [self presentViewController:alertController animated:YES completion:nil];
}

- (void)streamStartSuccess:(NSNotification *)noti{
    if (noti.object) {
        _weakself;
         dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(5* NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
             _strongSelf;
            [HNHttpRequest connectFlowWithUid:self.anchorModel.uid Success:^(id responseObject) {
                strongSelf.connectState = 2;
                [strongSelf.connectBtn setTitle:@"连麦中" forState:UIControlStateNormal];
                strongSelf.congUserIdArr.firstObject.conetState = @"3";
                if (strongSelf.prohibitSlideBlcok) {
                    strongSelf.prohibitSlideBlcok(NO);
                }
            } failure:^(NSError *error) {
                ERROR;
            }];
       });
    }
}

- (void)cancelSuccess:(NSNotification *)noti{
    self.prohibitSlideBlcok(YES);
    self.connectState = 0;
    [self.connectBtn setTitle:@"连麦互动" forState:UIControlStateNormal];
    [self.streamView stopPush];
    self.streamView = nil;
    NSDictionary *dic = noti.userInfo;
    _weakself;
    [self.congUserIdArr enumerateObjectsWithOptions:NSEnumerationReverse usingBlock:^(id obj, NSUInteger idx, BOOL * _Nonnull stop) {
        _strongSelf;
        HNLiveAnchorModel *anchorModel = obj;
        if ([anchorModel.uid isEqualToString:dic[@"uid"]]) {
            [strongSelf.congUserIdArr removeObject:anchorModel];
            *stop = YES;
        }
    }];
}


-(void)cancelApply{
    if (self.congUserIdArr.count>0) {
        self.connectState = 0;
        [self.connectBtn setTitle:@"连麦互动" forState:UIControlStateNormal];
        [HNHttpRequest  userCancelFlowWithUid:self.anchorModel.uid  gid:kUserID Success:^(id responseObject) {
           
        } failure:^(NSError *error) {
//            ERROR;
        }];
    }
}
#pragma mark ----------------- 设置巡管处理 -----------------

- (void)setInspector:(NSNotification *)noti
{
    NSString *uid = noti.userInfo[@"uid"];
    if ([uid isEqualToString:kUserID])
    {
        self.is_inspector = noti.userInfo[@"is_inspector"];
        
        if ([self.is_inspector integerValue] == 0)
        {
            // 取消了该用户的巡管身份
            
            if ([self.infoModel.live_type integerValue] == 0)
            {
                // 当前直播为免费， 不做处理
            }
            else
            {

            }
            
        }
        else
        {
            // 设置为巡管
            [self.effectImg removeFromSuperview];
            self.buyBtn.hidden = YES;
            
//            if (self.timer)
//            {
//                [self.timer invalidate];
//                self.timer = nil;
//            }
        }
    }
}


#pragma mark ----------------- 切换直播类型 -----------------


#pragma mark ----------------- 从服务器获取单个礼物处理 -----------------

- (void)requestOneGiftWithGiftId:(NSString *)giftId chatMsgModel:(HNLiveChatMsgModel *)msgModel
{
    NSDictionary *dic = @{
                          @"gift_id" : giftId
                          };
    
    [[HNRequestManager manager] sendRequestWithRequestMethodType:HNRequestMethodTypeGET requestAPICode:GetOneGift requestParameters:dic requestHeader:@{@"authorization" : kTOKEN} success:^(id responseObject) {
        
        if (CODE != 200)
        {
            return ;
        }
        
        HNGiftListModel *model = [HNGiftListModel yy_modelWithJSON:responseObject[@"d"][@"gift"]];
        
        msgModel.g_name = model.name;
        msgModel.g_icon = model.icon;
        msgModel.g_id = model.giftId;
        model.isShow = YES;
        if ([model.animation isEqualToString:@""])
        {
            // 小礼物
            HNAnimationManager *manger = [HNAnimationManager sharedAnimationManager];
            manger.superView = self.oneBgView;
            [manger animaWithMsgModel:msgModel finishedBlock:^(BOOL result, NSInteger finishCount ) {
                
                
                DLog(@"--------------  走了没》？");
                
                // 聊天区域处理
                msgModel.msg_content = [NSString stringWithFormat:@"赠送了%ld个%@",finishCount,msgModel.g_name];
//                [self.chatListArr addObject:msgModel];
//
//                [self chatTableScrollToBottom];
                [self insertChatTableWithModel:msgModel];
            }];
        }
        else
        {
            // 大礼物
            [HNTools downloadAndZipArchiveWithGiftModel:model];
        }
        
        
        [self updateLocalGiftListWithGiftModel:model];
        
        
    } faild:^(NSError *error) {
        
    }];
}

- (void)updateLocalGiftListWithGiftModel:(HNGiftListModel *)model
{
    // 保存到本地(先判断本地是不是存在， 存在只更新， 不存在添加在最后)
    NSData *gidtData = [[UserDefault objectForKey:@"giftList"] copy];
    NSArray *array = [[NSKeyedUnarchiver unarchiveObjectWithData:gidtData] copy];
    
    BOOL _localIsHaveGift = NO;
    NSMutableArray *attArr = [NSMutableArray arrayWithArray:array];
    for (int i = 0; i < array.count; ++i)
    {
        HNGiftListModel *localModel = array[i];
        if ([localModel.giftId isEqualToString:model.giftId])
        {
            [attArr replaceObjectAtIndex:i withObject:model];
            _localIsHaveGift = YES;
            break;
        }
    }
    
    if (_localIsHaveGift == NO)
    {
        [self.giftListArr addObject:model];
    }
    else
    {
        self.giftListArr = attArr;
    }
    
    self.isChangeLocalGiftArr = YES;
    
    NSData * tempArchive = [NSKeyedArchiver archivedDataWithRootObject:self.giftListArr];
    
    [UserDefault setObject:tempArchive forKey:@"giftList"];
    [UserDefault synchronize];
}

#pragma mark ----------------- 兑换成功 -----------------

- (void)exchangeSuccessWithData:(NSNotification *)noti
{
    NSString *coin = noti.userInfo[@"user_coin"];
    self.userCoin = [NSString stringWithFormat:@"%ld",[self.userCoin integerValue] + [coin integerValue]];
    
    // 这里跟安卓保持一致， 暂时不处理， 等用户自己点击按钮时再处理
}

//#pragma mark ----------------- 点击弹幕头像 -----------------
//
//- (void)clickFlyViewHeader:(NSNotification *)noti
//{
//    NSString *uid = noti.object;
//    
//    [self clickUserHeaderWithUid:uid];
//}
//
//- (void)clickUserHeaderWithUid:(NSString *)uid
//{
//    if ([uid isEqualToString:kUserID])
//    {
//        return;
//    }
//    
//    if (self.infoCardView.superview == nil)
//    {
//        self.infoCardView.uid = uid;
//        [self.infoCardView slidingShowWithSuperView:nil];
//    }
//}

#pragma mark ----------------- HNLiveChatToolsDelegate (公聊) -----------------

- (void)inputFuntionView:(HNLiveChatToolsView *)toolsView sendMessage:(NSString *)message barrageBtnSelect:(BOOL)isSelect
{
    
    if (self.socket != nil) {
        // 只有 SR_OPEN 开启状态才能调 send 方法，不然要崩
        if (self.socket.readyState == SR_OPEN) {
//                [weakself.socket send:data];    // 发送数据
//            [self inputFuntionView:toolsView sendMessage:message barrageBtnSelect:isSelect];
            if ([self.userLevel integerValue] <= [kSayLevel integerValue])
            {
                // 用户需达到一定等级才可以发言
                [MBProgressHUD showError:@"您当前的等级不能发言"];
                return;
            }
            
            if (message.length == 0)
            {
                [MBProgressHUD showError:@"请输入聊天信息"];
                return;
            }
            
            NSDictionary *dic = @{
                                  @"word" : message,
                                  @"send_type" : isSelect ? @"barrage" : @"public_msg",
                                  @"uid" : self.anchorModel.uid
                                  };
            [[HNRequestManager manager] sendRequestWithRequestMethodType:HNRequestMethodTypePOST requestAPICode:LiveSendMsg requestParameters:dic requestHeader:@{@"authorization" : kTOKEN} success:^(id responseObject) {
                
                if (CODE != 200)
                {
                    MBErrorMsg;
                    return ;
                }
                
            } faild:^(NSError *error) {
                ERROR;
            }];
        } else if (self.socket.readyState == SR_CONNECTING) {
            NSLog(@"正在连接中，重连后其他方法会去自动同步数据");
            // 每隔2秒检测一次 socket.readyState 状态，检测 10 次左右
            // 只要有一次状态是 SR_OPEN 的就调用 [ws.socket send:data] 发送数据
            // 如果 10 次都还是没连上的，那这个发送请求就丢失了，这种情况是服务器的问题了，小概率的
            [self reconnect];
//             return;
            
        } else if (self.socket.readyState == SR_CLOSING || self.socket.readyState == SR_CLOSED) {
            // websocket 断开了，调用 reConnect 方法重连
            [self reconnect];
//             return;
        }
        
    } 
}

- (void)didClickEmojiBtnWithBtn:(UIButton *)emojiBtn
{
    self.chatToolsView.emojiScrollView.hidden = NO;
    
    [self.view layoutIfNeeded];

    [UIView animateWithDuration:0.25 animations:^{
        
        CGRect ToolsViewRect = self.chatToolsView.frame;
        CGRect emojiScrollViewRect = self.chatToolsView.emojiScrollView.frame;
        CGRect oneBgViewRect = self.liveChatTable.frame;
        
        if (emojiBtn.selected == YES)
        {
            [self.chatToolsView.inputTextField resignFirstResponder];
            
            emojiScrollViewRect.origin.y = SCREEN_HEIGHT - EmojiKeyboard_Height;
            self.chatToolsView.emojiScrollView.frame = emojiScrollViewRect;
            
            ToolsViewRect.origin.y = SCREEN_HEIGHT - EmojiKeyboard_Height - self.chatToolsView.frame.size.height;
            self.chatToolsView.frame = ToolsViewRect;
        }
        else
        {
            [self.chatToolsView.inputTextField becomeFirstResponder];
            
            emojiScrollViewRect.origin.y = SCREEN_HEIGHT;
            self.chatToolsView.emojiScrollView.frame = emojiScrollViewRect;
        }
        
        oneBgViewRect.origin.y = ToolsViewRect.origin.y - oneBgViewRect.size.height;
        self.liveChatTable.frame = oneBgViewRect;
        
    }];
}

// 键盘监听
- (void)keyboardChange:(NSNotification *)notification
{
    if (self.liveMessageVC.view.superview && self.liveMessageVC != nil) {
        // 如果是私信
        return;
    }
    else
    {
        NSDictionary *userInfo = [notification userInfo];
        
        NSTimeInterval animationDuration;
        UIViewAnimationCurve animationCurve;
        CGRect keyboardEndFrame;
        
        [[userInfo objectForKey:UIKeyboardAnimationCurveUserInfoKey] getValue:&animationCurve];
        [[userInfo objectForKey:UIKeyboardAnimationDurationUserInfoKey] getValue:&animationDuration];
        [[userInfo objectForKey:UIKeyboardFrameEndUserInfoKey] getValue:&keyboardEndFrame];
        
        [UIView animateWithDuration:animationDuration animations:^{
            
            CGRect newFrame = self.chatToolsView.frame;
            newFrame.origin.y = keyboardEndFrame.origin.y - newFrame.size.height;
            self.chatToolsView.frame = newFrame;
            
            CGRect oneBgViewFrame = self.liveChatTable.frame;
            oneBgViewFrame.origin.y = newFrame.origin.y - oneBgViewFrame.size.height;
            self.liveChatTable.frame = oneBgViewFrame;
            
        } completion:^(BOOL finished)
         {
//             if (self.liveChatTable.frame.origin.y == 0)
//             {
                 for (UIButton *btn in self.bottomBtnArr)
                 {
                     btn.hidden = NO;
                 }
//             }
         }];
        
        CGRect emojiScrollViewRect = self.chatToolsView.emojiScrollView.frame;
        
        if (keyboardEndFrame.origin.y != SCREEN_HEIGHT)
        {
            self.chatToolsView.emojiBtn.selected = NO;
            
            emojiScrollViewRect.origin.y = SCREEN_HEIGHT;
            self.chatToolsView.emojiScrollView.frame = emojiScrollViewRect;
        }
        else
        {
            CGRect newFrame = self.chatToolsView.frame;
            newFrame.origin.y = SCREEN_HEIGHT;
            self.chatToolsView.frame = newFrame;
            
            CGRect oneBgViewFrame = self.liveChatTable.frame;
            oneBgViewFrame.origin.y = oneBgViewFrame.origin.y;
            self.liveChatTable.frame = oneBgViewFrame;
        }
    }
}

// 私信消息列表界面消失
- (void)liveMessageShowOrHidden:(NSNotification *)notifi
{
    NSString *str = notifi.object;
    if ([str isEqualToString:@"removeMessageList"])
    {
        [UIView animateWithDuration:0.25 animations:^{
            self.liveMessageVC.view.transform =CGAffineTransformMakeTranslation(0, SCREEN_HEIGHT);
            
        } completion:^(BOOL finished) {
            
            self.chatToolsView.emojiScrollView.hidden = YES;

            [self.liveMessageVC removeFromParentViewController];
            self.liveMessageVC = nil;
        }];
    }
}

#pragma mark ----------------- HNGiftListViewDelegate (礼物列表) -----------------

// 去兑换
- (void)didClickRechargeBtn
{
    [self.giftListView hiddenView];
    self.giftListView = nil;
    HNMyAccountVC *vc = [[HNMyAccountVC alloc] init];
    vc.isFromUserLive = YES;
    [self.navigationController pushViewController:vc animated:YES];
   
}

// 点击了赠送
- (void)didClickSendGiftWithSelectModel:(HNGiftListModel *)model
{
    NSDictionary *dic = @{
                          @"gift_id" : model.giftId,
                          @"uid" : self.anchorModel.uid
                          };
    
    [[HNRequestManager manager] sendRequestWithRequestMethodType:HNRequestMethodTypePOST requestAPICode:SendGift requestParameters:dic requestHeader:@{@"authorization" : kTOKEN} success:^(id responseObject) {
        
        if (CODE != 200)
        {
            if (CODE == 201) {
                HNAlertView *view = [[HNAlertView alloc] initWithTitle:responseObject[@"m"] Content:@"您的余额不足，充值后才可继续送礼，是否去" whitTitleArray:@[@"取消",@"充值"] withType:@"center"];
                _weakself;
                [view showAlertView:^(NSInteger index)
                 {
                     if (index == 1) {
                         [weakself.giftListView hiddenView];
                         weakself.giftListView = nil;

                             HNMyAccountVC *vc = [[HNMyAccountVC alloc] init];
                             vc.isFromUserLive = YES;
                             [weakself.navigationController pushViewController:vc animated:YES];
                        
                     }
                 }];
            }
           
            
            if (CODE == 203)
            {
                [MBProgressHUD showError:@"礼物已下架"];
                //礼物下架了
                NSMutableArray *array = [NSMutableArray arrayWithArray:self.giftListArr];
                for (HNGiftListModel *listmodel in self.giftListArr)
                {
                    if ([listmodel.giftId isEqualToString:model.giftId])
                    {
                        listmodel.status = @"2";
                        [array removeObject:listmodel];
                        break;
                    }
                }
                
                NSData * tempArchive = [NSKeyedArchiver archivedDataWithRootObject:self.giftListArr];
                
                [UserDefault setObject:tempArchive forKey:@"giftList"];
                [UserDefault synchronize];
                
                // 处理完本地的数据， 还要处理下当前界面的礼物数据源
                self.giftListArr = array;
                
                self.isChangeLocalGiftArr = YES;
            } else
            {
                MBErrorMsg;
            }
            return ;
            
        }
        
        self.userCoin = responseObject[@"d"][@"coin"];
        self.userInfoView.exceptionalMoney = responseObject[@"d"][@"total_dot"];
        
        self.giftListView.coin = self.userCoin;
        
    } faild:^(NSError *error) {
        ERROR;
    }];
}

#pragma mark ----------------- HNBigGiftViewDelegate(大礼物动画) -----------------

- (void)cleanView
{
    [self.bigGiftView removeFromSuperview];
    self.bigGiftView = nil;
    self.bigGiftImageArr = nil;
    [self.giftImageArr removeObject:self.giftImageArr.firstObject];
    [self continueReplaceShowBigGiftView];

}

// 再次进行大礼物动画的播放
- (void)continueReplaceShowBigGiftView
{
    if (self.giftImageArr.count > 0) {
        HNLiveChatMsgModel *msgModel = self.giftImageArr.firstObject;
        NSString *giftKey = [NSString stringWithFormat:@"%@_%@",msgModel.g_id,msgModel.g_name];
        
        if ([[HNTools BigGiftNameArray] containsObject:giftKey])
        {
            [self.bigGiftImageArr removeAllObjects];
            self.bigGiftImageArr = [HNTools getBigGiftPictureArray:giftKey];
             self.currentSendGiftMsgModel = msgModel;
            self.bigGiftView.infoLabel.text = [NSString stringWithFormat:@"%@送给主播一个%@",msgModel.nick,msgModel.g_name];
            [self.oneBgView insertSubview:self.bigGiftView atIndex:0];
        }
    }else{
         self.currentSendGiftMsgModel = nil;
    }
}

#pragma mark ----------------- HNLiveChatTableDelegate(聊天视图) -----------------

- (void)showUserInfoCardWithUid:(NSString *)uid
{
    if ([uid isEqualToString:kUserID])
    {
        return;
    }
    
    if (self.infoCardView.superview == nil)
    {
        self.infoCardView.anchorId = self.anchorModel.uid;
        self.infoCardView.uid = uid;
        self.infoCardView.isFieldControl = [self.is_field_control integerValue] == 1 ? YES : NO;
        [self.infoCardView slidingShowWithSuperView:nil];
    }
}

#pragma mark ----------------- HNLiveAnchorUserInfoViewDelegate（主播信息）-----------------

- (void)didClickFollowBtnWithAnchor:(NSString *)anchorID
{
    if (kUserID == nil || [kUserID isEqualToString:@""]){
        
        [[NSNotificationCenter defaultCenter] postNotificationName:@"HNgoLogin" object:nil];
        return ;
    }
    NSDictionary *dic = @{
                          @"uid" : anchorID,
                          @"type" : @"add"
                          };
    
    [[HNRequestManager manager] sendRequestWithRequestMethodType:HNRequestMethodTypePOST requestAPICode:ChangeFollow requestParameters:dic requestHeader:@{@"authorization" : kTOKEN} success:^(id responseObject) {
        
        if (CODE != 200)
        {
            MBErrorMsg;
            return ;
        }
        
        [self.userInfoView followAnchorSuccess];
        
    } faild:^(NSError *error) {
        ERROR;
    }];
}

- (void)didClickHeaderWithAnchor:(NSString *)anchorID
{
    if (anchorID == nil || anchorID != self.anchorModel.uid)
    {
        return;
    }
    
    if (self.infoCardView.superview == nil)
    {
        self.infoCardView.uid = anchorID;
        self.infoCardView.anchorId = anchorID;
        [self.infoCardView slidingShowWithSuperView:nil];
    }
}

- (void)didClickShowFansContributionList
{
    if (kUserID == nil || [kUserID isEqualToString:@""]){
        
        [[NSNotificationCenter defaultCenter] postNotificationName:@"HNgoLogin" object:nil];
        return ;
    }
    HNFansContributionListVC *vc = [[HNFansContributionListVC alloc] init];
    vc.rid = self.anchorModel.uid;
    [self.navigationController pushViewController:vc animated:YES];
}

#pragma mark ----------------- HNUserInfoCardViewDelegate （用户信息） -----------------

- (void)didClickFollowBtnWithChangeButton:(UIButton *)followBtn
{
    if (kUserID == nil || [kUserID isEqualToString:@""]){
        
        [[NSNotificationCenter defaultCenter] postNotificationName:@"HNgoLogin" object:nil];
        return ;
    }
    if (followBtn.isSelected)
    {
        // 关注
        NSDictionary *dic = @{
                              @"type" : @"add",
                              @"uid" : self.infoCardView.uid
                              };
        
        followBtn.userInteractionEnabled = NO;
        [[HNRequestManager manager] sendRequestWithRequestMethodType:HNRequestMethodTypePOST requestAPICode:ChangeFollow requestParameters:dic requestHeader:@{@"authorization" : kTOKEN} success:^(id responseObject) {
            
            followBtn.userInteractionEnabled = YES;
            
            if (CODE != 200)
            {
                MBErrorMsg;
                followBtn.selected = NO;
                return ;
            }
            
            followBtn.selected = YES;
            [followBtn setTitle:@"已关注" forState:UIControlStateSelected];
            
            if ([self.infoCardView.uid isEqualToString:self.anchorModel.uid])
            {
                [self.userInfoView followAnchorSuccess];
            }
            
            
        } faild:^(NSError *error) {
            
            followBtn.userInteractionEnabled = YES;
            
            followBtn.selected = NO;
            ERROR;
        }];
    }
    else
    {
        // 取消关注
        NSDictionary *dic = @{
                              @"type" : @"cancel",
                              @"uid" : self.infoCardView.uid
                              };
        
        followBtn.userInteractionEnabled = NO;
        [[HNRequestManager manager] sendRequestWithRequestMethodType:HNRequestMethodTypePOST requestAPICode:ChangeFollow requestParameters:dic requestHeader:@{@"authorization" : kTOKEN} success:^(id responseObject) {
            
            followBtn.userInteractionEnabled = YES;
            
            if (CODE != 200)
            {
                MBErrorMsg;
                followBtn.selected = YES;
                return ;
            }
            
            followBtn.selected = NO;
            [followBtn setTitle:@"+关注" forState:UIControlStateNormal];
            
            // 界面上主播头像处也要进行对应的处理
            if ([self.infoCardView.uid isEqualToString:self.anchorModel.uid])
            {
                 [self.userInfoView cancelFollowAnchor];
            }
            
        } faild:^(NSError *error) {
            
            followBtn.userInteractionEnabled = YES;
            
            followBtn.selected = YES;
            ERROR;
        }];
    }
}

// 点击私信按钮
- (void)didClickPrivateMessageWithModel:(HNMessageModel *)model
{
   
    HNLiveChatMessageVC *vc = [[HNLiveChatMessageVC alloc] init];
    vc.uid = model.uid;
    vc.nick = model.nick;
    
    vc.ExitVCEnd = ^{
        
        [UIView animateWithDuration:0.25 animations:^{
            
            vc.view.transform = CGAffineTransformMakeTranslation(0, SCREEN_HEIGHT);
            
        } completion:^(BOOL finished) {
            
        }];
    };
    
    vc.view.frame = CGRectMake(0, SCREEN_HEIGHT, SCREEN_WIDTH, SCREEN_HEIGHT);
    [self addChildViewController:vc];
    [self.view addSubview:vc.view];
    
    [UIView  animateWithDuration:0.25 animations:^{
        vc.view.transform = CGAffineTransformMakeTranslation(0, -SCREEN_HEIGHT);;
    }];
}

-(void)headerBgAction:(HNMessageModel *)model{
    
    HNPersonalHomeHageVC *personalHomeHageVC=[HNPersonalHomeHageVC new];
     personalHomeHageVC.uid=model.uid;
    [self.navigationController pushViewController:personalHomeHageVC animated:YES];
}
- (void)didChangeShutupStatusWithButton:(UIButton *)shutupBtn
{
    if (kUserID == nil || [kUserID isEqualToString:@""]){
        
        [[NSNotificationCenter defaultCenter] postNotificationName:@"HNgoLogin" object:nil];
         [self.userInfoView removeFromSuperview];
        return ;
    }
    NSDictionary *dic = @{
                          @"is_banned_say" :  shutupBtn.isSelected ? @"1" : @"0",
                          @"banned_say_uid" : self.infoCardView.uid,
                          @"rid" : self.anchorModel.uid
                          };
    
    [[HNRequestManager manager] sendRequestWithRequestMethodType:HNRequestMethodTypePOST requestAPICode:SetBannedSay requestParameters:dic requestHeader:@{@"authorization" : kTOKEN} success:^(id responseObject) {
        
        if (CODE != 200)
        {
            MBErrorMsg;
            shutupBtn.selected = shutupBtn.isSelected ? NO : YES;
            return ;
        }
        
        if (shutupBtn.isSelected)
        {
            shutupBtn.selected = YES;
            [shutupBtn setTitle:@"解除禁言" forState:UIControlStateSelected];
        }
        else
        {
            shutupBtn.selected = NO;
            [shutupBtn setTitle:@"禁言" forState:UIControlStateNormal];
        }
        
    } faild:^(NSError *error) {
        
        shutupBtn.selected = shutupBtn.isSelected ? NO : YES;
        ERROR;
    }];
}

- (void)viewRemoveFromSuperView
{
//    [self.infoCardView removeFromSuperview];
    self.infoCardView = nil;
}


#pragma mark - 界面按钮点击

- (void)viewsBtnClick:(UIButton *)btn
{
    
    switch (btn.tag)
    {
        case 7000:
        {
            // 评论
            if (kUserID == nil || [kUserID isEqualToString:@""]){
                
                [[NSNotificationCenter defaultCenter] postNotificationName:@"HNgoLogin" object:nil];
                return ;
            }
            [self.view addSubview:self.chatToolsView];
            [self.chatToolsView.inputTextField becomeFirstResponder];
            
            for (UIButton *button in self.bottomBtnArr)
            {
                button.hidden = YES;
            }
            
            // 告诉自己的父视图， 此时评论界面出来了
            [[NSNotificationCenter defaultCenter] postNotificationName:@"liveMessageShowOrHidden" object:@"Show"];
            
        }
            break;
            
        case 7001:
        {
            if (kUserID == nil || [kUserID isEqualToString:@""]){
                
                [[NSNotificationCenter defaultCenter] postNotificationName:@"HNgoLogin" object:nil];
                return ;
            }
            // 私信
            self.liveMessageVC = [[HNLiveMessageVC alloc] init];
            self.liveMessageVC.anchorModel = self.anchorModel;
            self.liveMessageVC.isAnchor = NO;
            self.liveMessageVC.view.frame = CGRectMake(0, SCREEN_HEIGHT, SCREEN_WIDTH, SCREEN_HEIGHT);
            [self addChildViewController:self.liveMessageVC];
            [self.view addSubview:self.liveMessageVC.view];
            
            [UIView animateWithDuration:0.25 animations:^{
                self.liveMessageVC.view.transform = CGAffineTransformMakeTranslation(0, -SCREEN_HEIGHT);
            }];
            
            // 告诉自己的父视图， 此时私信界面出来了
            [[NSNotificationCenter defaultCenter] postNotificationName:@"liveMessageShowOrHidden" object:@"Show"];
        }
            break;
            
        case 7002:
        {
            if (kUserID == nil || [kUserID isEqualToString:@""]){
                
                [[NSNotificationCenter defaultCenter] postNotificationName:@"HNgoLogin" object:nil];
                return ;
            }
            // 礼物
            btn.enabled=NO;
//            dispatch_async(dispatch_get_main_queue(), ^{
                if (self.isChangeLocalGiftArr == YES)
                {
                    self.giftListView.giftArray = self.giftListArr;
                }
                // UI更新代码
            
                [self.giftListView show];
//            });
            self.giftListView.enabledBlock = ^{
                  btn.enabled=YES;
            };
        }
            break;
            
        case 7003:
        {
            // 退出
            NSString *string = @"";
            if ([self.infoModel.live_type integerValue] == 2)
            {
                string = @"同一场直播退出";
            }
            else
            {
                string = @"确认退出观看直播？";
            }
            
            HNAlertView *view = [[HNAlertView alloc] initWithTitle:nil Content:string whitTitleArray:@[@"取消",@"离开房间"] withType:@"center"];
            
            [view showAlertView:^(NSInteger index) {
                if (index == 1)
                {
                    // 在这里做一下区分处理， 如果是直接从开播提醒弹框进来的， 手动退出的时候， 要pop
                    if (self.isFollowLive == YES)
                    {
                        [self.navigationController popViewControllerAnimated:YES];
                        
                        [self exitRoom];
                    }
                    else
                    {
                        [self exitRoom];
                        
                        [[NSNotificationCenter defaultCenter] postNotificationName:@"popViewController" object:nil];
                    }
                }
            }];
        }
            break;
        case 7004:
        {
//            if (self.streamView) {
//                self.streamView.streamCloudURL =@"rtmp://21764.livepush.myqcloud.com/live/21764_fbb0ff5917?bizid=21764&txSecret=d00a87453cc6701ca0d24cc5804d46a2&txTime=5ADF547F"; //// [HNAESSecurity AES128Decrypt:self.infoModel.up_url];
//                self.streamView.frame=CGRectMake(SCREEN_WIDTH-(X(250)+10), SCREEN_HEIGHT-(Y(354)*1)-30, X(250), Y(350));
//                self.streamView.enableNearestIP = YES;
//               [self.view insertSubview:self.streamView aboveSubview:self.scrollerView];
//                [self.streamView startPush];
//            }
//            [HNHttpRequest  userCancelFlowWithUid:self.anchorModel.uid gid:kUserID Success:^(id responseObject) {
//
//            } failure:^(NSError *error) {
//
//            }];
//            [HNHttpRequest userCancelFlowWithSuccess:^(id responseObject) {
//
//            } failure:^(NSError *error) {
//
//            }];
            
            HNShareModel *shareModel=[HNShareModel new];
            shareModel.title=@"快来看我直播吧";
            shareModel.Desc=@"夕阳红直播，中老年人的专属直播平台，中国第一中老年直播平台";
            shareModel.webpageUrl=[NSString stringWithFormat:@"%@/live/%@/detail",WEBREQUEST,self.anchorModel.uid];
            shareModel.thumImg=self.pullBgImageView.image;//[UIImage imageNamed:_anchorModel.avatar];
            HNShareView *shareView=[HNShareView initHNShareView];
            [shareView showView:nil shareModel:shareModel];
            
        }
            break;
        case 7005:
        {
//            [self.view addSubview:self.headsetView];
            // 评论
            if (kUserID == nil || [kUserID isEqualToString:@""]){
                
                [[NSNotificationCenter defaultCenter] postNotificationName:@"HNgoLogin" object:nil];
                return ;
            }
            self.headsetView.anchorId = self.anchorModel.uid;
             _weakself;
            if (self.connectState == 0) {
                self.headsetView.applyBtnBlock = ^{
                    _strongSelf;
                    [HNHttpRequest userToConnectWithUid:strongSelf.anchorModel.uid Success:^(id responseObject) {
                        HNLiveAnchorModel *model = [HNLiveAnchorModel new];
                        model.uid = kUserID;
                        model.conetState = @"2";
                        model.nick = [HNUserModel shareInstance].nick;
                        [strongSelf.congUserIdArr enumerateObjectsWithOptions:NSEnumerationReverse usingBlock:^(id obj, NSUInteger idx, BOOL * _Nonnull stop) {
                            HNLiveAnchorModel *anchorModel = obj;
                            if ([anchorModel.uid isEqualToString:model.uid]) {
                                [strongSelf.congUserIdArr removeObject:anchorModel];
                                *stop = YES;
                            }
                        }];
                        [strongSelf.congUserIdArr addObject:model];
                        strongSelf.connectState = 1;
                        [strongSelf.connectBtn setTitle:@"等待连接" forState:UIControlStateNormal];
                    } failure:^(NSError *error) {
                        ERROR;
                    }];
                    strongSelf.headsetView = nil;
                };
                [self.headsetView show:0 congUserIdArr:self.congUserIdArr];
            }else if (self.connectState == 1){
                self.headsetView.cancelBtnBlock = ^{
                    _strongSelf;
                    strongSelf.connectState = 0;
                    [strongSelf.connectBtn setTitle:@"连麦互动" forState:UIControlStateNormal];
                     strongSelf.headsetView = nil;
                     strongSelf.prohibitSlideBlcok(NO);
                };

                [self.headsetView show:1 congUserIdArr:self.congUserIdArr];
                
            }else if (self.connectState == 2){

                self.headsetView.cancelBtnBlock = ^{
                    _strongSelf;
//                     strongSelf.connectState = 0;
//                     strongSelf.headsetView = nil;
                    strongSelf.connectState = 0;
                    strongSelf.prohibitSlideBlcok(NO);
                    [strongSelf.connectBtn setTitle:@"连麦互动" forState:UIControlStateNormal];
                    strongSelf.headsetView = nil;
                };
                [self.headsetView show:2 congUserIdArr:self.congUserIdArr];
                
            }
            self.headsetView.colseBtnBlock = ^{
                _strongSelf;
                strongSelf.headsetView = nil;
            };
//            [self addConnectView:@"http://wssource.rtc.inke.cn/live/1535440528663624.flv?ikHost=ws&ikOp=1&codecInfo=8192&dpSrc=push&ikDnsOp=1001"];
        }
            break;
        default:
            break;
    }
}


#pragma mark - UIGestureRecognizerDelegate


- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldReceiveTouch:(UITouch *)touch
{

    
    // 这里判断是否是点击其他区域让键盘消失
    if ([touch.view isKindOfClass:[UIView class]])
    {
        UIView *view = (UIView *)touch.view;
        if (view.tag == 666)
        {
            // 说明点击在了oneBgView上
            if (self.chatToolsView.emojiBtn.selected == NO)
            {
                for (UIButton *btn in self.bottomBtnArr)
                {
                    btn.hidden = NO;
                }

                [self.chatToolsView.emojiScrollView removeFromSuperview];
                [self.chatToolsView removeFromSuperview];
                self.chatToolsView = nil;
                

                // 告诉自己的父视图， 此时公聊视图已经消失了
                [[NSNotificationCenter defaultCenter] postNotificationName:@"liveMessageShowOrHidden" object:@"Hidden"];
            }
        }
    }
    
    return NO;
}

#pragma mark - 点赞动画
-(void)heartFlyViewAnimation{
     dispatch_async(dispatch_get_main_queue(), ^{
        DMHeartFlyView* heart = [[DMHeartFlyView alloc]initWithFrame:CGRectMake(0, 0, Handle(42), Handle(42))];
        [self.view addSubview:heart];
        
        CGPoint fountainSource = CGPointMake( SCREEN_WIDTH - SCREEN_WIDTH / 8.0 * 1.5 - Handle(10), self.view.bounds.size.height - SCREEN_WIDTH / 8.0);
        heart.center = fountainSource;
        [heart animateInView:self.view];
     });
}
- (void)praiseAnimation
{
    
    if (kUserID == nil || [kUserID isEqualToString:@""]){
        
        [[NSNotificationCenter defaultCenter] postNotificationName:@"HNgoLogin" object:nil];
        return ;
    }
    NSDictionary *dic = @{
                          @"uid" : self.anchorModel.uid
                          };
    [[HNRequestManager manager] sendRequestWithRequestMethodType:HNRequestMethodTypeGET requestAPICode:PraiseAnchor requestParameters:dic requestHeader:@{@"authorization" : kTOKEN} success:^(id responseObject) {
        
//        if (CODE != 200)
//        {
//            return ;
//        }
        
        self.isParse = YES;
        
        //  隐藏点赞特效
        
        [self heartFlyViewAnimation];
        
    } faild:^(NSError *error) {
        ERROR;
    }];
}

#pragma mark - privateMethod

- (void)exitRoom
{
//    [self.freeTimer invalidate];
//    self.freeTimer = nil;
//
//    [self.timer invalidate];
//    self.timer = nil;
    
    //
    [self.pullFlowView stopPlay];
    [self.pullFlowView removeFromSuperview];
    self.pullFlowView = nil;
//    if (self.pullFlowView1) {
//        [self.pullFlowView1 stopPlay];
//        [self.pullFlowView1 removeFromSuperview];
//        self.pullFlowView1 = nil;
//    }
//
//    if (self.pullFlowView2) {
//        [self.pullFlowView2 stopPlay];
//        [self.pullFlowView2 removeFromSuperview];
//        self.pullFlowView2 = nil;
//    }
    if (self.connectState==1) {
        [self cancelApply];
    }
    if (self.streamView) {
        [HNHttpRequest  userCancelFlowWithUid:self.anchorModel.uid  gid:kUserID Success:^(id responseObject) {
            
        } failure:^(NSError *error) {
            //            ERROR;
        }];
        [self.streamView stopPush];
        [self.streamView removeFromSuperview];
        self.streamView = nil;
    }
    // 关闭socket
    [self.socket close];
    self.socket.delegate = nil;
    
    // 界面上的视图都移除
    
    [_chatToolsView.emojiScrollView removeFromSuperview];
    _chatToolsView.emojiScrollView = nil;
    
    [_chatToolsView removeFromSuperview];
    _chatToolsView = nil;
    
    [_infoCardView removeFromSuperview];
    _infoCardView = nil;

    [_giftListView removeFromSuperview];
    _giftListView = nil;
    
    [_buyBtn removeFromSuperview];
    _buyBtn = nil;
    
    [self.countDownView removeFromSuperview];
    self.countDownView = nil;
    
    [self.liveChatTable removeFromSuperview];
    self.liveChatTable = nil;
    
    [self.oneBgView removeFromSuperview];
    
    [self.pullBgImageView removeFromSuperview];
    
    [self.lookUserArr removeAllObjects];
    [self.chatListArr removeAllObjects];
    
    self.playerPlyingSuccessCount = 0;
    self.infoModel = nil;
    self.userCoin = nil;
    self.userLevel = nil;
    self.is_field_control = nil;
    self.is_inspector = nil;
   
    
    // 通知也处理了
    [[NSNotificationCenter defaultCenter] removeObserver:self];
    
    // 处理当前是否有弹框
    for (UIView *view in KEY_WINDOW.subviews)
    {
        if ([view isKindOfClass:[HNAlertView class]])
        {
            if (view.tag != 1111)
            {
                HNAlertView *alert = (HNAlertView *)view;
                [alert dissmis];
            }
        }
    }
}

// 观看区域处理
- (void)insertLookUserWithModel:(HNLiveUserModel *)model type:(NSString *)type
{
    model.type = type;
//    NSMutableArray *attArr = [NSMutableArray arrayWithArray:self.lookUserArr];
    dispatch_async(dispatch_get_main_queue(), ^{

        if (self.lookUserArr.count > 50)
        {
            // 观众榜最多显示50个人
            [self.lookUserArr removeObjectAtIndex:50];
        }
        
        for (HNLiveUserModel *userModel in self.lookUserArr.reverseObjectEnumerator) {
            if ([userModel.uid isEqualToString:model.uid])
            {
                [self.lookUserArr removeObject:model];
            }
        }
        if ([type isEqualToString:@"user"]) {
            for (int i = 0; i<self.lookUserArr.count; i++) {
                HNLiveUserModel *userModel =self.lookUserArr[i];
                if ([model.level integerValue] > [userModel.level integerValue] ) {
                   [self.lookUserArr insertObject:model atIndex:i];
                    break;
                }
            }
        }else{
            [self.lookUserArr addObject:model];
        }
        [self reloadUserCollection];
    });
}

- (void)reloadUserCollection
{

    dispatch_async(dispatch_get_main_queue(), ^{
        
        [self.lookUserCollection mas_updateConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(self.userInfoView.headerBgView.mas_right).mas_offset(Handle(10));
        }];
          [self.lookUserCollection reloadData];
    });
    
    
}

// 聊天区域处理
- (void)insertChatTableWithModel:(HNLiveChatMsgModel *)msgModel
{
     [msgModel calculationcellHeight];
    [self.chatListArr addObject:msgModel];
    
    if (self.chatListArr.count > 50)
    {
        [self.chatListArr removeObjectAtIndex:0];
    }
    
    if ([msgModel.level integerValue] >= 15 && [msgModel.msg_content isEqualToString:@"入场了"])
    {
        // 进场动画
        [[HNFlyManger sharedManger] mangerPeopleEnterRoom:msgModel parentView:self.oneBgView];
    }
    
    [self chatTableScrollToBottom];

}

- (void)chatTableScrollToBottom
{
        [self.liveChatTable reloadData];
    
//        if (self.chatListArr.count == 0)
//        {
//            return ;
//        }
    
        if (self.chatListArr.count > 1)
        {
              NSIndexPath *indexPath = [NSIndexPath indexPathForRow:self.chatListArr.count - 1 inSection:0];
            [self.liveChatTable scrollToRowAtIndexPath:indexPath atScrollPosition:UITableViewScrollPositionBottom animated:NO];
            
        }
}

#pragma mark - UICollectionViewDelegate

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    return self.lookUserArr.count;
}

- (__kindof UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    HNLiveSeeUserCollectionCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"seeCell" forIndexPath:indexPath];
    
    if (self.lookUserArr.count > 0)
    {
        cell.userModel = self.lookUserArr[indexPath.row];
    }
    
    return cell;
}

- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath
{
    return CGSizeMake(Handle_width(40), Handle_height(40));
}

- (UIEdgeInsets)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout insetForSectionAtIndex:(NSInteger)section
{
    return UIEdgeInsetsMake(Handle(5), 0, Handle(5), 0);
}

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
    [collectionView deselectItemAtIndexPath:indexPath animated:YES];
    
    HNUserModel *model = self.lookUserArr[indexPath.row];
    if([model.uid rangeOfString:@"visitors"].location != NSNotFound){
        return;
    }
    [self showUserInfoCardWithUid:model.uid];
}

#pragma mark - setUI

- (void)setUI
{
    [self.view addSubview:self.scrollerView];
    [self.view insertSubview:self.pullFlowView belowSubview:self.scrollerView];
    
    [self.scrollerView addSubview:self.oneBgView];
    
    [self.oneBgView addSubview:self.userInfoView];
    [self.oneBgView addSubview:self.lookUserCollection];
    [self.oneBgView addSubview:self.liveChatTable];
    
    [self.oneBgView addSubview:self.commentBtn];
    [self.oneBgView addSubview:self.shareBtn];
    [self.oneBgView addSubview:self.privateMsgBtn];
    [self.oneBgView addSubview:self.giftBtn];
    [self.oneBgView addSubview:self.exitLiveBtn];
    [self.oneBgView addSubview:self.connectBtn];
    
    [self.oneBgView addSubview:self.buyBtn];
    
    [self setMasonry];
    
}

- (void)setMasonry
{
    [self.userInfoView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.left.right.mas_equalTo(self.oneBgView);
    }];
    
    [self.lookUserCollection mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.mas_equalTo(self.oneBgView.mas_right).mas_offset(-Handle(4.5));
        make.height.mas_offset(Handle_height(55));
        make.centerY.mas_equalTo(self.userInfoView.headerBgView.mas_centerY);
        make.left.mas_equalTo(self.userInfoView.headerBgView.mas_right).mas_offset(Handle(10));
    }];

    [self.liveChatTable mas_makeConstraints:^(MASConstraintMaker *make) {
        make.bottom.mas_equalTo(self.commentBtn.mas_top).mas_offset(-Handle(20));
        make.left.mas_equalTo(self.oneBgView);
        make.height.mas_offset(Handle_height(160));
        make.width.mas_offset(Handle_width(285));
    }];
    
    [self.commentBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_offset(kSpaceToLeftOrRight);
        make.bottom.mas_equalTo(self.oneBgView.mas_bottom).mas_offset(-kSpaceToLeftOrRight);
    }];
    
    [self.exitLiveBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.mas_equalTo(self.oneBgView).mas_offset(-kSpaceToLeftOrRight);
        make.centerY.mas_equalTo(self.commentBtn);
    }];
    
    [self.giftBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.mas_equalTo(self.exitLiveBtn.mas_left).mas_offset(-Handle(10));
        make.centerY.mas_equalTo(self.exitLiveBtn);
    }];
    
    [self.privateMsgBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.mas_equalTo(self.giftBtn.mas_left).mas_offset(-Handle(10));
        make.centerY.mas_equalTo(self.giftBtn);
    }];
    [self.shareBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.mas_equalTo(self.privateMsgBtn.mas_left).mas_offset(-Handle(10));
        make.centerY.mas_equalTo(self.privateMsgBtn);
    }];
    [self.connectBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.bottom.mas_equalTo(self.exitLiveBtn.mas_top).mas_offset(-Handle(10));
        make.right.mas_equalTo(self.oneBgView).mas_offset(-kSpaceToLeftOrRight);
        make.height.mas_offset(Handle_height(60));
        make.width.mas_offset(Handle_width(60));
    }];
    [self.buyBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.mas_equalTo(self.oneBgView.mas_right).mas_offset(-kSpaceToLeftOrRight);
        make.top.mas_equalTo(self.userInfoView.mas_bottom).mas_offset(Handle(20));
    }];
    
    [self.view layoutIfNeeded];
}


#pragma mark - getter

- (UIScrollView *)scrollerView
{
    if (!_scrollerView)
    {
        _scrollerView = InsertScrollView(nil, CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT), 88, self);
        _scrollerView.backgroundColor = [UIColor clearColor];
        _scrollerView.showsVerticalScrollIndicator = NO;
        _scrollerView.pagingEnabled = YES;
        _scrollerView.bounces = NO;
        _scrollerView.contentSize = CGSizeMake(SCREEN_WIDTH * 2, 0);
        _scrollerView.contentOffset = CGPointMake(SCREEN_WIDTH, 0);
        
        _scrollerView.userInteractionEnabled = YES;
        
        UITapGestureRecognizer *doubleTapGesture = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(praiseAnimation)];
        doubleTapGesture.numberOfTapsRequired =2;
        doubleTapGesture.numberOfTouchesRequired =1;
//        UITapGestureRecognizer *ges = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(praiseAnimation)];
//        ges.delegate = self;
        [_scrollerView addGestureRecognizer:doubleTapGesture];
        
    }
    return _scrollerView;
}

- (UIView *)oneBgView
{
    if(!_oneBgView)
    {
        _oneBgView = InsertView(nil, CGRectMake(SCREEN_WIDTH, 0, SCREEN_WIDTH, SCREEN_HEIGHT), [UIColor clearColor]);
        _oneBgView.tag = 666;
    }
    return _oneBgView;
}

- (HNLiveAnchorUserInfoView *)userInfoView
{
    if (!_userInfoView)
    {
        _userInfoView = [[HNLiveAnchorUserInfoView alloc] init];
        _userInfoView.isAnchor = NO;
        _userInfoView.infoViewDelegate = self;
    }
    return _userInfoView;
}

- (UIImageView *)pullBgImageView
{
    if (!_pullBgImageView)
    {
        _pullBgImageView = InsertImageView(nil, CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT), nil);
    }
    return _pullBgImageView;
}

- (HNTXLivePlayerView *)pullFlowView
{
    if (!_pullFlowView)
    {
        _pullFlowView = [HNTXLivePlayerView livePlayerView];
    }
    return _pullFlowView;
}

//- (HNTXLivePlayerView *)pullFlowView1
//{
//    if (!_pullFlowView1)
//    {
//        _pullFlowView1 = [HNTXLivePlayerView livePlayerView];
//        _pullFlowView1.frame= CGRectMake(SCREEN_WIDTH-(X(250)+10), SCREEN_HEIGHT-(Y(354)*2)-30, X(250), Y(350));
////        _weakself;
////        _pullFlowView1.colseBlock = ^{
////            _strongSelf;
////            strongSelf.pullFlowView1=nil;
////        };
//         [self.view insertSubview:_pullFlowView1 aboveSubview:self.pullFlowView];
//    }
//    return _pullFlowView1;
//}
//- (HNTXLivePlayerView *)pullFlowView2
//{
//    if (!_pullFlowView2)
//    {
//        _pullFlowView2 = [HNTXLivePlayerView livePlayerView];
//        _pullFlowView2.frame= CGRectMake(SCREEN_WIDTH-(X(250)+10), SCREEN_HEIGHT-(Y(354)*3)-30, X(250), Y(350));
////         _weakself;
////        _pullFlowView2.colseBlock = ^{
////            _strongSelf;
////            strongSelf.pullFlowView2=nil;
////        };
//        [self.view insertSubview:_pullFlowView2 aboveSubview:self.pullFlowView];
//
//    }
//    return _pullFlowView2;
//}
- (UICollectionView *)lookUserCollection
{
    if (!_lookUserCollection)
    {
        UICollectionViewFlowLayout *layout=[[UICollectionViewFlowLayout alloc]init];
        layout.scrollDirection = UICollectionViewScrollDirectionHorizontal;
        layout.minimumInteritemSpacing = Handle(10);
        
        _lookUserCollection = [[UICollectionView alloc] initWithFrame:CGRectZero collectionViewLayout:layout];
        _lookUserCollection.backgroundColor = [UIColor clearColor];
        _lookUserCollection.delegate = self;
        _lookUserCollection.dataSource = self;
        
        _lookUserCollection.showsVerticalScrollIndicator = NO;
        
        [_lookUserCollection registerClass:[HNLiveSeeUserCollectionCell class] forCellWithReuseIdentifier:@"seeCell"];
    }
    return _lookUserCollection;
}

- (HNLiveChatTable *)liveChatTable
{
    if (!_liveChatTable)
    {
        _liveChatTable = [HNLiveChatTable liveChatTable];
        _liveChatTable.backgroundColor = [UIColor clearColor];
        _liveChatTable.dataSourceArr = self.chatListArr;
        _liveChatTable.tableDelegate = self;
    }
    return _liveChatTable;
}

- (UIButton *)commentBtn
{
    if(!_commentBtn)
    {
        _commentBtn = InsertImageButton(nil, CGRectZero, 7000, GetImage(@"xinxi"), nil, self, @selector(viewsBtnClick:));
        
        [self.bottomBtnArr addObject:_commentBtn];
    }
    return _commentBtn;
}

- (UIButton *)shareBtn
{
    if(!_shareBtn)
    {
        _shareBtn = InsertImageButton(nil, CGRectZero, 7004, GetImage(@"share1"), nil, self, @selector(viewsBtnClick:));
        
        [self.bottomBtnArr addObject:_shareBtn];
    }
    return _shareBtn;
}
- (UIButton *)privateMsgBtn
{
    if(!_privateMsgBtn)
    {
        _privateMsgBtn = InsertImageButton(nil, CGRectZero, 7001, GetImage(@"sixin"), nil, self, @selector(viewsBtnClick:));
        
        [self.bottomBtnArr addObject:_privateMsgBtn];
    }
    return _privateMsgBtn;
}

- (UIButton *)giftBtn
{
    if(!_giftBtn)
    {
        _giftBtn = InsertImageButton(nil, CGRectZero, 7002, GetImage(@"zhibojian_liwu"), nil, self, @selector(viewsBtnClick:));
        
        [self.bottomBtnArr addObject:_giftBtn];
    }
    return _giftBtn;
}

- (UIImageView *)effectImg
{
    if(!_effectImg)
    {
        _effectImg = InsertImageView(nil, CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT), nil);
        
        UIBlurEffect *effect = [UIBlurEffect effectWithStyle:UIBlurEffectStyleDark];
        UIVisualEffectView *effectView = [[UIVisualEffectView alloc] initWithEffect:effect];
        
        effectView.frame = _effectImg.bounds;
        [_effectImg addSubview:effectView];
    
    }
    return _effectImg;
}

- (UIButton *)exitLiveBtn
{
    if(!_exitLiveBtn)
    {
        _exitLiveBtn = InsertImageButton(nil, CGRectZero, 7003, GetImage(@"tuichu_zhibojian"), nil, self, @selector(viewsBtnClick:));
        
        [self.bottomBtnArr addObject:_exitLiveBtn];
    }
    return _exitLiveBtn;
}
- (JXButton *)connectBtn
{
    if(!_connectBtn)
    {
        _connectBtn = [[JXButton alloc] initWithFrame:CGRectZero];
        _connectBtn.tag = 7005;
        [_connectBtn addTarget:self action:@selector(viewsBtnClick:) forControlEvents:UIControlEventTouchUpInside];
        _connectBtn.layer.cornerRadius = 5;
//        [_connectBtn setTitle:@"Oh,Dog!" forState:0];
        [_connectBtn setTitle:@"连麦互动" forState:UIControlStateNormal];
        _connectBtn.backgroundColor = [UIColor colorWithWhite:0.f alpha:0.3];
        [_connectBtn setTitleColor:[UIColor blackColor] forState:0];
        [_connectBtn setImage:[UIImage imageNamed:@"connect"] forState:0];
        [_connectBtn setTitleColor: [UIColor whiteColor] forState:UIControlStateNormal];

        [self.bottomBtnArr addObject:_connectBtn];
    }
    return _connectBtn;
}

- (HNLiveChatToolsView *)chatToolsView
{
    if (!_chatToolsView)
    {
        _chatToolsView = [[HNLiveChatToolsView alloc] initWithSuperView:self.view];
        _chatToolsView.toolsDelegate = self;
        _chatToolsView.barragePrice = self.infoModel.barrage_price;
    }
    return _chatToolsView;
}

- (HNBigGiftView *)bigGiftView
{
    if (!_bigGiftView)
    {
        _bigGiftView = [[HNBigGiftView alloc] initWithFrame:self.view.bounds WithAnimalArray:self.bigGiftImageArr withTimeinterval:0.1 withTimes:1];
        _bigGiftView.delegate = self;
    }
    return _bigGiftView;
}

- (HNCountdownView *)countDownView
{
    if (!_countDownView)
    {
        _countDownView = [[HNCountdownView alloc] init];
        _countDownView.frame = CGRectMake(0, -Handle_height(50), SCREEN_WIDTH, Handle_height(50));
        _countDownView.liveType = self.infoModel.live_type;
    }
    return _countDownView;
}

- (HNGiftListView *)giftListView
{
    if (!_giftListView)
    {
        _giftListView = [[HNGiftListView alloc] init];
        _giftListView.giftDelegate = self;
        _giftListView.coin = self.userCoin;
        _giftListView.giftArray = self.giftListArr;
        
    }
    return _giftListView;
}

- (NSMutableArray *)bigGiftImageArr
{
    if (!_bigGiftImageArr)
    {
        _bigGiftImageArr = [NSMutableArray array];
    }
    return _bigGiftImageArr;
}

- (NSMutableArray *)bottomBtnArr
{
    if (!_bottomBtnArr)
    {
        _bottomBtnArr = [NSMutableArray array];
    }
    return _bottomBtnArr;
}

- (NSMutableArray *)lookUserArr
{
    if (!_lookUserArr)
    {
        _lookUserArr = [NSMutableArray array];
        
    }
    return _lookUserArr;
}

- (NSMutableArray *)chatListArr
{
    if (!_chatListArr)
    {
        _chatListArr = [NSMutableArray array];
    }
    return _chatListArr;
}

- (NSArray *)tempRobotArr
{
    if (!_tempRobotArr)
    {
        _tempRobotArr = [NSArray array];
    }
    return _tempRobotArr;
}

- (NSMutableArray *)giftImageArr
{
    if (!_giftImageArr)
    {
        _giftImageArr = [NSMutableArray array];
    }
    return _giftImageArr;
}
- (NSMutableArray *)congUserIdArr
{
    if (!_congUserIdArr)
    {
        _congUserIdArr = [NSMutableArray array];
    }
    return _congUserIdArr;
}
- (HNUserInfoCardView *)infoCardView
{
    if (!_infoCardView)
    {
        _infoCardView = [[HNUserInfoCardView alloc] init];
        _infoCardView.isShowLive = YES;
        _infoCardView.isAnchor = NO;
        _infoCardView.cardDelegate = self;
    }
    return _infoCardView;
}
-(HNHeadsetView *)headsetView{
    if (!_headsetView) {
        _headsetView=[[HNHeadsetView alloc]initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT)];
    }
   return  _headsetView;
}
- (HNTXLivePushView *)streamView
{
    if (!_streamView)
    {
        _streamView = [HNTXLivePushView livePushView];
         [_streamView changeSkinCareWithType:YES skinCareValue:6 whiteningValue:6 ruddyValue:6];
        _weakself;
        _streamView.colseBlock = ^{
            _strongSelf;
            strongSelf.streamView=nil;
        };
    }
    return _streamView;
}

@end
