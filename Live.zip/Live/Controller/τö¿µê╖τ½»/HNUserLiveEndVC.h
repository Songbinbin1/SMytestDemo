//
//  HNUserLiveEndVC.h
//  SunsetLive
//
//  Created by Sunwanwan on 2017/9/11.
//  Copyright © 2017年 HN. All rights reserved.
//

#import "HNBaseViewController.h"

@interface HNUserLiveEndVC : HNBaseViewController

@property (nonatomic, strong) NSString *uid;  // 主播ID

@end
