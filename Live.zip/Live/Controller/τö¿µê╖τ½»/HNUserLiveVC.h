//
//  HNUserLiveVC.h
//  SunsetLive
//
//  Created by Sunwanwan on 2017/9/11.
//  Copyright © 2017年 HN. All rights reserved.
//  用户端

#import "HNBaseViewController.h"
#import "HNLiveAnchorModel.h"
typedef void(^ProhibitSlideBlcok)(BOOL isProhibit);
@interface HNUserLiveVC : HNBaseViewController

@property (nonatomic, strong) NSString *down_url; // 拉流地址

@property (nonatomic, strong) HNLiveAnchorModel *anchorModel;

@property (nonatomic, strong) NSString *pullBgImage;
@property (nonatomic, strong) ProhibitSlideBlcok prohibitSlideBlcok;
@property (nonatomic, assign) BOOL isFollowLive;  // 是否是从开播提醒的去看看按钮过来的

- (void)startLoadData;

- (void)exitRoom;

-(void)cancelApply;
@end
