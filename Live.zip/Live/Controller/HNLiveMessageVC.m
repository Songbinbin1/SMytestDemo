//
//  HNLiveMessageVC.m
//  SunsetLive
//
//  Created by Sunwanwan on 2017/9/15.
//  Copyright © 2017年 HN. All rights reserved.
//

#import "HNLiveMessageVC.h"
#import "HNMessageCell.h"
#import "HNLiveChatMessageVC.h"
#import "HNChatMsgModel.h"
#import "HNLiveSystemMessageVC.h"

@interface HNLiveMessageVC ()<UITableViewDelegate, UITableViewDataSource, UIGestureRecognizerDelegate>
{
    NSInteger _page;
    BOOL _isprivate;
    
    NSString *_selectDetailUserID; // 查看某一个人的聊天详情
}

@property (nonatomic, strong) UIView *headerView;
@property (nonatomic, strong) UILabel *descLab;
@property (nonatomic, strong) UIButton *unreadBtn;
@property (nonatomic, strong) UIView *line;

@property (nonatomic, strong) UITableView *mainTable;

@property (nonatomic, strong) NSMutableArray *dataArray;

@end

@implementation HNLiveMessageVC

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    self.view.backgroundColor = [UIColor clearColor];
    
    [self setUI];
    [self.mainTable.mj_header beginRefreshing];
    
    // 私信消息通知
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(haveNewMessage:) name:@"privateMessage" object:nil];
    
    // 系统消息通知
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(haveNewSystemMessage:) name:@"systemMessage" object:nil];
    
    // 某一个用户未读消息改变
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(changeOneUserUnread:) name:@"ChangeCurrentIDUnread" object:nil];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - 点击空白消失
-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    UITouch *touche = [touches anyObject];
    CGPoint point =  [touche locationInView:self.view];
    CGFloat height = self.headerView.height + self.mainTable.height;
   
    BOOL b =  CGRectContainsPoint(CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT - height), point);
    if (b)
    {
        // 在这里进行一个区分处理
        if (self.childViewControllers.count == 1)
        {
            // 说明是在聊天详情界面点击的空白区域， 则此时要调用一下退出聊天的接口， 处理下未读消息数
            [self exitMessageDetail];
        }
        else
        {
            [self HiddenView];
        }
        
    }
}

#pragma mark - loadData

- (void)loadDataWithPage:(NSInteger)page
{
    NSDictionary *dic = @{
                          @"page" : @(page)
                          };
    [[HNRequestManager manager] sendRequestWithRequestMethodType:HNRequestMethodTypeGET requestAPICode:ChatList requestParameters:dic requestHeader:@{@"authorization" : kTOKEN} success:^(id responseObject) {
        
        [self.mainTable.mj_header endRefreshing];
        [self.mainTable.mj_footer endRefreshing];
        
        if (CODE != 200)
        {
            MBErrorMsg;
            return ;
        }
        
        NSArray *array = [NSArray yy_modelArrayWithClass:[HNMessageModel class] json:responseObject[@"d"][@"chat_list"][@"items"]];
        if (page == 1)
        {
            self.dataArray = [NSMutableArray arrayWithArray:array];
            
            // 这里做一下特殊处理， 如果用户端没有跟当前主播私聊过， 那么在系统消息下插入一条消息
            if (self.isAnchor == NO)
            {
                _isprivate = NO;
                for (int i = 0; i < array.count; ++i)
                {
                    HNMessageModel *model = array[i];
                    if ([model.uid isEqualToString:self.anchorModel.uid])
                    {
                        _isprivate = YES;
                        break;
                    }
                }
                
                if (_isprivate == NO)
                {
                    HNMessageModel *model = [[HNMessageModel alloc] init];
                    model.uid = self.anchorModel.uid;
                    model.avatar = self.anchorModel.avatar;
                    model.nick = self.anchorModel.nick;
                    model.level = self.anchorModel.level;
                    model.gender = self.anchorModel.gender;
                    model.last_msg = @"喜欢主播 那就私聊TA";
                    model.isNoPrivateMsg = YES;
                    
                    [self.dataArray insertObject:model atIndex:1];
                }
            }
        }
        else
        {
            [self.dataArray addObjectsFromArray:array];
            
            if (page == [responseObject[@"d"][@"chat_list"][@"pagetotal"] integerValue])
            {
                [self.mainTable.mj_footer endRefreshingWithNoMoreData];
            }
        }
        if (array.count>0) {
            _page ++;
        }
        if (self.dataArray.count == 0)
        {
            [self loadAbankViewWithSuperView:self.mainTable frame:self.mainTable.bounds imageStr:@"defaultpage_null" descStr:@"暂时还没有消息哦"];
        }
        else
        {
            [self.baseBankView removeFromSuperview];
            
            // 这里有点特殊， 第一页的时候， 会插入一条系统消息进来， 后面的页数返回的是纯粹的聊天信息， 所以返回的total 第一页的时候不含系统消息
            
            // 也要判断是主播端还是用户端
            if (self.isAnchor)
            {
                if (self.dataArray.count - 1 == [responseObject[@"d"][@"chat_list"][@"total"] integerValue])
                {
                    self.mainTable.mj_footer = nil;
                }
            }
            else
            {
                if (_isprivate == NO)
                {
                    // 用户端没有与当前主播私聊过， 跟服务器返回的消息总数多了两条 自己插入的信息
                    if (self.dataArray.count - 2 == [responseObject[@"d"][@"chat_list"][@"total"] integerValue])
                    {
                        self.mainTable.mj_footer = nil;
                    }
                }
                else
                {
                    if (self.dataArray.count - 1 == [responseObject[@"d"][@"chat_list"][@"total"] integerValue])
                    {
                        self.mainTable.mj_footer = nil;
                    }
                }
            }
            
        }

        [self.mainTable reloadData];
        
    } faild:^(NSError *error) {
        
        [self.mainTable.mj_header endRefreshing];
        [self.mainTable.mj_footer endRefreshing];
        ERROR;
        
    }];
}

// 删除对话详情
- (void)deleteMessageWithMessageModel:(HNMessageModel *)model WithIndexPath:(NSIndexPath *)indexPath
{
    NSDictionary *dic = @{
                          @"uid" : model.uid
                          };
    
    [[HNRequestManager manager] sendRequestWithRequestMethodType:HNRequestMethodTypePOST requestAPICode:RemoveChat requestParameters:dic requestHeader:@{@"authorization" : kTOKEN} success:^(id responseObject) {
        
        if (CODE != 200)
        {
            MBErrorMsg;
            return ;
        }
        
        // 删除前， 先修改下本地的未读消息数以及tabbar的角标
        NSInteger localUnreadCount = [[UserDefault objectForKey:UnreadMessageCount] integerValue];
        localUnreadCount = localUnreadCount - [model.unread_num integerValue];
        [UserDefault setValue:[NSString stringWithFormat:@"%ld",(long)localUnreadCount] forKey:UnreadMessageCount];
        [UserDefault synchronize];
        
        [[NSNotificationCenter defaultCenter] postNotificationName:kChangeTotalUnread object:nil userInfo:@{kUnReadKey : [NSString stringWithFormat:@"%ld",(long)localUnreadCount]}];
        
        // 删除本地数据
        [self.dataArray removeObject:model];
        
        [self.mainTable deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
        
    } faild:^(NSError *error) {
        ERROR;
    }];
}

- (void)exitMessageDetail
{
    NSDictionary *dic = @{
                          @"uid" : _selectDetailUserID
                          };
    
    [[HNRequestManager manager] sendRequestWithRequestMethodType:HNRequestMethodTypePOST requestAPICode:QuitChat requestParameters:dic requestHeader:@{@"authorization" : kTOKEN} success:^(id responseObject) {
        
        if (CODE != 200)
        {
            return ;
        }
        
        // 发个通知处理用户的总的未读消息数
        NSString *total_unread = responseObject[@"d"][@"total_unread"];
        
        [UserDefault setValue:total_unread forKey:UnreadMessageCount];
        [UserDefault synchronize];
        
        [[NSNotificationCenter defaultCenter] postNotificationName:kChangeTotalUnread object:nil userInfo:@{kUnReadKey:total_unread}];
        
        // 在这里发一个通知到消息界面， 把当前用户的未读消息数处理了
        [[NSNotificationCenter defaultCenter] postNotificationName:@"allMessageisReadWithUser" object:nil userInfo:@{@"uid" : _selectDetailUserID}];
        
        [self HiddenView];
        
    } faild:^(NSError *error) {
        
    }];
}

#pragma mark - MJRefresh

- (void)headerRefreshing
{
    _page = 1;
    [self loadDataWithPage:_page];
}

- (void)footerRefreshing
{
   
    [self loadDataWithPage:_page];
}

#pragma mark - 通知

// 接收到新的私信消息
- (void)haveNewMessage:(NSNotification *)notifi
{
    NSDictionary *dict = notifi.userInfo;
    HNMessageModel *newModel = [HNMessageModel yy_modelWithJSON:dict[@"user_info"]];
    
    BOOL isHaveUid = NO;
    for (int i = 0; i < self.dataArray.count; ++i)
    {
        HNMessageModel *model = self.dataArray[i];
        
        if ([newModel.uid isEqualToString:model.uid])
        {
            isHaveUid = YES;
            
            model.last_msg = dict[@"content"][@"word"];
            model.update_time = dict[@"content"][@"add_time"];
            NSInteger unreadCount = [model.unread_num integerValue] + 1;
            model.unread_num = [NSString stringWithFormat:@"%ld",(long)unreadCount];
            
            [self.mainTable reloadRowsAtIndexPaths:@[[NSIndexPath indexPathForRow:i inSection:0]] withRowAnimation:UITableViewRowAnimationNone];
            
            break;
        }
    }
    
    if (isHaveUid == NO)
    {
        // 当前列表没有这个用户， 说明第一次发， 则把当前这条消息插入
        
        newModel.last_msg = dict[@"content"][@"word"];
        newModel.update_time = dict[@"content"][@"add_time"];
        newModel.unread_num = @"1";
        
        [self.dataArray insertObject:newModel atIndex:1];
        [self.mainTable insertRowsAtIndexPaths:@[[NSIndexPath indexPathForRow:1 inSection:0]] withRowAnimation:UITableViewRowAnimationNone];
    }
}

// 接收到新的系统消息
- (void)haveNewSystemMessage:(NSNotification *)noti
{
    NSDictionary *dict = noti.userInfo;
    
    HNMessageModel *model = self.dataArray[0];
    model.last_msg = dict[@"content"];
    model.update_time = dict[@"add_time"];
    NSInteger unread = [model.unread_num integerValue] + 1;
    model.unread_num = [NSString stringWithFormat:@"%ld",(long)unread];
    
    [self.mainTable reloadRowsAtIndexPaths:@[[NSIndexPath indexPathForRow:0 inSection:0]] withRowAnimation:UITableViewRowAnimationNone];
}

// 修改某一个用户的未读私信消息
- (void)changeOneUserUnread:(NSNotification *)noti
{
    NSDictionary *dic = noti.userInfo;
    
    NSString *uid = dic[@"uid"];
    
    if (dic.allKeys.count > 1)
    {
        HNChatMsgModel *msgModel = dic[@"model"];
        
        for (int i = 0; i < self.dataArray.count; ++i)
        {
            HNMessageModel *model = self.dataArray[i];
            if ([model.uid isEqualToString:uid])
            {
                model.unread_num = 0;
                model.last_msg = msgModel.msg_content;
                model.update_time = msgModel.add_time;
                
                HNMessageCell *cell = (HNMessageCell *)[self.mainTable cellForRowAtIndexPath:[NSIndexPath indexPathForRow:i inSection:0]];
                cell.model = model;
            }
        }
    }
    else
    {
        for (int i = 0; i < self.dataArray.count; ++i)
        {
            HNMessageModel *model = self.dataArray[i];
            if ([model.uid isEqualToString:uid])
            {
                model.unread_num = 0;
                
                HNMessageCell *cell = (HNMessageCell *)[self.mainTable cellForRowAtIndexPath:[NSIndexPath indexPathForRow:i inSection:0]];
                cell.model = model;
            }
        }
    }
}

- (void)HiddenView
{
    // 告诉自己的父视图，此时我消息列表消失了
    [[NSNotificationCenter defaultCenter] postNotificationName:@"liveMessageShowOrHidden" object:@"removeMessageList"];
}

#pragma mark - privateMethod

- (void)ignoreTheUnread
{
    [[HNRequestManager manager] sendRequestWithRequestMethodType:HNRequestMethodTypePOST requestAPICode:ClearUnread requestParameters:nil requestHeader:@{@"authorization" : kTOKEN} success:^(id responseObject) {
        
        if (CODE != 200)
        {
            MBErrorMsg;
            return ;
        }
        
        [UserDefault setValue:@"0" forKey:UnreadMessageCount];
        [UserDefault synchronize];
        
        [[NSNotificationCenter defaultCenter] postNotificationName:kChangeTotalUnread object:nil userInfo:@{kUnReadKey : @"0"}];
        
        // 界面上所有的消息的小红点都要去掉
        for (HNMessageModel *model in self.dataArray)
        {
            model.unread_num = 0;
        }
        
        [self.mainTable reloadData];
        
    } faild:^(NSError *error) {
        ERROR;
    }];
}

#pragma mark - UIGestureRecognizerDelegate

- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldReceiveTouch:(UITouch *)touch
{
    if ([touch.view isKindOfClass:[UITableView class]])
    {
        return NO;
    }
    
    if ([NSStringFromClass([touch.view class]) isEqualToString:@"UITableViewCellContentView"])
    {
        return NO;
    }
    
    return YES;
}

#pragma mark - 数据源方法

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.dataArray.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    HNMessageCell *cell = [HNMessageCell messageCellWithTabelView:tableView];
    
    cell.model = self.dataArray[indexPath.row];
    
    if (self.isAnchor == NO)
    {
        // 用户端
        if (self.dataArray.count >= 2)
        {
            if (indexPath.row == 1)
            {
                // 没有与当前主播私聊过， 则显示私聊按钮
                HNMessageModel *model = self.dataArray[1];
                if (model.isNoPrivateMsg == YES)
                {
                    cell.privateMsgBtn.hidden = NO;
                }
                else
                {
                    cell.privateMsgBtn.hidden = YES;
                }
            }
        }
    }
    
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
//    HNMessageCell *cell = (HNMessageCell *)[self tableView:tableView cellForRowAtIndexPath:indexPath];
//    return [cell cellHeight];
    
    return Handle_height(136 / 2);
}

- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (self.isAnchor)
    {
        return indexPath.row == 0 ? NO : YES;
    }
    else
    {
        HNMessageModel *model = self.dataArray[1];
        return indexPath.row == 0 ? NO : ([model.uid isEqualToString:self.anchorModel.uid] ? NO : YES);
    }
    
}

- (NSString *)tableView:(UITableView *)tableView titleForDeleteConfirmationButtonForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return @"删除";
}

- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    HNMessageModel *model = self.dataArray[indexPath.row];
    
    [self deleteMessageWithMessageModel:model WithIndexPath:indexPath];
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    if (indexPath.row == 0)
    {
        HNMessageModel *model = self.dataArray[0];
        
        _selectDetailUserID = model.uid;
        
        HNLiveSystemMessageVC *vc = [[HNLiveSystemMessageVC alloc] init];
        vc.uid = model.uid;
        
        vc.view.frame = CGRectMake(0, SCREEN_HEIGHT, SCREEN_WIDTH, SCREEN_HEIGHT);
        
        [UIView  animateWithDuration:0.25 animations:^{
            vc.view.transform = CGAffineTransformMakeTranslation(0, -SCREEN_HEIGHT);;
        }];
        
        [self addChildViewController:vc];
        [self.view addSubview:vc.view];
    }
    else
    {
        HNMessageModel *model = self.dataArray[indexPath.row];
        
        _selectDetailUserID = model.uid;
        
        HNLiveChatMessageVC *vc = [[HNLiveChatMessageVC alloc] init];
        vc.uid = model.uid;
        vc.nick = model.nick;
        
        _weakself;
        vc.ExitVCEnd = ^{
            
            [UIView animateWithDuration:0.25 animations:^{
                
                weakself.view.transform = CGAffineTransformMakeTranslation(0, SCREEN_HEIGHT);
                
            } completion:^(BOOL finished) {
                
            }];
        };
        
        vc.view.frame = CGRectMake(0, SCREEN_HEIGHT, SCREEN_WIDTH, SCREEN_HEIGHT);
        
        [UIView  animateWithDuration:0.25 animations:^{
            vc.view.transform = CGAffineTransformMakeTranslation(0, -SCREEN_HEIGHT);;
        }];
        
        [self addChildViewController:vc];
        [self.view addSubview:vc.view];

    }
}
#pragma mark - setUI

- (void)setUI
{
    [self.view addSubview:self.headerView];
    [self.headerView addSubview:self.descLab];
    [self.headerView addSubview:self.unreadBtn];
    [self.headerView addSubview:self.line];
    [self.view addSubview:self.mainTable];
    
    [self.headerView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.width.mas_equalTo(self.view);
        make.height.mas_offset(Handle_height(45));
        make.bottom.mas_offset(-Handle(450 / 2));
    }];
    
    [self.descLab mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_offset(kSpaceToLeftOrRight);
        make.centerY.mas_equalTo(self.headerView.mas_centerY);
    }];
    
    [self.unreadBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.mas_offset(-kSpaceToLeftOrRight);
        make.centerY.mas_equalTo(self.headerView.mas_centerY);
    }];
    
    [self.line mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.width.bottom.mas_equalTo(self.headerView);
        make.height.mas_offset(Handle(0.5));
    }];
    
    [self.mainTable mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(self.headerView.mas_bottom);
        make.left.width.bottom.mas_equalTo(self.view);
    }];
}

#pragma mark - getter

- (UIView *)headerView
{
    if(!_headerView)
    {
        _headerView = InsertView(nil, CGRectZero, CString(BgColor));
    }
    return _headerView;
}

- (UILabel *)descLab
{
    if(!_descLab)
    {
        _descLab = InsertLabel(nil, CGRectZero, NSTextAlignmentLeft, @"消息", SystemFontSize18, CString(TitleColor));
    }
    return _descLab;
}

- (UIButton *)unreadBtn
{
    if(!_unreadBtn)
    {
        _unreadBtn = InsertTitleAndImageButton(nil, CGRectZero, 8888, @"忽略未读", UIEdgeInsetsZero, SystemFontSize15, CString(SubtitleColor), nil, nil, nil, self, @selector(ignoreTheUnread));
    }
    return _unreadBtn;
}

- (UIView *)line
{
    if(!_line)
    {
        _line = InsertView(nil, CGRectZero, CString(LineColor));
    }
    return _line;
}

- (UITableView *)mainTable
{
    if (!_mainTable)
    {
        _mainTable = InsertTableView(nil, CGRectZero, self, self, UITableViewStylePlain, UITableViewCellSeparatorStyleNone);
        _mainTable.backgroundColor = CString(BgColor);
        _mainTable.showsVerticalScrollIndicator = NO;
        
        _weakself;
        _mainTable.mj_header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
            
            [weakself headerRefreshing];
        }];
        _mainTable.mj_footer = [MJRefreshAutoNormalFooter footerWithRefreshingBlock:^{
            
            [weakself footerRefreshing];
        }];
//        _mainTable.mj_footer.automaticallyHidden = YES;
    }
    return _mainTable;
}

- (NSMutableArray *)dataArray
{
    if (!_dataArray)
    {
        _dataArray = [NSMutableArray array];
    }
    return _dataArray;
}


@end
