//
//  ViewController.m
//  DTAlert
//
//  Created by 宋彬彬 on 2020/7/21.
//  Copyright © 2020 宋彬彬. All rights reserved.
//

#import "ViewController.h"
#import "DPAlertViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
}


- (IBAction)alertMore:(id)sender {
    UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"标题" message:@"这个是UIAlertController的默认样式" preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction *cancelAction = [UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:nil];
    UIAlertAction *okAction = [UIAlertAction actionWithTitle:@"好的" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
//        UIAlertController *alertController1 = [UIAlertController alertControllerWithTitle:@"标题" message:@"这个是UIAlertController的默认样式" preferredStyle:UIAlertControllerStyleAlert];
//         UIAlertAction *cancelAction = [UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:nil];
//          [alertController1 addAction:cancelAction];
//         [self presentViewController:alertController1 animated:YES completion:nil];
        
        [self alert:nil];
    }];
    [alertController addAction:cancelAction];
    [alertController addAction:okAction];
     [self presentViewController:alertController animated:YES completion:nil];
    
         
    
//    DPAlertAction *action2 = [DPAlertAction actionWithTitle:@"确定"
//                                                 titleColor:[UIColor redColor]
//                                                      style:(PDAlertActionStyleAlertActionStyleCancel)
//                                                    handler:^(DPAlertAction * _Nonnull action) {
//        NSLog(@"确定");
//
//
//    }];
//
//    DPAlertAction *action1 = [DPAlertAction actionWithTitle:@"取消" titleColor:[UIColor blueColor] style:(PDAlertActionStyleAlertActionStyleCancel) handler:^(DPAlertAction * _Nonnull action) {
//        NSLog(@"取消");
//    }];
//
//    DPAlertLableModel *titleModel = [DPAlertLableModel initWithTitle:@"标题标题标题标题标题标题" titleColor:[UIColor redColor] attTitle:nil];
//
//    DPAlertLableModel *messageModel = [[DPAlertLableModel alloc] init];
//    messageModel.title = @"135352526666";
//    DPAlertViewController *alert = [DPAlertViewController alertControllerWithTitleModel:titleModel messageModel:messageModel preferredStyle:DPUIAlertControllerStyleAlert];
//
//    [alert addAction:action1];
//    [alert addAction:action2];
//    [alert addAction:action2];
//    [self presentViewController:alert animated:NO completion:nil];
    
//    [self alert:nil];
}


- (IBAction)alert:(id)sender {
    
    DPAlertAction *action2 = [DPAlertAction actionWithTitle:@"确定"
                                                 titleColor:[UIColor redColor]
                                                      style:(PDAlertActionStyleAlertActionStyleCancel)
                                                    handler:^(DPAlertAction * _Nonnull action) {
        NSLog(@"确定");
    }];
    DPAlertAction *action1 = [DPAlertAction actionWithTitle:@"取消" titleColor:[UIColor blueColor] style:(PDAlertActionStyleAlertActionStyleCancel) handler:^(DPAlertAction * _Nonnull action) {
        NSLog(@"取消");
    }];
    
    NSMutableAttributedString *attributedString = [[NSMutableAttributedString alloc] initWithString:@"wgagggagwgagggagwgagggagwgagggagwgagggagwgagggagwgagggagwgagggagwgagggagwgagggagwgagggagwgagggagwgagggagwgagggagwgagggagwgagggagwgagggagwgagggagwgagggagwgagggagwgagggagwgagggagwgagggagwgagggagwgagggagwgagggagwgagggagwgagggagwgagggagwgagggagwgagggagwgagggagwgagggagwgagggagwgagggagwgagggagwgagggag"];
    // 字号
    [attributedString addAttribute: NSFontAttributeName value:[UIFont systemFontOfSize:16] range: NSMakeRange(0, attributedString.length)];
    // 字体颜色
    [attributedString addAttribute: NSForegroundColorAttributeName value:[UIColor redColor] range: NSMakeRange(0, attributedString.length)];
    NSMutableParagraphStyle *paraStyle = [[NSMutableParagraphStyle alloc] init];
    paraStyle.lineBreakMode = NSLineBreakByWordWrapping;
    paraStyle.alignment = NSTextAlignmentLeft;
    paraStyle.lineSpacing = 12;
    paraStyle.paragraphSpacing = 18;
    [attributedString addAttribute: NSParagraphStyleAttributeName value:paraStyle range: NSMakeRange(0, attributedString.length)];
    
    DPAlertLableModel *messageModel = [DPAlertLableModel initWithTitle:@"标题" titleColor:[UIColor redColor] attTitle:attributedString];
    
    DPAlertLableModel *titleModel = [[DPAlertLableModel alloc] init];
    titleModel.title = @"确定确定确定确定确定确定确定";
    DPAlertViewController *alert = [DPAlertViewController alertControllerWithTitleModel:titleModel messageModel:messageModel preferredStyle:DPUIAlertControllerStyleAlert];
    
    //    DPAlertViewController *alert = [DPAlertViewController alertControllerWithTitle:@"确定确定确定确定确定确定确定" message:nil preferredStyle:DPUIAlertControllerStyleAlert];
    [alert addAction:action1];
    [alert addAction:action2];
    
    [self presentViewController:alert animated:NO completion:nil];
}

- (IBAction)sheet:(id)sender {
    DPAlertAction *action2 = [DPAlertAction actionWithTitle:@"标题1"
                                                 titleColor:[UIColor redColor]
                                                      style:(PDAlertActionStyleAlertActionStyleCancel)
                                                    handler:^(DPAlertAction * _Nonnull action) {
        NSLog(@"标题1");
    }];
    DPAlertAction *action1 = [DPAlertAction actionWithTitle:@"标题2"
                                                 titleColor:[UIColor blueColor]
                                                      style:(PDAlertActionStyleAlertActionStyleDefault)
                                                    handler:^(DPAlertAction * _Nonnull action) {
        NSLog(@"标题2");
        [self alert:nil];
    }];
    
    DPAlertViewController *alert = [DPAlertViewController alertControllerWithTitleModel:nil messageModel:nil preferredStyle:DPUIAlertControllerStyleActionSheet];
    [alert addAction:action1];
    [alert addAction:action2];
    
    
    [self presentViewController:alert animated:NO completion:nil];
}


@end
