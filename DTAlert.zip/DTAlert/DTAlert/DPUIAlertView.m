//
//  DPUIAlertView.m
//  DTAlert
//
//  Created by 宋彬彬 on 2020/7/21.
//  Copyright © 2020 宋彬彬. All rights reserved.
//

#import "DPUIAlertView.h"



@interface DPUIAlertView ()<UITextViewDelegate>
@property (nonatomic, strong) UIView *bgView;
@property (nonatomic, strong) NSArray<DPAlertAction *> *optionsArr;
@property (nonatomic, strong) UIView *contentView;
@property (nonatomic,   copy) void(^cancelBlock)(void);
@property (nonatomic, strong) DPAlertLableModel *titleModel;
@property (nonatomic, strong) DPAlertLableModel *messageModel;

@property (nonatomic, strong) UILabel *titleLable;

@property (nonatomic, strong) UITextView *messageTextView;
@end

@implementation DPUIAlertView


- (instancetype)initWithTitleModel:(nullable DPAlertLableModel*)titleModel
                      messageModel:(nullable DPAlertLableModel*)messageModel
                        optionsArr:(NSArray*)optionsArr
                       cancelBlock:(void(^)(void))cancelBlock {
    
    if (self = [super init]) {
        _titleModel = titleModel;
        _messageModel = messageModel;
        _optionsArr = optionsArr;
        _cancelBlock = cancelBlock;
        [self craetUI];
    }
    return self;
}
- (void)craetUI {
    CGFloat contentViewWidth = Handle_width(285);
    
    self.frame = [UIScreen mainScreen].bounds;
    [self addSubview:self.bgView];
    [self addSubview:self.contentView];
    
    self.titleLable.text = _titleModel.title;
    if(self.titleModel.title){
        self.messageTextView.text = _titleModel.title;
    }else{
        self.messageTextView.attributedText = _titleModel.attTitle;
    }
    self.titleLable.textColor = _titleModel.titleColor?:UIColorFromRGBA(0 , 0, 0, 1);
    
    self.titleLable.font = [UIFont systemFontOfSize:18 weight:UIFontWeightMedium];
    self.titleLable.textAlignment = NSTextAlignmentCenter;
    [self.contentView addSubview:_titleLable];
    [self.titleLable mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(5);
        make.right.mas_equalTo(-5);
        make.top.mas_equalTo(24);
        make.height.mas_equalTo(20);
    }];
    
    if(_messageModel.title){
        self.messageTextView.text = _messageModel.title;
    }else{
        self.messageTextView.attributedText = _messageModel.attTitle;
    }
    self.messageTextView.textColor = _titleModel.titleColor?:UIColorFromRGBA(48, 48, 48, 1);
    self.messageTextView.font = [UIFont systemFontOfSize:16];
    self.messageTextView.delegate = self;
    self.messageTextView.userInteractionEnabled = NO;
    self.messageTextView.textAlignment = NSTextAlignmentCenter;
    _messageTextView.editable = NO;
    [_contentView addSubview:_messageTextView];
    
    CGSize sizeToFit = [_messageTextView sizeThatFits:CGSizeMake(contentViewWidth - 28, MAXFLOAT)];
    if(sizeToFit.height > SCREEN_HEIGHT - 150 - statusBar_HEIGHT){
        sizeToFit.height = SCREEN_HEIGHT - 150 - statusBar_HEIGHT;
        _messageTextView.userInteractionEnabled = YES;
    }
    [_messageTextView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.mas_equalTo(0);
        make.left.mas_equalTo(14);
        make.right.mas_equalTo(-14);
        make.top.mas_equalTo(_titleLable.mas_bottom).mas_offset(6);
        make.height.mas_equalTo(sizeToFit.height);
    }];
    
    UIView *lineView = [[UITextView alloc] init];
    lineView.backgroundColor = UIColorFromRGBA(230, 231, 232, 1);
    [_contentView addSubview:lineView];
    [lineView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(_messageTextView.mas_bottom).mas_offset(21);
        make.left.mas_equalTo(0);
        make.right.mas_equalTo(0);
        make.height.mas_equalTo(1);
    }];
    
    CGFloat contentViewHight = 24 + 20 + 6 + sizeToFit.height + 22;
    if (_optionsArr.count == 1) {
        contentViewHight += 44;
        DPAlertAction *acton = _optionsArr.firstObject;
        UIButton *button = [self createBtnWithAction:acton];
        button.tag = 100000;
        [_contentView addSubview:button];
        [button mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(_messageTextView.mas_bottom).mas_offset(22);
            make.left.mas_equalTo(0);
            make.right.mas_equalTo(0);
            make.height.mas_equalTo(44);
        }];
    }else if (_optionsArr.count == 2){
        contentViewHight += 44;
        DPAlertAction *leftActon = _optionsArr.firstObject;
        UIButton *leftbutton = [self createBtnWithAction:leftActon];
        leftbutton.tag = 100000;
        [_contentView addSubview:leftbutton];
        [leftbutton mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(_messageTextView.mas_bottom).mas_offset(22);
            make.left.mas_equalTo(0);
            make.width.mas_equalTo(contentViewWidth/2);
            make.height.mas_equalTo(44);
        }];
        
        DPAlertAction *rightActon = _optionsArr[1];
        UIButton *rightbutton = [self createBtnWithAction:rightActon];
        rightbutton.tag = 100001;
        [_contentView addSubview:rightbutton];
        [rightbutton mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(_messageTextView.mas_bottom).mas_offset(22);
            make.right.mas_equalTo(0);
            make.width.mas_equalTo(285/2);
            make.height.mas_equalTo(44);
        }];
        
        UIView *btnLineView = [[UITextView alloc] init];
        btnLineView.backgroundColor = UIColorFromRGBA(230, 231, 232, 1);
        [_contentView addSubview:btnLineView];
        [btnLineView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(_messageTextView.mas_bottom).mas_offset(21);
            make.centerX.mas_equalTo(0);
            make.width.mas_equalTo(1);
            make.height.mas_equalTo(44);
        }];
    }else{
        contentViewHight += (44*_optionsArr.count);
        for (int i = 0 ; i<_optionsArr.count; i++) {
            DPAlertAction *acton = _optionsArr[i];
            UIButton *button = [self createBtnWithAction:acton];
            button.tag = 100000 + i;
            [_contentView addSubview:button];
            [button mas_makeConstraints:^(MASConstraintMaker *make) {
                make.top.mas_equalTo(_messageTextView.mas_bottom).mas_offset(22 + (44*i));
                make.left.mas_equalTo(0);
                make.right.mas_equalTo(0);
                make.height.mas_equalTo(44);
            }];
            UIView *lineView = [[UITextView alloc] init];
            lineView.backgroundColor = UIColorFromRGBA(230, 231, 232, 1);
            [_contentView addSubview:lineView];
            [lineView mas_makeConstraints:^(MASConstraintMaker *make) {
                make.top.mas_equalTo(button.mas_bottom).mas_offset(0);
                make.left.mas_equalTo(0);
                make.right.mas_equalTo(0);
                make.height.mas_equalTo(1);
            }];
        }
    }
    
    [self.contentView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.mas_equalTo(0);
        make.centerX.mas_equalTo(0);
        make.width.mas_equalTo(contentViewWidth);
        make.height.mas_equalTo(contentViewHight);
    }];
}

-(UIButton *)createBtnWithAction:(DPAlertAction *)acton{
    UIButton *button =  [UIButton buttonWithType:UIButtonTypeSystem];
    [button addTarget:self action:@selector(buttonAction:) forControlEvents:UIControlEventTouchUpInside];
    [button setTitle:acton.title forState:UIControlStateNormal];
    [button setTitleColor:acton.titleColor?:UIColorFromRGBA(250, 56, 79, 1) forState:UIControlStateNormal];
    button.titleLabel.font = [UIFont systemFontOfSize:16];
    return button;
}

- (BOOL)textViewShouldBeginEditing:(UITextView *)textView{
    return NO;
}

-(void)buttonAction:(UIButton *)btn{
    DPAlertAction *rightActon = _optionsArr[btn.tag - 100000];
    if (rightActon.handler) {
        rightActon.handler(rightActon);
    }
    [self dismiss];
}

- (void)showWithView:(UIView *)view{
    [view addSubview:self];
    //    [self exChangeOut:_contentView dur:0.5];
    self.contentView.alpha = 0;
    self.contentView.transform = CGAffineTransformMakeScale(0.65, 0.65);
    [UIView animateWithDuration:0.35 animations:^{
        self.contentView.transform = CGAffineTransformIdentity;
        self.contentView.alpha = 1;
    } completion:nil];
    
}

- (void)dismiss {
    self.contentView.transform = CGAffineTransformMakeScale(1, 1);
    [UIView animateWithDuration:0.35 animations:^{
        self.contentView.transform = CGAffineTransformMakeScale(0.65, 0.65);
        self.contentView.alpha = 0;
    } completion:^(BOOL finished) {
        [self removeFromSuperview];
        if (self.cancelBlock) {
            self.cancelBlock();
        }
    }];
}

- (void)touchesEnded:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    
}

-(UIView *)bgView{
    if (!_bgView) {
        _bgView = [UIView new];
        _bgView.frame = [UIScreen mainScreen].bounds;
        _bgView.backgroundColor = UIColorFromRGBA(0, 0, 0, 0.4);
        _bgView.userInteractionEnabled = YES;
    }
    return _bgView;
}

-(UIView *)contentView{
    if (!_contentView) {
        _contentView = [UIView new];
        _contentView.backgroundColor= [UIColor whiteColor];
        _contentView.userInteractionEnabled = YES;
        _contentView.layer.cornerRadius = 12;
    }
    return _contentView;
}

-(UILabel *)titleLable{
    if (!_titleLable) {
        _titleLable = [[UILabel alloc] init];;
    }
    return _titleLable;
}

-(UITextView *)messageTextView{
    if (!_messageTextView) {
        _messageTextView = [[UITextView alloc] init];;
    }
    return _messageTextView;
}

@end
