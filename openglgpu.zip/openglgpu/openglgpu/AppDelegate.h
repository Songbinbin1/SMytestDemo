//
//  AppDelegate.h
//  openglgpu
//
//  Created by 宋彬彬 on 2019/4/20.
//  Copyright © 2019年 宋彬彬. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

