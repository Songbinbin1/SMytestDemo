//
//  ViewController.h
//  openglgpu
//
//  Created by 宋彬彬 on 2019/4/20.
//  Copyright © 2019年 宋彬彬. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <GPUImage/GPUImage.h>
#import "GPUImageBeautifyFilter.h"
@interface ViewController : UIViewController{
    GPUImageBilateralFilter *bilateralFilter;
    GPUImageBrightnessFilter *brightnessFilter;
   
}


@end

