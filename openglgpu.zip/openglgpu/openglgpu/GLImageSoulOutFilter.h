//
//  GLImageSoulOutFilter.h
//  GPURenderKitDemo
//
//  Created by 刘海东 on 2019/4/16.
//  Copyright © 2019 刘海东. All rights reserved.
//

#import "GPUImageFilter.h"

/** 抖音灵魂出窍demo */

NS_ASSUME_NONNULL_BEGIN

@interface GLImageSoulOutFilter : GPUImageFilter

@end

NS_ASSUME_NONNULL_END
