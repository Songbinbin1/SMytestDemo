//
//  FilterData.m
//  openglgpu
//
//  Created by 宋彬彬 on 2020/4/1.
//  Copyright © 2020 宋彬彬. All rights reserved.
//

#import "FilterData.h"

@implementation FilterData

@end
