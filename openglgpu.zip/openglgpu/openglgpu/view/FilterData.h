//
//  FilterData.h
//  openglgpu
//
//  Created by 宋彬彬 on 2020/4/1.
//  Copyright © 2020 宋彬彬. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface FilterData : NSObject
@property (nonatomic,strong) NSString* name;
@property (nonatomic,strong) NSString* value;
@property (nonatomic,strong) NSString* fillterName;
@property (nonatomic,strong) NSString* iconPath;
@property (nonatomic,assign) BOOL isSelected;
@end

NS_ASSUME_NONNULL_END
