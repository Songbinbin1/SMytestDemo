//
//  SBBHttpRequest.h
//  openglgpu
//
//  Created by 宋彬彬 on 2019/11/28.
//  Copyright © 2019 宋彬彬. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <AFNetworking.h>
NS_ASSUME_NONNULL_BEGIN
typedef void(^SuccessBlock)(id responseObject);

typedef void(^FaildBlock)(NSError *error);
@interface SBBHttpRequest : NSObject

+(void)downloadVideoWithUrl:(NSString *)downloadUrl success:(SuccessBlock)success
faild:(FaildBlock)faild;
@end

NS_ASSUME_NONNULL_END
