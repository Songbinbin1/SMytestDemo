//
//  GPU3x3NineSquaresFilter.m
//  AVFoundationDemo
//
//  Created by RMKJ on 2019/6/27.
//  Copyright © 2019 RMKJ. All rights reserved.
//

#import "GPU3x3NineSquaresFilter.h"

NSString *const kGPUImage3x3NineSquaresFragmentShaderString = SHADER_STRING
(
 varying highp vec2 textureCoordinate;
 
 uniform sampler2D inputImageTexture;
 
 void main()
 {
     highp vec2 textureCoord = textureCoordinate;
     
     /**
      横向坐标分成三块
      */
     if (textureCoord.s <= 0.333) {
         // 1
         textureCoord.s *= 3.0;
     } else if (textureCoord.s <= 0.666) {
         // 2
         textureCoord.s = (textureCoord.s - 0.333) * 3.0;
     } else {
         // 3
         textureCoord.s = (textureCoord.s - 0.666) * 3.0;
     }

     /**
      纵向坐标分成三块
      */
     if (textureCoord.t <= 0.333) {
         // 1
         textureCoord.t *= 3.0;
     } else if (textureCoord.t <= 0.666) {
         // 2
         textureCoord.t = (textureCoord.t - 0.333) * 3.0;
     } else {
         // 3
         textureCoord.t = (textureCoord.t - 0.666) * 3.0;
     }
     gl_FragColor = texture2D(inputImageTexture, textureCoord);
 }
 );

@implementation GPU3x3NineSquaresFilter

- (id)init;
{
    if (!(self = [super initWithFragmentShaderFromString:kGPUImage3x3NineSquaresFragmentShaderString]))
    {
        return nil;
    }
    return self;
}

@end
