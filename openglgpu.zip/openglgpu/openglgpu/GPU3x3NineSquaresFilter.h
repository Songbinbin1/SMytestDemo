//
//  GPU3x3NineSquaresFilter.h
//  AVFoundationDemo
//
//  Created by RMKJ on 2019/6/27.
//  Copyright © 2019 RMKJ. All rights reserved.
//

#import "GPUImageFilter.h"

NS_ASSUME_NONNULL_BEGIN

extern NSString *const kGPUImage3x3NineSquaresFragmentShaderString;

@interface GPU3x3NineSquaresFilter : GPUImageFilter

@end

NS_ASSUME_NONNULL_END
