//
//  VideoCameraView.h
//  openglgpu
//
//  Created by 宋彬彬 on 2019/6/14.
//  Copyright © 2019年 宋彬彬. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "GPUImage.h"
#import "GPUImageBeautifyFilter.h"
NS_ASSUME_NONNULL_BEGIN

@interface VideoCameraView : UIView{
    GPUImageVideoCamera *videoCamera;
    GPUImageBeautifyFilter *filter;
    GPUImageMovieWriter *movieWriter;
    NSString *pathToMovie;
    GPUImageView *filteredVideoView;
    CALayer *_focusLayer;
    NSTimer *myTimer;
    UILabel *timeLabel;
    NSDate *fromdate;
    CGRect mainScreenFrame;

}
/// 水印
@property (strong, nonatomic) GPUImageUIElement *dissolveElement;
/// 与水印合并的界面滤镜 主要用来显示
@property (strong, nonatomic) GPUImageAlphaBlendFilter *dissolveFilter;
- (instancetype)initWithFrame:(CGRect)frame NS_DESIGNATED_INITIALIZER; 
@end

NS_ASSUME_NONNULL_END
