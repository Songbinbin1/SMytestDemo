//
//  ViewController.m
//  openglgpu
//
//  Created by 宋彬彬 on 2019/4/20.
//  Copyright © 2019年 宋彬彬. All rights reserved.
//

#import "ViewController.h"
#import <GPUImage/GPUImage.h>
#import "VideoCameraView.h"
#import "GPU3x3NineSquaresFilter.h"
#import "GLImageSoulOutFilter.h"
#import "GPUImageMxNSquaresFilter.h"
#import "SBBHttpRequest.h"
#import "TVViewController.h"
//#import  <SnapKit/SnapKit-umbrella.h>
//#import "openglgpu-Bridging-Header.h"
//#import "openglgpu-Swift.h"
#define SCREEN_WIDTH [UIScreen mainScreen].bounds.size.width
#define SCREEN_HEIGHT [UIScreen mainScreen].bounds.size.height
typedef uint32_t(*CallBackGetPrivateKey)(int num);
@interface ViewController ()
@property(nonatomic,strong) GPUImageVideoCamera *videoCamera;
@property(nonatomic,strong) GPUImageView *imageView;
@property (nonatomic,strong) GPUImageFilterGroup    *filterGroup;
@property (nonatomic,strong) GPUImageMovieWriter    *movieWriter;
@property (nonatomic,strong) GPU3x3NineSquaresFilter *squaresFilter;
@property (nonatomic,strong) GPUImageMxNSquaresFilter *squaresFilter1;
@property (nonatomic,strong) GPUImageBeautifyFilter *beautifyFilter;

@property (nonatomic,strong) GLImageSoulOutFilter *soulOutFilter;
@property (nonatomic,strong) GPUImageUIElement *uielement;
@property (nonatomic,strong) GPUImageFilter* uiFilter;
@property (nonatomic,strong) NSMutableArray *urlArr;
@property (nonatomic,strong) NSURL *micUrl;
@end

@implementation ViewController{
    NSString *pathToMovie;
    GPUImageOutput<GPUImageInput> *filter;
}

- (void)viewDidLoad {
    [super viewDidLoad];
 
    CGFloat width = SCREEN_WIDTH;
    CGFloat height = SCREEN_HEIGHT;
    _imageView = [[GPUImageView alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
    _imageView.center = self.view.center;
    [self.view addSubview:_imageView];
    _micUrl = [NSURL fileURLWithPath:[[NSBundle mainBundle] pathForResource:@"audio536" ofType:@"mp3"]];

    [self addBtn];
    UISlider *filterSettingsSlider = [[UISlider alloc] initWithFrame:CGRectMake(25.0, 30.0, width - 50.0, 40.0)];
    [filterSettingsSlider addTarget:self action:@selector(updateSliderValue:) forControlEvents:UIControlEventValueChanged];
    filterSettingsSlider.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleTopMargin;
    filterSettingsSlider.minimumValue = 0.0;
    filterSettingsSlider.maximumValue = 9.0;
    filterSettingsSlider.value = 1.0;
    [self.view addSubview:filterSettingsSlider];
    UISlider *filterSettingsSlider1 = [[UISlider alloc] initWithFrame:CGRectMake(25.0 , 30.0+ 40.0, width - 50.0, 40.0)];
    [filterSettingsSlider1 addTarget:self action:@selector(updateSliderValue1:) forControlEvents:UIControlEventValueChanged];
    filterSettingsSlider1.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleTopMargin;
    filterSettingsSlider1.minimumValue = 0.0;
    filterSettingsSlider1.maximumValue = 1.0;
    filterSettingsSlider1.value = 1.0;
    [self.view addSubview:filterSettingsSlider1];
//    // GPUImageView 用来显示相机捕获的画面
//    // Do any additional setup after loading the view, typically from a nib.
    _videoCamera  = [[GPUImageVideoCamera alloc]initWithSessionPreset:AVCaptureSessionPresetHigh cameraPosition:AVCaptureDevicePositionBack];
    if ([_videoCamera.inputCamera lockForConfiguration:nil]) {
              //自动对焦
          if ([_videoCamera.inputCamera isFocusModeSupported:AVCaptureFocusModeContinuousAutoFocus]) {
              [_videoCamera.inputCamera setFocusMode:AVCaptureFocusModeContinuousAutoFocus];
          }
          //自动曝光
          if ([_videoCamera.inputCamera isExposureModeSupported:AVCaptureExposureModeContinuousAutoExposure]) {
              [_videoCamera.inputCamera setExposureMode:AVCaptureExposureModeContinuousAutoExposure];
          }
          //自动白平衡
          if ([_videoCamera.inputCamera isWhiteBalanceModeSupported:AVCaptureWhiteBalanceModeContinuousAutoWhiteBalance]) {
              [_videoCamera.inputCamera setWhiteBalanceMode:AVCaptureWhiteBalanceModeContinuousAutoWhiteBalance];
          }
      
          [_videoCamera.inputCamera unlockForConfiguration];
      }
//    _videoCamera.outputImageOrientation = UIDeviceOrientationPortrait;
     _videoCamera.outputImageOrientation = UIInterfaceOrientationPortrait;
    _videoCamera.horizontallyMirrorFrontFacingCamera = YES;

    _videoCamera.horizontallyMirrorRearFacingCamera = NO;
    [self.videoCamera addAudioInputsAndOutputs];
    [_videoCamera rotateCamera];
    _filterGroup = [[GPUImageFilterGroup alloc] init];
    [_videoCamera startCameraCapture];
    // 创建美颜滤镜
    [self showsquaresFilter];
}

- (IBAction)soulAction:(id)sender {
    _filterGroup = [[GPUImageFilterGroup alloc] init];
     [self addbeautifyFilter];
    GLImageSoulOutFilter *soulOutFilter = [[GLImageSoulOutFilter alloc]init];
    [self addGPUImageFilter:soulOutFilter];
    [self updateFilter];
}

-(void)x3NineSquares{
     _filterGroup = [[GPUImageFilterGroup alloc] init];
     [self addbeautifyFilter];
    _squaresFilter =  [[GPU3x3NineSquaresFilter alloc]init];
     [self addGPUImageFilter:_squaresFilter];
    [self updateFilter];
}

-(void)addBtn{
    UIButton *startBtn = [[UIButton alloc]initWithFrame:CGRectMake(30, SCREEN_WIDTH - 40, 60, 40)];
    startBtn.backgroundColor = [UIColor blueColor];
    [startBtn setTitle:@"录制" forState:UIControlStateNormal];
    [startBtn addTarget:self action:@selector(startRecording:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:startBtn];
    UIButton *stopBtn = [[UIButton alloc]initWithFrame:CGRectMake(SCREEN_WIDTH-30-60, SCREEN_WIDTH - 40, 60, 40)];
    [stopBtn setTitle:@"导出" forState:UIControlStateNormal];
     stopBtn.backgroundColor = [UIColor blueColor];
    [stopBtn addTarget:self action:@selector(stopRecording:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:stopBtn];
    
    UIButton *startBtn1 = [[UIButton alloc]initWithFrame:CGRectMake(30, SCREEN_HEIGHT - 70, 80, 40)];
   startBtn1.backgroundColor = [UIColor blueColor];
   [startBtn1 setTitle:@"soulOut" forState:UIControlStateNormal];
   [startBtn1 addTarget:self action:@selector(soulAction:) forControlEvents:UIControlEventTouchUpInside];
   [self.view addSubview:startBtn1];
   
    UIButton *x3NineSquaresBtn = [[UIButton alloc]initWithFrame:CGRectMake(120, SCREEN_HEIGHT - 70, 60, 40)];
      x3NineSquaresBtn.backgroundColor = [UIColor blueColor];
      [x3NineSquaresBtn setTitle:@"3x" forState:UIControlStateNormal];
      [x3NineSquaresBtn addTarget:self action:@selector(x3NineSquares) forControlEvents:UIControlEventTouchUpInside];
      [self.view addSubview:x3NineSquaresBtn];
    
}

- (void)startRecording:(UIButton *)sender{
    if(!pathToMovie){
         [sender setTitle:@"暂停" forState:UIControlStateNormal];
        //    //组合
        pathToMovie =  [NSHomeDirectory() stringByAppendingPathComponent:[NSString stringWithFormat:@"tmp/Movie%lu.mov",(unsigned long)self.urlArr.count]];
        unlink([pathToMovie UTF8String]); // If a file already exists, AVAssetWriter won't let you record new frames, so delete the old movie
        NSURL *movieURL = [NSURL fileURLWithPath:pathToMovie];
        //    NSString *pathToMovie = [[NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES) objectAtIndex:0] stringByAppendingPathComponent:@"aiMovie.mp4"];
        //    NSURL  *movieURL = [NSURL URLWithString:pathToMovie];
        
        _movieWriter = [[GPUImageMovieWriter alloc] initWithMovieURL:movieURL size:CGSizeMake(_imageView.sizeInPixels.width, _imageView.sizeInPixels.height)];
        [_filterGroup addTarget:_movieWriter];
        _movieWriter.isNeedBreakAudioWhiter = YES;
        _movieWriter.encodingLiveVideo = YES;
        _movieWriter.shouldPassthroughAudio = YES;
        _videoCamera.audioEncodingTarget = _movieWriter;
        [_movieWriter startRecording];
    }else{
         [self.filterGroup removeTarget:_squaresFilter1];
          [sender setTitle:@"录制" forState:UIControlStateNormal];
        __weak __typeof(self)weakSelf = self;
        [_movieWriter finishRecordingWithCompletionHandler:^{
            __strong __typeof(weakSelf)strongSelf = weakSelf;
            strongSelf.videoCamera.audioEncodingTarget = nil;
            [strongSelf.filterGroup removeTarget:strongSelf.movieWriter];
        }];
        [self.urlArr addObject:[NSURL URLWithString:[NSString stringWithFormat:@"file://%@",pathToMovie]]];
//        NSURL *movieURL = [NSURL fileURLWithPath:pathToMovie];
        pathToMovie = nil;
//        UISaveVideoAtPathToSavedPhotosAlbum([movieURL path], self, @selector(video:didFinishSavingWithError:contextInfo:), nil);
    }
}

- (void)stopRecording:(UIButton *)sender{
//    if ( self.urlArr.count > 3) {
        NSString *OutPath =  [NSHomeDirectory() stringByAppendingPathComponent:[NSString stringWithFormat:@"tmp/Movie%lu.mov",(unsigned long)self.urlArr.count+1]];
        [self mergeAndExportVideos:[self.urlArr copy] withOutPath:OutPath];
        [self.urlArr removeAllObjects];
//    }
}

-(void)showsquaresFilter{
    
    [self addbeautifyFilter];
    [self updateFilter];
}

-(void)addbeautifyFilter{
    _beautifyFilter = [[GPUImageBeautifyFilter alloc] init];
       // 设置GPUImage处理链，从数据源 => 滤镜 => 最终界面效果
      [self addGPUImageFilter:_beautifyFilter];
}


-(void)updateFilter{
    [_videoCamera  removeAllTargets];
    // 水印
    UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(100, 100, 100, 100)];
    label.text = @"我是水印";
    label.font = [UIFont systemFontOfSize:30];
    label.textColor = [UIColor redColor];
    [label sizeToFit];
    
    UIView *subView = [[UIView alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
    subView.backgroundColor = [UIColor clearColor];

    [subView addSubview:label];
    
   GPUImageUIElement *uielement = [[GPUImageUIElement alloc] initWithView:subView];
    
    /// 水印滤镜
   filter = [[GPUImageDissolveBlendFilter alloc] init];
      [(GPUImageDissolveBlendFilter *)filter setMix:0.5];

       /// 水印 渲染到 水印滤镜
    [_filterGroup addTarget:filter];
     [uielement addTarget:filter];
    [_videoCamera addTarget:_filterGroup];
    
    [_filterGroup addTarget:_imageView];
    /// 更新到滤镜上 每次更新水印需要刷新
//       __unsafe_unretained GPUImageUIElement *weakOverlay = self.uielement;
       [self.filterGroup setFrameProcessingCompletionBlock:^(GPUImageOutput *output, CMTime time) {
//           [weakOverlay update];
            [uielement updateWithTimestamp:time];
       }];

}

-(void)showImageRGBFilter{
    // 添加 filter
    /**
     原理：
     1. filterGroup(addFilter) 滤镜组添加每个滤镜
     2. 按添加顺序（可自行调整）前一个filter(addTarget) 添加后一个filter
     3. filterGroup.initialFilters = @[第一个filter]];
     4. filterGroup.terminalFilter = 最后一个filter;
     */
        GPUImageRGBFilter *filter1         = [[GPUImageRGBFilter alloc] init];
        GPUImageToonFilter *filter2        = [[GPUImageToonFilter alloc] init];
        GPUImageSepiaFilter *filter3       = [[GPUImageSepiaFilter alloc] init];
        GPUImageColorInvertFilter *filter4 = [[GPUImageColorInvertFilter alloc] init];
        [self addGPUImageFilter:filter1];
        [self addGPUImageFilter:filter2];
        [self addGPUImageFilter:filter3];
        [self addGPUImageFilter:filter4];
        [self updateFilter];
}

-(void)showbilateralFilter{
    bilateralFilter = [[GPUImageBilateralFilter alloc] init];
    [bilateralFilter setDistanceNormalizationFactor:9.3];
    //  6.美白滤镜
    brightnessFilter = [[GPUImageBrightnessFilter alloc] init];
    [brightnessFilter setBrightness:0.3];
    [self addGPUImageFilter:bilateralFilter];
     [self addGPUImageFilter:brightnessFilter];

     [self updateFilter];
}

- (IBAction)updateSliderValue1:(id)sender

{
//     [brightnessFilter setBrightness:[(UISlider *)sender value]];
    _beautifyFilter.intensity = [(UISlider *)sender value];
//        [(GPUImageBeautifyFilter *)beautifyFilter setSaturation:[(UISlider *)sender value]];
}

- (IBAction)updateSliderValue:(id)sender

{
//     [bilateralFilter setDistanceNormalizationFactor:[(UISlider *)sender value]];
    _beautifyFilter.bil = [(UISlider *)sender value];
//        [(GPUImageBeautifyFilter *)beautifyFilter setSaturation:[(UISlider *)sender value]];
}

-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{

    
}

- (void)mergeAndExportVideos:(NSArray*)videosPathArray withOutPath:(NSString*)outpath{
    if (videosPathArray.count == 0) {
        return;
    }
    unlink([outpath UTF8String]);
    //创建一个音视频组合轨道
    AVMutableComposition *mixComposition = [[AVMutableComposition alloc] init];
    
    //创建可变音频通道容器
    AVMutableCompositionTrack *audioTrack = [mixComposition addMutableTrackWithMediaType:AVMediaTypeAudio
                                                                        preferredTrackID:kCMPersistentTrackID_Invalid];
    //创建可变视频通道容器
    AVMutableCompositionTrack *videoTrack = [mixComposition addMutableTrackWithMediaType:AVMediaTypeVideo
                                                                        preferredTrackID:kCMPersistentTrackID_Invalid];
    
    CMTime totalDuration = kCMTimeZero;
    //把多段视频合并到一个视频通道 多段音频合并到一个音频通道
    for (int i = 0; i < videosPathArray.count; i++) {
        //        AVURLAsset *asset = [AVURLAsset assetWithURL:[NSURL URLWithString:videosPathArray[i]]];
        NSDictionary* options = @{AVURLAssetPreferPreciseDurationAndTimingKey:@YES};
        
        AVAsset* asset = [AVURLAsset URLAssetWithURL:videosPathArray[i] options:options];
       NSError *erroraudio = nil;

        
        //获取AVAsset中的音频
        AVAssetTrack *assetAudioTrack = [[asset tracksWithMediaType:AVMediaTypeAudio] firstObject];
        
        
        //向通道内加入音频
        BOOL ba = [audioTrack insertTimeRange:CMTimeRangeMake(kCMTimeZero, asset.duration)
                                      ofTrack:assetAudioTrack
                                       atTime:totalDuration
                                        error:&erroraudio];

        NSLog(@"erroraudio:%@%d",erroraudio,ba);
        
        NSError *errorVideo = nil;
        //获取AVAsset中的视频
        AVAssetTrack *assetVideoTrack = [[asset tracksWithMediaType:AVMediaTypeVideo]firstObject];
         //向通道内加入视频
        BOOL bl = [videoTrack insertTimeRange:CMTimeRangeMake(kCMTimeZero, asset.duration)
                                      ofTrack:assetVideoTrack
                                       atTime:totalDuration
                                        error:&errorVideo];
        NSLog(@"errorVideo:%@%d",errorVideo,bl);
         //视频通道在视频合成体中的时间点
        totalDuration = CMTimeAdd(totalDuration, asset.duration);
        NSLog(@"-=-=-=-=-=-%lld",asset.duration.value);
    }
   
   //创建音频通道容器
   AVMutableCompositionTrack *audioTrack1 = [mixComposition addMutableTrackWithMediaType:AVMediaTypeAudio
                                                                       preferredTrackID:kCMPersistentTrackID_Invalid];

    NSDictionary* options = @{AVURLAssetPreferPreciseDurationAndTimingKey:@YES};
   AVAsset* asset = [AVURLAsset URLAssetWithURL:self.micUrl options:options];
   
   NSError *erroraudio = nil;
   //获取AVAsset中的音频 或者视频

   AVAssetTrack *assetAudioTrack = [[asset tracksWithMediaType:AVMediaTypeAudio] firstObject];
   //向通道内加入音频或者视频
   BOOL ba = [audioTrack1 insertTimeRange:CMTimeRangeMake(kCMTimeZero, totalDuration)
                                 ofTrack:assetAudioTrack
                                  atTime:kCMTimeZero
                                   error:&erroraudio];
   
   NSLog(@"erroraudio:%@%d",erroraudio,ba);
    NSLog(@"%@",NSHomeDirectory());
    
    //水印图片
    UIImage* waterImg = [UIImage imageNamed:@"audio"];

    //获取视频尺寸大小
    CGSize videoSize = [videoTrack naturalSize];
    //创建视频水印layer
    CALayer* aLayer = [CALayer layer];
    aLayer.contents = (id)waterImg.CGImage;
    aLayer.frame = CGRectMake(videoSize.width - waterImg.size.width - 30, videoSize.height - waterImg.size.height*3, waterImg.size.width, waterImg.size.height);
    aLayer.opacity = 0.9;
    
    //创建背景层parentLayer
    CALayer *parentLayer = [CALayer layer];
    //创建视频展示层videoLayer
    CALayer *videoLayer = [CALayer layer];
    parentLayer.frame = CGRectMake(0, 0, videoSize.width, videoSize.height);
    videoLayer.frame = CGRectMake(0, 0, videoSize.width, videoSize.height);
    [parentLayer addSublayer:videoLayer];
    //添加水印到视频parentLayer上
    [parentLayer addSublayer:aLayer];
    
    //视频操作指令集合
    AVMutableVideoComposition* videoComp = [AVMutableVideoComposition videoComposition];
    //设置视频尺寸
    videoComp.renderSize = videoSize;

    //创建混音对象
    AVMutableAudioMix *videoAudioMixTools = [AVMutableAudioMix audioMix];
    
    //在某一时间点变化音量
    //设置音频轨道混合输入参数
    AVMutableAudioMixInputParameters *secondAudioParam = [AVMutableAudioMixInputParameters audioMixInputParametersWithTrack:audioTrack1];
    //设置第二个音轨音量
    [secondAudioParam setVolume:0.2 atTime:kCMTimeZero];
    
    //设置一段时间内变化音量
//    AVMutableAudioMixInputParameters  *parameters = [AVMutableAudioMixInputParameters audioMixInputParametersWithTrack:audioTrack1];
//
//    float begin = 0;
//    float end = 0.5;
//    [parameters setVolumeRampFromStartVolume:begin toEndVolume:end timeRange:CMTimeRangeMake(kCMTimeZero, audioTrack1.timeRange.duration)]; //

    
    //设置音频混合音频轨道
    videoAudioMixTools.inputParameters = @[secondAudioParam];
    
    videoComp.frameDuration = CMTimeMake(1, 30);
    //设置播放层videoLayer 动画层parentLayer 以合成新的视频帧
    videoComp.animationTool = [AVVideoCompositionCoreAnimationTool videoCompositionCoreAnimationToolWithPostProcessingAsVideoLayer:videoLayer inLayer:parentLayer];
    //创建视频合成操作指令
    AVMutableVideoCompositionInstruction* instruction = [AVMutableVideoCompositionInstruction videoCompositionInstruction];
    //指令生效时间
    instruction.timeRange = CMTimeRangeMake(kCMTimeZero, [mixComposition duration]);
    //视频通道数组
    AVAssetTrack* mixVideoTrack = [[mixComposition tracksWithMediaType:AVMediaTypeVideo] firstObject];
    //创建一个视频轨道的操作指令  AVMutableVideoCompositionLayerInstruction用于视频帧裁剪大小和设置透明度以及,对视频帧做一些动画缩放,旋转,平移等
    AVMutableVideoCompositionLayerInstruction* layerInstruction = [AVMutableVideoCompositionLayerInstruction videoCompositionLayerInstructionWithAssetTrack:mixVideoTrack];
    //把对应的视频轨道的操作设置添加到 视频合成操作指令对象中
    instruction.layerInstructions = [NSArray arrayWithObject:layerInstruction];
    //把指令集合添加到AVMutableVideoComposition指令集合中
    videoComp.instructions = [NSArray arrayWithObject: instruction];

//    NSURL *mergeFileURL = [NSURL fileURLWithPath:outpath];
    NSURL *mergeFileURL = [NSURL fileURLWithPath:outpath];
    //视频导出工具
    AVAssetExportSession *exporter = [[AVAssetExportSession alloc] initWithAsset:mixComposition
                                                                      presetName:AVAssetExportPreset1280x720];
    //设置视频合成的指令操作
    exporter.videoComposition = videoComp;
    //设置音频混合的参数
    exporter.audioMix = videoAudioMixTools;
    /*
     exporter.progress
     导出进度
     This property is not key-value observable.
     不支持kvo 监听
     只能用定时器监听了  NStimer
     */
    exporter.outputURL = mergeFileURL;
    //导出的文件类型
    exporter.outputFileType = AVFileTypeQuickTimeMovie;
    exporter.shouldOptimizeForNetworkUse = YES;
    [exporter exportAsynchronouslyWithCompletionHandler:^{
        dispatch_async(dispatch_get_main_queue(), ^{
           // 写入相册
           UISaveVideoAtPathToSavedPhotosAlbum([mergeFileURL path], self, @selector(video:didFinishSavingWithError:contextInfo:), nil);
            NSArray *files = [[NSFileManager defaultManager] subpathsAtPath:NSTemporaryDirectory()];
            NSLog(@"%@",files.firstObject);
            
        });
    }];
    
}

#pragma mark 视频保存完毕的回调
- (void)video:(NSString *)videoPath didFinishSavingWithError:(NSError *)error contextInfo:(void *)contextInf{
    if (error) {

        NSLog(@"保存视频过程中发生错误，错误信息:%@",error.localizedDescription);
    }else{
    NSLog(@"视频保存成功.");
    }
}

- (void)addGPUImageFilter:(GPUImageOutput<GPUImageInput> *)filter
{
    [_filterGroup addFilter:filter];
    
    GPUImageOutput<GPUImageInput> *newTerminalFilter = filter;
    
    NSInteger count = _filterGroup.filterCount;
    
    if (count == 1)
    {
        _filterGroup.initialFilters = @[newTerminalFilter];
        _filterGroup.terminalFilter = newTerminalFilter;
        
    } else
    {
        GPUImageOutput<GPUImageInput> *terminalFilter    = _filterGroup.terminalFilter;
        NSArray *initialFilters                          = _filterGroup.initialFilters;
        
        [terminalFilter addTarget:newTerminalFilter];
        
        _filterGroup.initialFilters = @[initialFilters[0]];
        _filterGroup.terminalFilter = newTerminalFilter;
    }
    
}


-(NSMutableArray *)urlArr{
    if (!_urlArr) {
        _urlArr = [NSMutableArray new];
    }
    return _urlArr;
}

@end
