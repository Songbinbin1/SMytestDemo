//
//  DPGeneralEmptyView.m
//  DPCrossBusinessModule
//
//  Created by Potato on 2020/5/6.
//

#import "DPGeneralEmptyView.h"

#import <DTConstant/DTConstant.h>

@interface DPGeneralEmptyView ()

@property (nonatomic, strong) UIStackView *stackView;

@property (nonatomic, strong) UIView *contentView;
@property (nonatomic, strong) UIImageView *contentImageView;

@property (nonatomic, strong) UIView *titleView;
@property (nonatomic, strong) UILabel *titleLabel;

@property (nonatomic, strong) UIView *detailView;
@property (nonatomic, strong) UILabel *detailLabel;

@property (nonatomic, strong) UIView *handleView;
@property (nonatomic, strong) UIButton *handleButton;

@property (nonatomic, strong) MASConstraint *stackViewCenterY;
@property (nonatomic, strong) MASConstraint *contentViewBottom;
@property (nonatomic, strong) MASConstraint *contentImageViewBottom;

@end

@implementation DPGeneralEmptyView

#pragma mark - Public

///
/// 创建空视图
/// @param emptyType 空视图类型
///
+ (instancetype)emptyViewWithEmptyType:(DPGeneralEmptyType)emptyType {
    
    DPGeneralEmptyView *emptyView = [[self alloc] init];
    emptyView.emptyType = emptyType;
    return emptyView;
    
}

///
/// 创建空视图
/// @param emptyType 空视图类型
/// @param noDataType 空数据类型
///
+ (instancetype)emptyViewWithEmptyType:(DPGeneralEmptyType)emptyType
                            noDataType:(DPGeneralNoDataType)noDataType {
    
    DPGeneralEmptyView *emptyView = [[self alloc] init];
    emptyView.emptyType = emptyType;
    emptyView.noDataType = noDataType;
    return emptyView;
    
}

///
/// 创建空视图，属性传nil代表隐藏
/// @param image 图片
/// @param title 标题
/// @param detail 描述
/// @param handle 按钮文案
/// @param handleAction 按钮事件
///
+ (instancetype)emptyViewWithImage:(nullable UIImage *)image
                             title:(nullable NSString *)title
                            detail:(nullable NSString *)detail
                            handle:(nullable NSString *)handle
                      handleAction:(nullable void(^)(void))handleAction {
    
    DPGeneralEmptyView *emptyView = [[self alloc] init];
    emptyView.image = image;
    emptyView.title = title;
    emptyView.detail = detail;
    emptyView.handle = handle;
    emptyView.handleAction = handleAction;
    return emptyView;
    
}

///
/// 更新 ContentImageView
///
- (void)updateContentImageViewWithBlock:(void(^)(UIImageView *))block {
    if (block) {
        block(self.contentImageView);
    }
}

///
/// 更新 TitleLabel
///
- (void)updateTitleLabelWithBlock:(void(^)(UILabel *))block {
    if (block) {
        block(self.titleLabel);
    }
}

///
/// 更新 DetailLabel
///
- (void)updateDetailLabelWithBlock:(void(^)(UILabel *))block {
    if (block) {
        block(self.detailLabel);
    }
}

///
/// 更新 HandleButton
///
- (void)updateHandleButtonWithBlock:(void(^)(UIButton *))block {
    if (block) {
        block(self.handleButton);
    }
}

///
/// 更新 StackView 约束
///
- (void)remakeConstraintsStackViewWithBlock:(void(^)(UIStackView *))block {
    self.stackViewCenterY = nil;
    
    if (block) {
        block(self.stackView);
    }
}

///
/// 更新 ContentView 约束
///
- (void)remakeConstraintsContentViewWithBlock:(void(^)(UIView *))block {
    self.contentViewBottom = nil;
    
    if (block) {
        block(self.contentView);
    }
}

///
/// 更新 ContentImageView 约束
///
- (void)remakeConstraintsContentImageViewWithBlock:(void(^)(UIImageView *))block {
    self.contentImageViewBottom = nil;
    
    if (block) {
        block(self.contentImageView);
    }
}

#pragma mark - Private

- (instancetype)init {
    self = [super init];
    if (self) {
        [self setupView];
        [self setupConstraint];
    }
    return self;
}

- (void)setupView {
    self.backgroundColor = UIColor.whiteColor;
    
    [self addSubview:self.stackView];
    [self.stackView addArrangedSubview:self.contentView];
    [self.stackView addArrangedSubview:self.titleView];
    [self.stackView addArrangedSubview:self.detailView];
    [self.stackView addArrangedSubview:self.handleView];
    
    [self.contentView addSubview:self.contentImageView];
    [self.titleView addSubview:self.titleLabel];
    [self.detailView addSubview:self.detailLabel];
    [self.handleView addSubview:self.handleButton];
}

- (void)setupConstraint {
    [self.stackView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.right.equalTo(self);
        self.stackViewCenterY = make.centerY.equalTo(self);
    }];
    
    [self.contentView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.right.equalTo(self.stackView);
        self.contentViewBottom = make.bottom.equalTo(self.mas_centerY).offset(DP_EMPTY_CONTENT_IMAGE_OFFSET);
    }];
    
    [self.contentImageView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.left.right.equalTo(self.contentView);
        self.contentImageViewBottom = make.bottom.equalTo(self.contentView).offset(-DP_EMPTY_CONTENT_IMAGE_OFFSET);
        make.height.equalTo(self.mas_width).multipliedBy(182.0/375.0);
    }];
    
    [self.titleView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.right.equalTo(self.stackView);
    }];
    
    [self.titleLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.equalTo(self.titleView);
    }];
    
    [self.detailView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.right.equalTo(self.stackView);
    }];
    
    [self.detailLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.equalTo(self.detailView);
    }];
    
    [self.handleView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.right.equalTo(self.stackView);
    }];
    
    [self.handleButton mas_updateConstraints:^(MASConstraintMaker *make) {
        make.top.bottom.centerX.equalTo(self.handleView);
    }];
    
    [self updateStackViewCenter];
    [self updateContentImageViewOffset];
}

- (void)assignContentImageView:(UIImage *)image {
    if (self.emptyType == DPGeneralEmptyTypeNoData) {
        self.contentImageView.image = self.noDataImage ? self.noDataImage : image;
    } else {
        self.contentImageView.image = self.image ? self.image : image;
    }
}

- (void)assignTitleLabel:(NSString *)title {
    if (self.emptyType == DPGeneralEmptyTypeNoData) {
        self.titleLabel.text = self.noDataTitle ? self.noDataTitle : title;
    } else {
        self.titleLabel.text = self.title ? self.title : title;
    }
}

- (void)assignDetailLabel:(NSString *)detail {
    if (self.emptyType == DPGeneralEmptyTypeNoData) {
        self.detailLabel.text = self.noDataDetail ? self.noDataDetail : detail;
    } else {
        self.detailLabel.text = self.detail ? self.detail : detail;
    }
}

- (void)assignHandleButton:(NSString *)handle {
    if (self.emptyType == DPGeneralEmptyTypeNoData) {
        [self.handleButton setTitle:self.noDataHandle ? self.noDataHandle : handle forState:UIControlStateNormal];
    } else {
        [self.handleButton setTitle:self.handle ? self.handle : handle forState:UIControlStateNormal];
    }
    
    [self updateHandleButton];
}

- (void)updateStackViewCenter {
    if (self.imageHidden) {
        [self.stackViewCenterY activate];
        [self.contentViewBottom deactivate];
    } else {
        if (self.titleHidden && self.detailHidden && self.handleHidden) {
            [self.stackViewCenterY activate];
            [self.contentViewBottom deactivate];
        } else {
            [self.stackViewCenterY deactivate];
            [self.contentViewBottom activate];
        }
    }
}

- (void)updateContentImageViewOffset {
    if (self.imageHidden) {
        self.contentViewBottom.offset = 0;
        self.contentImageViewBottom.offset = 0;
    } else {
        if (self.titleHidden && self.detailHidden && self.handleHidden) {
            self.contentViewBottom.offset = 0;
            self.contentImageViewBottom.offset = 0;
        } else {
            self.contentViewBottom.offset = DP_EMPTY_CONTENT_IMAGE_OFFSET;
            self.contentImageViewBottom.offset = -DP_EMPTY_CONTENT_IMAGE_OFFSET;
        }
    }
}

- (void)updateEmptyView {
    
    switch (self.emptyType) {
        case DPGeneralEmptyTypeNoNetwork:
            [self setupNoNetwork];
            break;
        case DPGeneralEmptyTypeLoadFailed:
            [self setupLoadFailed];
            break;
        case DPGeneralEmptyTypeNoData:
            [self setupNoData];
            break;
        default:
            break;
    }
    
    if (self.emptyType == DPGeneralEmptyTypeNoData) {
        switch (self.noDataType) {
            case DPGeneralNoDataTypeAll:
                [self setupNoDataAll];
                break;
            case DPGeneralNoDataTypeNormal:
                [self setupNoDataNormal];
                break;
            case DPGeneralNoDataTypeDetail:
                [self setupNoDataDetail];
                break;
            case DPGeneralNoDataTypeReload:
                [self setupNoDataReload];
                break;
            case DPGeneralNoDataTypeOnlyImage:
                [self setupNoDataOnlyImage];
                break;
            case DPGeneralNoDataTypeOnlyTitle:
                [self setupNoDataOnlyTitle];
                break;
            case DPGeneralNoDataTypeOnlyDetail:
                [self setupNoDataOnlyDetail];
                break;
            case DPGeneralNoDataTypeOnlyBtn:
                [self setupNoDataOnlyBtn];
                break;
            default:
                break;
        }
    }
    
}

- (void)updateHandleButton {
    [self.handleButton sizeToFit];
    self.handleButton.layer.cornerRadius = self.handleButton.frame.size.height / 2.0;
}

- (void)panGestureAction:(id)sender {
    
}

#pragma mark - DPGeneralEmptyType

- (void)setupNoNetwork {
    self.imageHidden = NO;
    self.titleHidden = NO;
    self.detailHidden = NO;
    self.handleHidden = NO;
    
    [self assignContentImageView:[UIImage imageNamed:DP_EMPTY_NO_NETWORK_IMAGE_NAME]];
    [self assignTitleLabel:EMPTY_T(DP_EMPTY_NO_NETWORK_TITLE_NAME)];
    [self assignDetailLabel:EMPTY_T(DP_EMPTY_NO_NETWORK_DETAIL_NAME)];
    [self assignHandleButton:EMPTY_T(DP_EMPTY_RELOAD_BUTTON_NAME)];
}

- (void)setupLoadFailed {
    self.imageHidden = NO;
    self.titleHidden = NO;
    self.detailHidden = YES;
    self.handleHidden = NO;
    
    [self assignContentImageView:[UIImage imageNamed:DP_EMPTY_LOAD_FAILED_IMAGE_NAME]];
    [self assignTitleLabel:EMPTY_T(DP_EMPTY_LOAD_FAILED_TITLE_NAME)];
    [self assignHandleButton:EMPTY_T(DP_EMPTY_RELOAD_BUTTON_NAME)];
}

- (void)setupNoData {
    [self assignContentImageView:[UIImage imageNamed:DP_EMPTY_NO_DATA_IMAGE_NAME]];
    [self assignTitleLabel:EMPTY_T(DP_EMPTY_NO_DATA_TITLE_NAME)];
    [self assignDetailLabel:EMPTY_T(DP_EMPTY_NO_DATA_TITLE_NAME)];
    [self assignHandleButton:EMPTY_T(DP_EMPTY_RELOAD_BUTTON_NAME)];
}

#pragma mark - DPGeneralNoDataType

- (void)setupNoDataAll {
    self.imageHidden = NO;
    self.titleHidden = NO;
    self.detailHidden = NO;
    self.handleHidden = NO;
}

- (void)setupNoDataDetail {
    self.imageHidden = NO;
    self.titleHidden = NO;
    self.detailHidden = NO;
    self.handleHidden = YES;
}

- (void)setupNoDataReload {
    self.imageHidden = NO;
    self.titleHidden = NO;
    self.detailHidden = YES;
    self.handleHidden = NO;
}

- (void)setupNoDataNormal {
    self.imageHidden = NO;
    self.titleHidden = NO;
    self.detailHidden = YES;
    self.handleHidden = YES;
}

- (void)setupNoDataOnlyImage {
    self.imageHidden = NO;
    self.titleHidden = YES;
    self.detailHidden = YES;
    self.handleHidden = YES;
}

- (void)setupNoDataOnlyTitle {
    self.imageHidden = YES;
    self.titleHidden = NO;
    self.detailHidden = YES;
    self.handleHidden = YES;
}

- (void)setupNoDataOnlyDetail {
    self.imageHidden = YES;
    self.titleHidden = YES;
    self.detailHidden = NO;
    self.handleHidden = YES;
}

- (void)setupNoDataOnlyBtn {
    self.imageHidden = YES;
    self.titleHidden = YES;
    self.detailHidden = YES;
    self.handleHidden = NO;
}

#pragma mark - Action

- (void)handleAction:(UIButton *)sender {
    if (self.handleAction) {
        self.handleAction();
    }
}

#pragma mark - Setter & Getter

- (void)setEmptyType:(DPGeneralEmptyType)emptyType {
    _emptyType = emptyType;
    
    [self updateEmptyView];
}

- (void)setNoDataType:(DPGeneralNoDataType)noDataType {
    _noDataType = noDataType;
    
    [self updateEmptyView];
}

- (void)setNoDataImage:(UIImage *)noDataImage {
    _noDataImage = noDataImage;
    
    if (self.emptyType != DPGeneralEmptyTypeNoData) {
        return;
    }
    
    if (noDataImage == nil) {
        return;
    }
    
    self.contentImageView.image = noDataImage;
    self.imageHidden = NO;
}

- (void)setImage:(UIImage *)image {
    _image = image;
    
    if (self.emptyType == DPGeneralEmptyTypeNoData) {
        return;
    }
    
    if (image == nil) {
        return;
    }
    
    self.contentImageView.image = image;
    self.imageHidden = NO;
}

- (void)setNoDataTitle:(NSString *)noDataTitle {
    _noDataTitle = noDataTitle;
    
    if (self.emptyType != DPGeneralEmptyTypeNoData) {
        return;
    }
    
    if ([noDataTitle isEqualToString:DP_EMPTY_DEFAULT_TITLE]) {
        return;
    }

    self.titleLabel.text = noDataTitle;
    self.titleHidden = noDataTitle == nil;
}

- (void)setTitle:(NSString *)title {
    _title = title;
    
    if (self.emptyType == DPGeneralEmptyTypeNoData) {
        return;
    }
    
    if ([title isEqualToString:DP_EMPTY_DEFAULT_TITLE]) {
        return;
    }
    
    self.titleLabel.text = title;
    self.titleHidden = title == nil;
}

- (void)setNoDataDetail:(NSString *)noDataDetail {
    _noDataDetail = noDataDetail;
    
    if (self.emptyType != DPGeneralEmptyTypeNoData) {
        return;
    }
    
    if ([noDataDetail isEqualToString:DP_EMPTY_DEFAULT_TITLE]) {
        return;
    }
    
    self.detailLabel.text = noDataDetail;
    self.detailHidden = noDataDetail == nil;
}

- (void)setDetail:(NSString *)detail {
    _detail = detail;
    
    if (self.emptyType == DPGeneralEmptyTypeNoData) {
        return;
    }
    
    if ([detail isEqualToString:DP_EMPTY_DEFAULT_TITLE]) {
        return;
    }
    
    self.detailLabel.text = detail;
    self.detailHidden = detail == nil;
}

- (void)setNoDataHandle:(NSString *)noDataHandle {
     _noDataHandle = noDataHandle;
    
    if (self.emptyType != DPGeneralEmptyTypeNoData) {
        return;
    }
    
    if ([noDataHandle isEqualToString:DP_EMPTY_DEFAULT_TITLE]) {
        return;
    }
    
    [self.handleButton setTitle:noDataHandle forState:UIControlStateNormal];
    [self updateHandleButton];
    
    self.handleHidden = noDataHandle == nil;
}

- (void)setHandle:(NSString *)handle {
    _handle = handle;
    
    if (self.emptyType == DPGeneralEmptyTypeNoData) {
        return;
    }
    
    if ([handle isEqualToString:DP_EMPTY_DEFAULT_TITLE]) {
        return;
    }
    
    [self.handleButton setTitle:handle forState:UIControlStateNormal];
    [self updateHandleButton];
    
    self.handleHidden = handle == nil;
}

- (void)setImageHidden:(BOOL)imageHidden {
    _imageHidden = imageHidden;
    
    self.contentView.hidden = imageHidden;
    
    [self updateStackViewCenter];
    [self updateContentImageViewOffset];
}

- (void)setTitleHidden:(BOOL)titleHidden {
    _titleHidden = titleHidden;
    
    self.titleView.hidden = titleHidden;
    
    [self updateStackViewCenter];
    [self updateContentImageViewOffset];
}

- (void)setDetailHidden:(BOOL)detailHidden {
    _detailHidden = detailHidden;
    
    self.detailView.hidden = detailHidden;
    
    [self updateStackViewCenter];
    [self updateContentImageViewOffset];
}

- (void)setHandleHidden:(BOOL)handleHidden {
    _handleHidden = handleHidden;
    
    self.handleView.hidden = handleHidden;
    
    [self updateStackViewCenter];
    [self updateContentImageViewOffset];
}

- (UIStackView *)stackView {
    if (!_stackView) {
        _stackView = [[UIStackView alloc] init];
        _stackView.axis = UILayoutConstraintAxisVertical;
        _stackView.spacing = 14;
    }
    
    return _stackView;
}

- (UIView *)contentView {
    if (!_contentView) {
        _contentView = [[UIView alloc] init];
        _contentView.backgroundColor = UIColor.clearColor;
        _contentView.hidden = YES;
        _imageHidden = YES;
    }
    
    return _contentView;
}

- (UIImageView *)contentImageView {
    if (!_contentImageView) {
        _contentImageView = [[UIImageView alloc] init];
        _contentImageView.layer.masksToBounds = YES;
        _contentImageView.contentMode = UIViewContentModeScaleAspectFill;
    }
    
    return _contentImageView;
}

- (UIView *)titleView {
    if (!_titleView) {
        _titleView = [[UIView alloc] init];
        _titleView.backgroundColor = UIColor.clearColor;
        _titleView.hidden = YES;
        _titleHidden = YES;
    }
    
    return _titleView;
}

- (UILabel *)titleLabel {
    if (!_titleLabel) {
        _titleLabel = [[UILabel alloc] init];
        _titleLabel.textColor = [UIColor colorWithHexString:@"303030"];
        _titleLabel.font = DTFont(16.0);
        _titleLabel.textAlignment = NSTextAlignmentCenter;
        _titleLabel.numberOfLines = 0;
    }
    
    return _titleLabel;
}

- (UIView *)detailView {
    if (!_detailView) {
        _detailView = [[UIView alloc] init];
        _detailView.backgroundColor = UIColor.clearColor;
        _detailHidden = YES;
    }
    
    return _detailView;
}

- (UILabel *)detailLabel {
    if (!_detailLabel) {
        _detailLabel = [[UILabel alloc] init];
        _detailLabel.textColor = [UIColor colorWithHexString:@"666666"];
        _detailLabel.font = DTFont(14.0);
        _detailLabel.textAlignment = NSTextAlignmentCenter;
        _detailLabel.numberOfLines = 0;
    }
    
    return _detailLabel;
}

- (UIView *)handleView {
    if (!_handleView) {
        _handleView = [[UIView alloc] init];
        _handleView.backgroundColor = UIColor.clearColor;
        _handleHidden = YES;
    }
    
    return _handleView;
}

- (UIButton *)handleButton {
    if (!_handleButton) {
        _handleButton = [[UIButton alloc] init];
        _handleButton.layer.borderWidth = 0;
        _handleButton.layer.masksToBounds = YES;
        _handleButton.titleLabel.font = [UIFont systemFontOfSize:16.0f];
        _handleButton.contentEdgeInsets = UIEdgeInsetsMake(14, 35, 14, 35);
        [_handleButton setTitleColor:UIColor.whiteColor forState:UIControlStateNormal];
        [_handleButton setTitleColor:UIColor.whiteColor forState:UIControlStateHighlighted];
        [_handleButton setBackgroundImage:[UIImage imageWithColor:[UIColor colorWithHexString:@"#FA384F"]] forState:UIControlStateNormal];
        [_handleButton setBackgroundImage:[UIImage imageWithColor:[UIColor colorWithHexString:@"#C82C3F"]] forState:UIControlStateHighlighted];
        [_handleButton addTarget:self action:@selector(handleAction:) forControlEvents:UIControlEventTouchUpInside];
    }
    
    return _handleButton;
}

@end
