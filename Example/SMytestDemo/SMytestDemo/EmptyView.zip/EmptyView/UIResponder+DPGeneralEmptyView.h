//
//  UIResponder+DPGeneralEmptyView.h
//  DPCrossBusinessModule
//
//  Created by Potato on 2020/5/7.
//
#import <UIKit/UIKit.h>
#import <DZNEmptyDataSet/UIScrollView+EmptyDataSet.h>
#import "DPGeneralEmptyView.h"

NS_ASSUME_NONNULL_BEGIN

@interface UIResponder (DPGeneralEmptyView) <DZNEmptyDataSetDelegate, DZNEmptyDataSetSource>

@property (nonatomic, strong) UIScrollView *dp_generalEmptyScrollerView; ///< 需要空数据底图的scrollerView

@property (nonatomic, strong, nullable) DPGeneralEmptyView *dp_generalEmptyView; ///< 空视图

@property (nonatomic, assign) BOOL dp_isLoadDataSuccessed; ///< 请求数据是否成功

@property (nonatomic, assign) BOOL dp_hasLoadedData; ///< 是否请求过数据

///
/// 请求成功
///
- (void)dp_loadDataSuccess;

///
/// 请求失败
///
- (void)dp_loadDataFailed;

///
/// 获取当前空视图状态
///
- (DPGeneralEmptyType)dp_configGeneralEmptyType;

#pragma mark - Show Empty View

///
/// 显示空视图状态
/// @param type 空状态类型
/// @param noDataImage 图片
/// @param imageHidden 图片是否显示
/// @param noDataTitle 标题
/// @param noDataDetail 描述
/// @param noDataRetry 按钮文案
/// @param handler 按钮事件
///

- (void)dp_showEmptyViewWithType:(DPGeneralEmptyType)type
                     noDataImage:(nullable UIImage *)noDataImage
                     imageHidden:(BOOL)imageHidden
                     noDataTitle:(nullable NSString *)noDataTitle
                    noDataDetail:(nullable NSString *)noDataDetail
                     noDataRetry:(nullable NSString *)noDataRetry
                         handler:(nullable void(^)(void))handler;

- (void)dp_showEmptyViewWithType:(DPGeneralEmptyType)type
                     noDataTitle:(nullable NSString *)noDataTitle
                     noDataRetry:(nullable NSString *)noDataRetry
                         handler:(nullable void(^)(void))handler;

- (void)dp_showEmptyViewWithType:(DPGeneralEmptyType)type
                     noDataImage:(nullable UIImage *)noDataImage
                     noDataTitle:(nullable NSString *)noDataTitle;

- (void)dp_showEmptyViewWithType:(DPGeneralEmptyType)type
                    noDataDetail:(nullable NSString *)noDataDetail;

- (void)dp_showEmptyViewWithType:(DPGeneralEmptyType)type
                     noDataTitle:(nullable NSString *)noDataTitle;

- (void)dp_showEmptyViewWithType:(DPGeneralEmptyType)type
                      noDataType:(DPGeneralNoDataType)noDataType
                         handler:(nullable void(^)(void))handler;

- (void)dp_showEmptyViewWithType:(DPGeneralEmptyType)type
                         handler:(nullable void(^)(void))handler;

- (void)dp_showEmptyViewWithType:(DPGeneralEmptyType)type
                           image:(nullable UIImage *)image
                     imageHidden:(BOOL)imageHidden
                           title:(nullable NSString *)title
                          detail:(nullable NSString *)detail
                           retry:(nullable NSString *)retry
                         handler:(nullable void(^)(void))handler;

- (void)dp_showEmptyViewWithType:(DPGeneralEmptyType)type
                           title:(nullable NSString *)title
                           retry:(nullable NSString *)retry
                         handler:(nullable void(^)(void))handler;

- (void)dp_showEmptyViewWithType:(DPGeneralEmptyType)type
                           title:(nullable NSString *)title;

#pragma mark - Hide Empty View

///
/// 隐藏空视图
///
- (void)dp_hideEmptyView;

@end

NS_ASSUME_NONNULL_END
