//
//  DPGeneralEmptyView.h
//  DPCrossBusinessModule
//
//  Created by Potato on 2020/5/6.
//

#import <UIKit/UIKit.h>

#define DP_EMPTY_NO_NETWORK_IMAGE_NAME   @"empty_view_no_network"
#define DP_EMPTY_NO_NETWORK_TITLE_NAME   @"empty_view_no_network_title"
#define DP_EMPTY_NO_NETWORK_DETAIL_NAME  @"empty_view_no_network_detail"

#define DP_EMPTY_LOAD_FAILED_IMAGE_NAME  @"empty_view_load_failed"
#define DP_EMPTY_LOAD_FAILED_TITLE_NAME  @"empty_view_load_failed_title"

#define DP_EMPTY_NO_DATA_IMAGE_NAME      @"empty_view_no_data"
#define DP_EMPTY_NO_DATA_TITLE_NAME      @"empty_view_no_data_title"

#define DP_EMPTY_RELOAD_BUTTON_NAME      @"empty_view_reload_button_title"

#define DP_EMPTY_CONTENT_IMAGE_OFFSET    11

#define DP_EMPTY_DEFAULT_TITLE     @"empty_default_title"

#define EMPTY_T(str)            NSLocalizedString(str, str)

typedef NS_ENUM(NSUInteger, DPGeneralEmptyType) {
    DPGeneralEmptyTypeNoNetwork = 0,    // 无网络（默认显示 image、title、btn）
    DPGeneralEmptyTypeLoadFailed,       // 加载失败（默认显示 image、title、btn）
    DPGeneralEmptyTypeNoData,           // 没有内容
};

typedef NS_ENUM(NSUInteger, DPGeneralNoDataType) {
    DPGeneralNoDataTypeNormal = 0,      // 默认显示 image、title
    DPGeneralNoDataTypeDetail,          // 默认显示 image、title、detail
    DPGeneralNoDataTypeReload,          // 默认显示 image、title、btn
    DPGeneralNoDataTypeAll,             // 默认显示 image、title、detail、btn
    DPGeneralNoDataTypeOnlyImage,       // 默认显示 image
    DPGeneralNoDataTypeOnlyTitle,       // 默认显示 title
    DPGeneralNoDataTypeOnlyDetail,      // 默认显示 detail
    DPGeneralNoDataTypeOnlyBtn,         // 默认显示 btn
};

NS_ASSUME_NONNULL_BEGIN

@interface DPGeneralEmptyView : UIView

#pragma mark - 类型

/// 空视图类型
@property (nonatomic, assign) DPGeneralEmptyType emptyType;

/// 空数据类型
@property (nonatomic, assign) DPGeneralNoDataType noDataType;

#pragma mark - 内容

/// 空数据 - 图片
@property (nonatomic, strong, nullable) UIImage *noDataImage;

/// 默认 - 图片
@property (nonatomic, strong, nullable) UIImage *image;

/// 空数据 - 标题文案
@property (nonatomic, strong, nullable) NSString *noDataTitle;

/// 默认 - 标题文案
@property (nonatomic, strong, nullable) NSString *title;

/// 空数据 - 详情文案
@property (nonatomic, strong, nullable) NSString *noDataDetail;

/// 默认 - 详情文案
@property (nonatomic, strong, nullable) NSString *detail;

/// 空数据 - 按钮文案
@property (nonatomic, strong, nullable) NSString *noDataHandle;

/// 默认 - 按钮文案
@property (nonatomic, strong, nullable) NSString *handle;

/// 按钮事件
@property (nonatomic, copy, nullable) void (^handleAction)(void);

#pragma mark - 隐藏

/// 图片是否隐藏
@property (nonatomic, assign) BOOL imageHidden;

/// 标题是否隐藏
@property (nonatomic, assign) BOOL titleHidden;

/// 详情是否隐藏
@property (nonatomic, assign) BOOL detailHidden;

/// 按钮是否隐藏
@property (nonatomic, assign) BOOL handleHidden;

#pragma mark - 构造方法

///
/// 创建空视图
/// @param emptyType 空视图类型
///
+ (instancetype)emptyViewWithEmptyType:(DPGeneralEmptyType)emptyType;

///
/// 创建空视图
/// @param emptyType 空视图类型
/// @param noDataType 空数据类型
///
+ (instancetype)emptyViewWithEmptyType:(DPGeneralEmptyType)emptyType
                            noDataType:(DPGeneralNoDataType)noDataType;

///
/// 创建空视图，属性传nil代表隐藏
/// @param image 图片
/// @param title 标题
/// @param detail 描述
/// @param handle 按钮文案
/// @param handleAction 按钮事件
///
+ (instancetype)emptyViewWithImage:(nullable UIImage *)image
                             title:(nullable NSString *)title
                            detail:(nullable NSString *)detail
                            handle:(nullable NSString *)handle
                      handleAction:(nullable void(^)(void))handleAction;

#pragma mark - 更改样式

///
/// 更新 ContentImageView
///
- (void)updateContentImageViewWithBlock:(void(^)(UIImageView *))block;

///
/// 更新 TitleLabel
///
- (void)updateTitleLabelWithBlock:(void(^)(UILabel *))block;

///
/// 更新 DetailLabel
///
- (void)updateDetailLabelWithBlock:(void(^)(UILabel *))block;

///
/// 更新 HandleButton
///
- (void)updateHandleButtonWithBlock:(void(^)(UIButton *))block;

#pragma mark - 更改约束

///
/// 更新 StackView 约束
///
- (void)remakeConstraintsStackViewWithBlock:(void(^)(UIStackView *))block;

///
/// 更新 ContentView 约束
///
- (void)remakeConstraintsContentViewWithBlock:(void(^)(UIView *))block;

///
/// 更新 ContentImageView 约束
///
- (void)remakeConstraintsContentImageViewWithBlock:(void(^)(UIImageView *))block;


@end

NS_ASSUME_NONNULL_END
