//
//  UIResponder+DPGeneralEmptyView.m
//  DPCrossBusinessModule
//
//  Created by Potato on 2020/5/7.
//

#import "UIResponder+DPGeneralEmptyView.h"
#import <objc/runtime.h>
#import <Reachability/Reachability.h>

@implementation UIResponder (DPGeneralEmptyView)

#pragma mark - Public

///
/// 请求成功
///
- (void)dp_loadDataSuccess {
    self.dp_hasLoadedData = YES;
    self.dp_isLoadDataSuccessed = YES;
}

///
/// 请求失败
///
- (void)dp_loadDataFailed {
    self.dp_hasLoadedData = YES;
    self.dp_isLoadDataSuccessed = NO;
}

///
/// 获取当前空视图状态
///
- (DPGeneralEmptyType)dp_configGeneralEmptyType {
    if (self.dp_isLoadDataSuccessed) {
        return DPGeneralEmptyTypeNoData;
    } else if (![[Reachability reachabilityForInternetConnection] isReachable]) {
        return DPGeneralEmptyTypeNoNetwork;
    } else {
        return DPGeneralEmptyTypeLoadFailed;
    }
}

#pragma mark - Show Empty View

- (void)dp_showEmptyViewWithType:(DPGeneralEmptyType)type
                     noDataImage:(nullable UIImage *)noDataImage
                     imageHidden:(BOOL)imageHidden
                     noDataTitle:(nullable NSString *)noDataTitle
                    noDataDetail:(nullable NSString *)noDataDetail
                     noDataRetry:(nullable NSString *)noDataRetry
                         handler:(nullable void(^)(void))handler {
    
    UIView *view = nil;
    
    if ([self isKindOfClass:UIViewController.class]) {
        view = ((UIViewController*)self).view;
    } else if ([self isKindOfClass:UIView.class]) {
        view = (id)self;
    }
    
    if (view == nil) {
        // 暂不支持
        return;
    }
    
    // 每一次都隐藏，防止叠加
    [self dp_hideEmptyView];
    
    DPGeneralEmptyView *emptyView = [DPGeneralEmptyView emptyViewWithEmptyType:type noDataType:DPGeneralNoDataTypeAll];
    emptyView.noDataImage = noDataImage;
    emptyView.imageHidden = imageHidden;
    emptyView.noDataTitle = noDataTitle;
    emptyView.noDataDetail = noDataDetail;
    emptyView.noDataHandle = noDataRetry;
    emptyView.handleAction = handler;
    
    emptyView.frame = view.bounds;
    emptyView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    
    [view addSubview:emptyView];
    
    self.dp_generalEmptyView = emptyView;
    
    if ([view isKindOfClass:UIScrollView.class]) {
        UIScrollView *scrollView = (id)view;
        emptyView.tag = scrollView.scrollEnabled;
        scrollView.scrollEnabled = NO;
    }
    
}

- (void)dp_showEmptyViewWithType:(DPGeneralEmptyType)type
                     noDataTitle:(nullable NSString *)noDataTitle
                     noDataRetry:(nullable NSString *)noDataRetry
                         handler:(nullable void(^)(void))handler {
    [self dp_showEmptyViewWithType:type noDataImage:nil imageHidden:YES noDataTitle:noDataTitle noDataDetail:nil noDataRetry:noDataRetry handler:handler];
}

- (void)dp_showEmptyViewWithType:(DPGeneralEmptyType)type
                     noDataImage:(nullable UIImage *)noDataImage
                     noDataTitle:(nullable NSString *)noDataTitle {
    [self dp_showEmptyViewWithType:type noDataImage:noDataImage imageHidden:(noDataImage==nil) noDataTitle:noDataTitle noDataDetail:nil noDataRetry:nil handler:nil];
}

- (void)dp_showEmptyViewWithType:(DPGeneralEmptyType)type
                    noDataDetail:(nullable NSString *)noDataDetail {
    [self dp_showEmptyViewWithType:type noDataImage:nil imageHidden:YES noDataTitle:nil noDataDetail:noDataDetail noDataRetry:nil handler:nil];
}

- (void)dp_showEmptyViewWithType:(DPGeneralEmptyType)type
                     noDataTitle:(nullable NSString *)noDataTitle {
    [self dp_showEmptyViewWithType:type noDataImage:nil imageHidden:YES noDataTitle:noDataTitle noDataDetail:nil noDataRetry:nil handler:nil];
}

- (void)dp_showEmptyViewWithType:(DPGeneralEmptyType)type
                      noDataType:(DPGeneralNoDataType)noDataType
                         handler:(nullable void(^)(void))handler {
    
    UIView *view = nil;
    
    if ([self isKindOfClass:UIViewController.class]) {
        view = ((UIViewController*)self).view;
    } else if ([self isKindOfClass:UIView.class]) {
        view = (id)self;
    }
    
    if (view == nil) {
        // 暂不支持
        return;
    }
    
    // 每一次都隐藏，防止叠加
    [self dp_hideEmptyView];
    
    DPGeneralEmptyView *emptyView = [DPGeneralEmptyView emptyViewWithEmptyType:type noDataType:noDataType];
    emptyView.handleAction = handler;
    
    emptyView.frame = view.bounds;
    emptyView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    
    [view addSubview:emptyView];
    
    self.dp_generalEmptyView = emptyView;
    
    if ([view isKindOfClass:UIScrollView.class]) {
        UIScrollView *scrollView = (id)view;
        emptyView.tag = scrollView.scrollEnabled;
        scrollView.scrollEnabled = NO;
    }
    
}

- (void)dp_showEmptyViewWithType:(DPGeneralEmptyType)type
                         handler:(nullable void(^)(void))handler {
    [self dp_showEmptyViewWithType:type noDataType:DPGeneralNoDataTypeNormal handler:handler];
}

- (void)dp_showEmptyViewWithType:(DPGeneralEmptyType)type
                           image:(nullable UIImage *)image
                     imageHidden:(BOOL)imageHidden
                           title:(nullable NSString *)title
                          detail:(nullable NSString *)detail
                           retry:(nullable NSString *)retry
                         handler:(nullable void(^)(void))handler {

    UIView *view = nil;
    
    if ([self isKindOfClass:UIViewController.class]) {
        view = ((UIViewController*)self).view;
    } else if ([self isKindOfClass:UIView.class]) {
        view = (id)self;
    }
    
    if (view == nil) {
        // 暂不支持
        return;
    }
    
    // 每一次都隐藏，防止叠加
    [self dp_hideEmptyView];
    
    DPGeneralEmptyView *emptyView = [DPGeneralEmptyView emptyViewWithEmptyType:type noDataType:DPGeneralNoDataTypeAll];
    emptyView.image = image;
    emptyView.imageHidden = imageHidden;
    emptyView.title = title;
    emptyView.detail = detail;
    emptyView.handle = retry;
    emptyView.handleAction = handler;
    
    emptyView.frame = view.bounds;
    emptyView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    
    [view addSubview:emptyView];
    
    self.dp_generalEmptyView = emptyView;
    
    if ([view isKindOfClass:UIScrollView.class]) {
        UIScrollView *scrollView = (id)view;
        emptyView.tag = scrollView.scrollEnabled;
        scrollView.scrollEnabled = NO;
    }
    
}

- (void)dp_showEmptyViewWithType:(DPGeneralEmptyType)type
                           title:(nullable NSString *)title
                           retry:(nullable NSString *)retry
                         handler:(nullable void(^)(void))handler {
    [self dp_showEmptyViewWithType:type image:nil imageHidden:YES title:title detail:nil retry:retry handler:handler];
}

- (void)dp_showEmptyViewWithType:(DPGeneralEmptyType)type
                           title:(nullable NSString *)title {
    [self dp_showEmptyViewWithType:type image:nil imageHidden:YES title:title detail:nil retry:nil handler:nil];
}

#pragma mark - Hide Empty View

///
/// 隐藏空视图
///
- (void)dp_hideEmptyView {
    DPGeneralEmptyView *emptyView = self.dp_generalEmptyView;
    
    if (emptyView == nil) {
        return;
    }
    
    UIView *view = emptyView.superview;
    if ([view isKindOfClass:UIScrollView.class]) {
        UIScrollView *scrollView = (id)view;
        scrollView.scrollEnabled = emptyView.tag;
    }
    
    [emptyView removeFromSuperview];
    
    self.dp_generalEmptyView = nil;
}


#pragma mark - Setter & Getter

- (void)setDp_generalEmptyScrollerView:(UIScrollView *)dp_generalEmptyScrollerView {
    if (!dp_generalEmptyScrollerView) {
        return;
    }
    dp_generalEmptyScrollerView.emptyDataSetDelegate = self;
    dp_generalEmptyScrollerView.emptyDataSetSource = self;
    objc_setAssociatedObject(self, @selector(dp_generalEmptyScrollerView), dp_generalEmptyScrollerView, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
}

- (UIScrollView *)dp_generalEmptyScrollerView {
    return objc_getAssociatedObject(self, @selector(dp_generalEmptyScrollerView));
}

- (void)setDp_generalEmptyView:(DPGeneralEmptyView *)dp_generalEmptyView {
    objc_setAssociatedObject(self, @selector(dp_generalEmptyView), dp_generalEmptyView, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
}

- (DPGeneralEmptyView *)dp_generalEmptyView {
    return objc_getAssociatedObject(self, @selector(dp_generalEmptyView));
}

- (void)setDp_isLoadDataSuccessed:(BOOL)dp_isLoadDataSuccessed {
    objc_setAssociatedObject(self, @selector(dp_isLoadDataSuccessed), [NSNumber numberWithBool:dp_isLoadDataSuccessed], OBJC_ASSOCIATION_RETAIN_NONATOMIC);
}

- (BOOL)dp_isLoadDataSuccessed {
    return [objc_getAssociatedObject(self, @selector(dp_isLoadDataSuccessed)) boolValue];
}

- (void)setDp_hasLoadedData:(BOOL)dp_hasLoadedData {
    objc_setAssociatedObject(self, @selector(dp_hasLoadedData), [NSNumber numberWithBool:dp_hasLoadedData], OBJC_ASSOCIATION_RETAIN_NONATOMIC);
}

- (BOOL)dp_hasLoadedData {
    return [objc_getAssociatedObject(self, @selector(dp_hasLoadedData)) boolValue];
}

#pragma mark - DZNEmptyDataSetDelegate, DZNEmptyDataSetSource

- (BOOL)emptyDataSetShouldAllowScroll:(UIScrollView *)scrollView {
    return YES;
}

- (BOOL)emptyDataSetShouldAllowTouch:(UIScrollView *)scrollView {
    return YES;
}

- (UIView *)customViewForEmptyDataSet:(UIScrollView *)scrollView {
    if (!self.dp_hasLoadedData) {
        return nil;
    }
    
    // 强制调整contentOffset，避免正在进行下拉加载动画导致位置异常
    scrollView.contentOffset = CGPointZero;
    
    self.dp_generalEmptyView.emptyType = [self dp_configGeneralEmptyType];
    CGSize size = scrollView.bounds.size;
    CGRect emptyViewFrame = CGRectMake(0, 0, size.width, size.height);
    self.dp_generalEmptyView.frame = emptyViewFrame;
    return self.dp_generalEmptyView;
}

- (BOOL)emptyDataSetShouldDisplay:(UIScrollView *)scrollView {
    return YES;
}

- (CGPoint)offsetForEmptyDataSet:(UIScrollView *)scrollView {
    CGFloat top = scrollView.contentInset.top / 2.0;
    CGFloat left = scrollView.contentInset.left / 2.0;
    CGFloat bottom = scrollView.contentInset.bottom / 2.0;
    CGFloat right = scrollView.contentInset.right / 2.0;
    
    CGPoint offset = CGPointMake(right-left, bottom-top);
    return offset;
}

@end
